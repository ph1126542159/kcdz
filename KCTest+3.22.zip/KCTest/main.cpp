﻿#include "UI/MainWindow.h"
#include <QApplication>
#include "PLCCommProc.h"
#include "DBMgr/DBMgr.h"
#include "AllConfig.h"
#include "ULog/ulog.h"
#include <QDebug>
#include <QThread>
#include "Mgr.h"
#include <QSystemSemaphore>
#include <QSharedMemory>

//C:\Qt5\Qt5.14.2\5.14.2\mingw73_64\bin\windeployqt.exe  KCTest.exe


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

     QCoreApplication::setAttribute(Qt::AA_ShareOpenGLContexts);
     QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

       //确保只运行一次
     QSystemSemaphore sema("MaQi", 1, QSystemSemaphore::Open);
     sema.acquire();//在临界区操作共享内存  SharedMemory

     QSharedMemory mem("MaQiObject"); //全局对象名
     bool bCreate = mem.create(1);
     qDebug() << "bCreate=============" << bCreate;

      if(bCreate)
       {
        //创建成功，说明之前没有程序在运行
        qDebug() << "create shared memory success======";
     }
      else
     {
        //创建失败，说明已经有一个程序在运行了。
          qDebug() << "An instance has already been running======";
        sema.release();//如果是 Unix 系统，会自动释放。
        return 0;
     }

     sema.release();//临界区
    MainWindow::instance()->show();
    Mgr mgr;
    mgr.sigPlcInit();

    return a.exec();
}
 
