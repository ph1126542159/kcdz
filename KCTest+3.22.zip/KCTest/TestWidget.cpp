﻿#include "TestWidget.h"
#include "ui_TestWidget.h"

TestWidget::TestWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TestWidget)
{
    ui->setupUi(this);

    m_plc = PLCCommProc::instance();


}

TestWidget::~TestWidget()
{
    delete ui;
}



void TestWidget::on_pushButton_2_clicked()
{
    //m_plc->m_plCcmd->ReConnect();
}

void TestWidget::on_pushButton_clicked()
{
    ushort heart = 0;
    bool enPreCheck = 0;
    bool recvCheck = 0;
    bool finished = 0;
    char rslt = 0;

   // m_plc->m_plCcmd->PreCheck_Write(heart, enPreCheck, recvCheck, finished, rslt);
}

void TestWidget::on_pushButton_3_clicked()
{
    ushort heart = 0;
    bool enWriteCode = 1;
    bool codeUsed = 1;
    bool recvWrite = 1;
    bool writeFinished = 1;
    bool writed = 1;
    char rslt = 0xff;
    QByteArray codes;
    QByteArray failedcodes;
    ushort len = 0;
    ushort num = 0;
    ushort writedNUm = 0;

    for(int i = 0; i < 5; i++)
    {
        for(int k = 0; k < 22; k++)
        {
            codes.append((char)0);
            codes.append((char)0);
        }
    }
    for(int i = 0; i < 5; i++)
    {
        failedcodes.append((char)0);
        failedcodes.append((char)0);
    }

//    m_plc->m_plCcmd->WriteCode_Write( heart, enWriteCode,  codeUsed, recvWrite,
//                           writeFinished,  writed, rslt,
//                           codes,  failedcodes,
//                           len, num, writedNUm);


}

void TestWidget::on_pushButton_4_clicked()
{
    ushort heart = 1;
    bool enReCheck = 1;
    bool recvReCheck = 1;
    bool recheckFinished = 1;
    char rslt = 0;
    const QByteArray codes;
    const QByteArray failedcodes;

   // m_plc->m_plCcmd->Recheck_Write(heart, enReCheck, recvReCheck, recheckFinished, rslt, codes, failedcodes);
   // m_cmd.Recheck_Write();
}


void TestWidget::on_pushButton_5_clicked()
{
    int heart;
    bool startPreCheck;
    bool reset;
   // m_plc->m_plCcmd->PreCheck_Read(heart, startPreCheck, reset);
}

void TestWidget::on_pushButton_6_clicked()
{
    int heart;
    bool writeCodeOK;
    bool  tiaohao;
    bool butiaohao;
    ushort lineLength;

  //  m_plc->m_plCcmd->WriteCode_Read(heart, writeCodeOK, tiaohao, butiaohao, lineLength);
}

void TestWidget::on_pushButton_7_clicked()
{
    int heart;
    bool startReCheck;
    bool reset;

  //  m_plc->m_plCcmd->Recheck_Read(heart, startReCheck, reset);
}

void TestWidget::on_pushButton_8_clicked()
{
  //  m_plc->m_plCcmd->WriteCode_Write_R();
}

void TestWidget::on_pushButton_9_clicked()
{
   // m_plc->m_plCcmd->PreCheck_Write_R();
}

void TestWidget::on_pushButton_10_clicked()
{
   // m_plc->m_plCcmd->Recheck_Write_R();
}

void TestWidget::on_pushButton_11_clicked()
{


    QByteArray outcodes;

//    for(int i = 0; i < 5; i++){
//        outcodes.append((char)0);
//        for(int k = 1; k < 14; k++){
//            outcodes.append('0');
//        }
//    }
    outcodes.append("05230203E00001");
    outcodes.append("05230203E00002");
    outcodes.append("05230203E00003");
    outcodes.append("05230203E00004");
    outcodes.append("05230203E00005");


    //m_chCmd.startWriteCode(outcodes);
}

void TestWidget::on_pushButton_12_clicked()
{
    //m_chCmd.startCheck();
}

void TestWidget::on_pushButton_13_clicked()
{
    int channel = ui->lineEdit->text().toInt();
    QByteArray rslt;

    //m_chCmd.readCheckRslt(channel, rslt);
}
