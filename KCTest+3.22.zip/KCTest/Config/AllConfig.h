﻿#ifndef DETCONFIG_H
#define DETCONFIG_H

#include <QList>
#include <QStringList>
#include <QDate>

struct ProduceConfigType{
    QString taskId;
    QString codePrefix;
    int produceStage; //生产环节
    int factory; //工厂码
    int detType; //雷管类型
    uchar feature; //特征码
    //获取当前时间
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString productDate = currentDateTime.toString("yyyy.MM.dd");  //生产日期
    int lineLength; //脚线长度
    int cntboxInPack; //箱内数量
    int numInBox;  //盒内数量
    int startBox; //起始盒号
    int startNo;  //起始序号

    int produceNum;  //生产数量
    int produceNumTotal; // 任务栏的总数量
    int channel = 0; //通道数
    int detcoreType = 0; //芯片类型

    int produceLineID = 0; //机台号
    int produceWritedNum = 0;
    int hasProductedTotalNum = 0; //已生产总数
    int finalProductedNum = 0; //最后一个任务需要的生产数
    bool finalProduceFlag = false; // 判断是否为最后一个任务
    int m_currentRunRow = 0;
    QString channel_port;
    QString plc_ip;
    QString precheckCh_port;
};

class AllConfig
{
public:
    static AllConfig* instance(){
        static AllConfig* _ins = new AllConfig();
        return _ins;
    }
    QString randString();
    QString statusToChinese(int statusInfo);  //状态码数字 转 中文
    void readConfig();
    void saveConfig();

    QByteArray getPreviewOutCode();

    struct ProduceConfigType* getProduceConfig();

private:
    AllConfig();

    struct ProduceConfigType m_produceConfig;
};

#endif // DETCONFIG_H
