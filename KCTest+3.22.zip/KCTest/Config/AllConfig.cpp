﻿#include "AllConfig.h"
#include <QList>
#include <QStringList>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

AllConfig::AllConfig()
{
    m_produceConfig.factory = 52; //工厂码
    m_produceConfig.detType = 1; //雷管类型
    m_produceConfig.feature = '9'; //特征码
    m_produceConfig.productDate = "2023.01.15";  //生产日期
    m_produceConfig.lineLength = 100; //脚线长度
    m_produceConfig.numInBox = 100;  //盒内数量
    m_produceConfig.startBox = 0; //起始盒号
    m_produceConfig.startNo = 0;  //起始序号
    m_produceConfig.produceNum = 100;  //生产数量
    readConfig();
}

QString AllConfig::randString()
{
    QString taskId = "";
    for(int i=0; i<10; i++)
        {
           int test=qrand()%10;
           taskId = taskId+QString::number(test);
        }

    return taskId;
}

QString AllConfig::statusToChinese(int statusInfo)
{
        if (statusInfo == 0) {
            return "正常";
        }
        else if (statusInfo == 255)
        {
            return "测试中";
        }
        else if (statusInfo == 1)
        {
            return "1//低压下正向电流小";
        }
        else if (statusInfo == 3)
        {
            return "3//低压下反向电流小";
        }
        else if (statusInfo == 5)
        {
            return "5//序列码读取错误";
        }
        else if (statusInfo == 20)
        {
            return "20//高压下正向电流小";
        }
        else if (statusInfo == 22)
        {
            return "22//高压下反向电流小";
        }
        else if (statusInfo == 40)
        {
            return "40//雷管短路";
        }
        else if (statusInfo == 41)
        {
            return "41//雷管断路";
        }
        else if (statusInfo == 42)
        {
            return "42//内码错误";
        }
        else if (statusInfo == 2)
        {
            return "2//低压下正向电流大";
        }
        else if (statusInfo == 4)
        {
            return "4//低压下反向电流大";
        }
        else if (statusInfo == 21)
        {
            return "21//高压下正向电流大";
        }
        else if (statusInfo == 23)
        {
            return "23//高压下反向电流大";
        }
        else if (statusInfo == 8)
        {
            return "8//雷管类型错误";
        }
        else if (statusInfo == 9)
        {
            return "9//桥头短路";
        }
        else if (statusInfo == 11)
        {
            return "11//BIT错误";
        }
        else if (statusInfo == 12)
        {
            return "12//没有工作电容";
        }
        else if (statusInfo == 43)
        {
            return "43//雷管与条码不一致";
        }
        else if (statusInfo == 48)
        {
            return "48//内码不符合规则";
        }
        else if (statusInfo == 50)
        {
            return "43//序列码备份";
        }
}

void AllConfig::readConfig()
{
    QString runPth = QDir::currentPath();
    runPth += "/Config/";
    QDir dir(runPth);
    if(!dir.exists())
    {
        dir.mkdir(runPth);
    }
    runPth += "configPara.txt";

    QFile file(runPth);
    if(file.open(QIODevice::ReadOnly| QIODevice::Text))
    {
        QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
        QJsonObject obj = doc.object();
        qDebug()<<obj;
        file.close();

        m_produceConfig.factory = obj.value("工厂码").toInt(); //工厂码
        m_produceConfig.detType = obj.value("雷管类型").toInt(); //雷管类型
        m_produceConfig.feature = obj.value("特征码").toString().toLocal8Bit().at(0); //特征码
        m_produceConfig.productDate = obj.value("生产日期").toString();  //生产日期
        m_produceConfig.lineLength = obj.value("脚线长度").toInt(); //脚线长度
        m_produceConfig.numInBox = obj.value("盒内数量").toInt();  //盒内数量
        m_produceConfig.startBox = obj.value("起始盒号").toInt(); //起始盒号
        m_produceConfig.startNo  = obj.value("起始序号").toInt();  //起始序号
        m_produceConfig.produceNum = obj.value("生产数量").toInt();  //生产数量
        m_produceConfig.produceLineID = obj.value("机台号").toInt();  //生产数量

        m_produceConfig.channel_port = obj.value("检测仪端口号").toString();  //生产数量
        m_produceConfig.plc_ip = obj.value("PLC IP地址").toString();  //生产数量
        m_produceConfig.precheckCh_port = obj.value("半成品检端口号").toString();  //生产数量
        m_produceConfig.produceWritedNum = obj.value("已生产雷管").toInt();  //生产数量
    }

}

void AllConfig::saveConfig()
{
    QString runPth = QDir::currentPath();
    runPth += "/Config/";
    QDir dir(runPth);
    if(!dir.exists())
    {
        dir.mkdir(runPth);
    }
    runPth += "configPara.txt";


    QFile file(runPth);
    if(file.open(QIODevice::WriteOnly| QIODevice::Text))
    {
        QJsonObject obj;

        obj.insert("工厂码", m_produceConfig.factory);
        obj.insert("雷管类型", m_produceConfig.detType);
        QByteArray arr; arr.append(m_produceConfig.feature);
        obj.insert("特征码", QString(arr));
        obj.insert("生产日期", m_produceConfig.productDate);
        obj.insert("脚线长度", m_produceConfig.lineLength);
        obj.insert("盒内数量", m_produceConfig.numInBox);
        obj.insert("起始盒号", m_produceConfig.startBox);
        obj.insert("起始序号", m_produceConfig.startNo);
        obj.insert("生产数量", m_produceConfig.produceNum);
        obj.insert("机台号", m_produceConfig.produceLineID);
        obj.insert("检测仪端口号", m_produceConfig.channel_port);
        obj.insert("PLC IP地址", m_produceConfig.plc_ip);
        obj.insert("半成品检端口号", m_produceConfig.precheckCh_port);
        obj.insert("已生产雷管", m_produceConfig.produceWritedNum);

        qDebug()<<obj;
        QTime::currentTime();
        QJsonDocument doc; doc.setObject(obj);

        file.write(doc.toJson());

        file.close();
    }



}

QByteArray AllConfig::getPreviewOutCode()
{
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
    QDate date = QDate::fromString(cfg->productDate, "yyyy.MM.dd");

    QString codePrefix = QString("").asprintf("%02d%d%02d%02d%c",cfg->factory, date.year()%10,
                     date.month(), date.day(), cfg->feature);


    QByteArray outcode;

    outcode = codePrefix.toLocal8Bit()
            + QString("").asprintf("%03d%02d",
                                   (cfg->startBox + (cfg->startNo + cfg->produceWritedNum + 0)/cfg->numInBox)
                                   , ((cfg->startNo + cfg->produceWritedNum + 0)%cfg->numInBox) ).toLocal8Bit();

    return outcode;

}

struct ProduceConfigType* AllConfig::getProduceConfig()
{
    return &m_produceConfig;
}

