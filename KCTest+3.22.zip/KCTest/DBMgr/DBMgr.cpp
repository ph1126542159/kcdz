﻿#include "DBMgr.h"
#include <QtSql/QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QDir>
#include "ChannelProc.h"
#include <QMessageBox>

#define DB_PATH  ("C:/Users/lenovo/Desktop/KC/DetDB.db")
DBMgr::DBMgr()
{
    init();
}


void DBMgr::init()
{
    if(QSqlDatabase::contains("DetDB")){
        m_db = QSqlDatabase::database("DetDB");
        qDebug()<<"db = QSqlDatabase::database(\"DetDB\");";
    } else {
        m_db = QSqlDatabase::addDatabase("QSQLITE","DetDB");
        qDebug()<<"db = QSqlDatabase::addDatabase(\"QSQLITE\",\"DetDB\");";
    }

    QString DBPth = QDir::currentPath();
    DBPth += "/DB";
    QDir dir(DBPth);
    if(!dir.exists())
    {
        dir.mkdir(DBPth);
    }
    DBPth += "/DetDB.db";

    m_db.setDatabaseName(DBPth);
    if(!m_db.open()) {
        qDebug()<<"DB open failed!";
        return;
    }else {
        qDebug()<<"DB open success!";
    }

    createDetTable();

}

bool DBMgr::createDetTable()
{
    QSqlQuery query(m_db);
    int ret = query.exec("CREATE TABLE IF NOT EXISTS  DET_PRODUCE( ID INT PRIMARY KEY NOT NULL, \
                         TASKID VARCHAR(10), \
                         CODEPREFIX VARCHAR(10), \
                         OUTCODE VARCHAR(13) NOT NULL, \
                         BARCODE VARCHAR(14),\
                         INCODE  VARCHAR(16), \
                         PWD VARCHAR(8), \
                         CHANNEL INT NOT NULL, \
                         DET_TYPE  INT, \
                         STATUS_CODE INT, \
                         PRODUCTION_LINE_ID INT,\
                         LINE_LENGTH  INT,\
                         FACTORY INT,\
                         FEATURE VARCHAR(1),\
                         NO INT, \
                         DET_DATE DATE,\
                         PRODUCE_TIME  DATETIME NOT NULL\
                         );");
    qDebug()<<__FUNCTION__<<ret;
    return ret;
}


bool DBMgr::queryMaxID(int& maxID)
{
    QSqlQuery query(m_db);

    int ret = query.exec("SELECT MAX(ID) FROM DET_PRODUCE;");
    if(ret){
        while (query.next())
        {
            maxID = query.value("MAX(ID)").toInt();
        }
    }
    return ret;
}

//
bool DBMgr::insertDet(const struct DetInfo& det)
{
    int id = 0;
    queryMaxID(id);
    QString sql = QString("INSERT INTO DET_PRODUCE (\
                          ID, \
                          TASKID, \
                          CODEPREFIX,\
                          OUTCODE, \
                          BARCODE, \
                          INCODE, \
                          PWD, \
                          CHANNEL, \
                          DET_TYPE, \
                          STATUS_CODE, \
                          PRODUCTION_LINE_ID, \
                          LINE_LENGTH, \
                          FACTORY, \
                          FEATURE, \
                          NO, \
                          DET_DATE, \
                          PRODUCE_TIME) \
            VALUES (%0, \'%1\', \'%2\', \'%3\', \'%4\', \'%5\', \'%6\', %7, \'%8\', \'%9\', \'%10\', \'%11\', \'%12\', \'%13\', \'%14\', \'%15\' ,\'%16\');")
                    .arg(QString::number(id+1),
                         QString(det.taskId),
                         QString(det.codePrefix),
                         QString(det.outcode),
                         QString(det.barcode),
                         QString(det.incode),
                         QString(det.pwd),
                         QString::number(det.channel),
                         QString::number(det.detType),
                         QString::number(det.statusCode),
                         QString::number(det.productionLineID),
                         QString::number(det.lineLength),
                         QString::number(det.factory),
                         QString(det.feature),
                         QString::number(det.no),
                         det.detDate.toString("yyyy-MM-dd"),
                         det.produceTime.toString("yyyy-MM-dd hh:mm:ss") );
            QSqlQuery query(m_db);

    int ret = query.exec(sql);
    //qDebug()<<__FUNCTION__<<ret<<sql;
    return ret;
}


bool DBMgr::insertDets(const QList<struct DetInfo>& dets)
{
    int ret = false;
    for(int i = 0; i < dets.size(); i++)
    {
        ret |= insertDet(dets.at(i));
    }

    return ret;
}

bool DBMgr::queryDet(QList<struct DetInfo>& dets)
{
    int ret = 0;
    QSqlQuery query(m_db);

    ret = query.exec("SELECT * FROM DET_PRODUCE;");
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
//            det.outcode = query.value("ID").toByteArray();
//            det.outcode = query.value("OUTCODE").toByteArray();
//            det.outcode = query.value("BARCODE").toByteArray();
//            det.outcode = query.value("INCODE").toByteArray();
//            det.outcode = query.value("PWD").toByteArray();
//            det.outcode = query.value("CHANNEL").toByteArray();
//            det.outcode = query.value("DET_TYPE").toByteArray();
//            det.outcode = query.value("STATUS_CODE").toByteArray();
//            det.outcode = query.value("PRODUCTION_LINE_ID").toByteArray();
//            det.outcode = query.value("LINE_LENGTH").toByteArray();
//            det.outcode = query.value("FACTORY").toByteArray();
//            det.outcode = query.value("FEATURE").toByteArray();
//            det.outcode = query.value("DET_DATE").toByteArray();
//            det.outcode = query.value("PRODUCE_TIME").toByteArray();
              dets.append(det);
        }
    }

    qDebug()<<__FUNCTION__<<ret;
    return ret;
}

bool DBMgr::queryDet(QStandardItemModel* model)
{
    int ret = 0;
    QSqlQuery query(m_db);

    model->removeRows(0, model->rowCount());
    ret = query.exec("SELECT * FROM DET_PRODUCE;");
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
            det.ID = query.value("ID").toInt();
            det.outcode = query.value("OUTCODE").toByteArray();
            det.barcode = query.value("BARCODE").toByteArray();
            det.incode = query.value("INCODE").toByteArray();
            det.pwd = query.value("PWD").toByteArray();
            det.channel = query.value("CHANNEL").toInt();
            det.detType = query.value("DET_TYPE").toInt();
            det.statusCode = query.value("STATUS_CODE").toInt();
            det.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            det.lineLength = query.value("LINE_LENGTH").toInt();
            det.factory = query.value("FACTORY").toInt();
            det.feature = query.value("FEATURE").toByteArray().at(0);
            det.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            det.produceTime = QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");
            det.taskId = query.value("TASKID").toString();

            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(det.ID)),Qt::DisplayRole);
            items.append(item);

//            item = new QStandardItem();
//            item->setData(QVariant::fromValue(QString(det.taskId)),Qt::DisplayRole);
//            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.outcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.barcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.incode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.pwd)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("PRODUCE_TIME").toString()),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.channel),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.statusCode),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("NO").toString()),Qt::DisplayRole);
            items.append(item);

            model->appendRow(items);
        }
    }

    qDebug()<<__FUNCTION__<<ret;
    return ret;

}

bool DBMgr::queryDetNormalCode(QStandardItemModel *model)
{
    int ret = 0;
    int retd = 0;
    QSqlQuery query(m_db);

    model->removeRows(0, model->rowCount());
//    retd = query.exec("select distinct OUTCODE from DET_PRODUCE"); // 去重
    ret = query.exec("SELECT * FROM DET_PRODUCE WHERE STATUS_CODE = 0;");
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
            det.ID = query.value("ID").toInt();
            det.outcode = query.value("OUTCODE").toByteArray();
            det.barcode = query.value("BARCODE").toByteArray();
            det.incode = query.value("INCODE").toByteArray();
            det.pwd = query.value("PWD").toByteArray();
            det.channel = query.value("CHANNEL").toInt();
            det.detType = query.value("DET_TYPE").toInt();
            det.statusCode = query.value("STATUS_CODE").toInt();
            det.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            det.lineLength = query.value("LINE_LENGTH").toInt();
            det.factory = query.value("FACTORY").toInt();
            det.feature = query.value("FEATURE").toByteArray().at(0);
            det.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            det.produceTime = QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");

            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(det.ID)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.outcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.barcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.incode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.pwd)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("PRODUCE_TIME").toString()),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.channel),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.statusCode),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("NO").toString()),Qt::DisplayRole);
            items.append(item);

            model->appendRow(items);
        }
    }

    qDebug()<<__FUNCTION__<<ret;
    return ret;
}

bool DBMgr::queryDetByOutcode(int factory, QDate date, QByteArray feature, int start, int end, QStandardItemModel* model)
{
    int ret = 0;
    QSqlQuery query(m_db);

    model->removeRows(0, model->rowCount());
    QString sql = QString("SELECT * FROM DET_PRODUCE WHERE FACTORY = %0 AND DET_DATE = \'%1\' AND FEATURE = \'%2\' AND NO >= %3 AND NO <= %4;")
            .arg(QString::number(factory),
                 date.toString("yyyy-MM-dd"),
                 QString(feature),
                 QString::number(start),
                 QString::number(end));
    //qDebug()<<sql;
    ret = query.exec(sql);
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
            det.ID = query.value("ID").toInt();
            det.outcode = query.value("OUTCODE").toByteArray();
            det.barcode = query.value("BARCODE").toByteArray();
            det.incode = query.value("INCODE").toByteArray();
            det.pwd = query.value("PWD").toByteArray();
            det.channel = query.value("CHANNEL").toInt();
            det.detType = query.value("DET_TYPE").toInt();
            det.statusCode = query.value("STATUS_CODE").toInt();
            det.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            det.lineLength = query.value("LINE_LENGTH").toInt();
            det.factory = query.value("FACTORY").toInt();
            det.feature = query.value("FEATURE").toByteArray().at(0);
            det.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            det.produceTime = QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");

            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(det.ID)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.outcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.barcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.incode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.pwd)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("PRODUCE_TIME").toString()),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.channel),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.statusCode),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);


            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("NO").toString()),Qt::DisplayRole);
            items.append(item);

            model->appendRow(items);
        }
    }

    qDebug()<<__FUNCTION__<<ret;
    return ret;

}

bool DBMgr::queryDetByProduceTime(const QDateTime& start_time, const QDateTime& end_time, QStandardItemModel* model)
{
    int ret = 0;
    QSqlQuery query(m_db);

    model->removeRows(0, model->rowCount());
    QString sql = QString("SELECT * FROM DET_PRODUCE WHERE PRODUCE_TIME >= \'%0\' AND PRODUCE_TIME <= \'%1\';").arg(start_time.toString("yyyy-MM-dd hh:mm:ss"), end_time.toString("yyyy-MM-dd hh:mm:ss"));
    //qDebug() <<sql;
    ret = query.exec(sql);
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
            det.ID = query.value("ID").toInt();
            det.outcode = query.value("OUTCODE").toByteArray();
            det.barcode = query.value("BARCODE").toByteArray();
            det.incode = query.value("INCODE").toByteArray();
            det.pwd = query.value("PWD").toByteArray();
            det.channel = query.value("CHANNEL").toInt();
            det.detType = query.value("DET_TYPE").toInt();
            det.statusCode = query.value("STATUS_CODE").toInt();
            det.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            det.lineLength = query.value("LINE_LENGTH").toInt();
            det.factory = query.value("FACTORY").toInt();
            det.feature = query.value("FEATURE").toByteArray().at(0);
            det.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            det.produceTime = QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");

            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(det.ID)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.outcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.barcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.incode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.pwd)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("PRODUCE_TIME").toString()),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.channel),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.statusCode),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("NO").toString()),Qt::DisplayRole);
            items.append(item);

            model->appendRow(items);
        }
    }

   // qDebug()<<__FUNCTION__<<ret;
    return ret;
}

bool DBMgr::queryDetByErrorCode(QStandardItemModel* model)
{
    int ret = 0;
    QSqlQuery query(m_db);

    model->removeRows(0, model->rowCount());
    QString sql = QString("SELECT * FROM DET_PRODUCE WHERE STATUS_CODE != 0;");
    qDebug() <<sql;
    ret = query.exec(sql);
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
            det.ID = query.value("ID").toInt();
            det.outcode = query.value("OUTCODE").toByteArray();
            det.barcode = query.value("BARCODE").toByteArray();
            det.incode = query.value("INCODE").toByteArray();
            det.pwd = query.value("PWD").toByteArray();
            det.channel = query.value("CHANNEL").toInt();
            det.detType = query.value("DET_TYPE").toInt();
            det.statusCode = query.value("STATUS_CODE").toInt();
            det.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            det.lineLength = query.value("LINE_LENGTH").toInt();
            det.factory = query.value("FACTORY").toInt();
            det.feature = query.value("FEATURE").toByteArray().at(0);
            det.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            det.produceTime = QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");

            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(det.ID)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.outcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.barcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.incode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.pwd)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("PRODUCE_TIME").toString()),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.channel),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.statusCode),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("NO").toString()),Qt::DisplayRole);
            items.append(item);

            model->appendRow(items);
        }
    }

    qDebug()<<__FUNCTION__<<ret;
    return ret;
}

bool DBMgr::deleteDet(int ID)
{
    int ret = 0;
    QSqlQuery query(m_db);

    QString sql = QString("DELETE FROM DET_PRODUCE WHERE ID = %0;").arg(ID);
    qDebug() <<sql;
    ret = query.exec(sql);
    if(ret)
    {

    }

    return ret;
}

bool DBMgr::queryDetCountByTaskId(const QString &taskId, QStandardItemModel* model)
{
    int ret = 0;
    int retd = 0;
    QSqlQuery query(m_db);
    model->removeRows(0, model->rowCount());
//    retd = query.exec("select distinct OUTCODE from DET_PRODUCE"); // 去重
    QString sql = QString("SELECT * FROM DET_PRODUCE WHERE TASKID = \'%0\'").arg(QString(taskId));

    ret = query.exec(taskId);
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
            det.ID = query.value("ID").toInt();
            det.outcode = query.value("OUTCODE").toByteArray();
            det.barcode = query.value("BARCODE").toByteArray();
            det.incode = query.value("INCODE").toByteArray();
            det.pwd = query.value("PWD").toByteArray();
            det.channel = query.value("CHANNEL").toInt();
            det.detType = query.value("DET_TYPE").toInt();
            det.statusCode = query.value("STATUS_CODE").toInt();
            det.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            det.lineLength = query.value("LINE_LENGTH").toInt();
            det.factory = query.value("FACTORY").toInt();
            det.feature = query.value("FEATURE").toByteArray().at(0);
            det.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            det.produceTime = QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");

            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(det.ID)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.outcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.barcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.incode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.pwd)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("PRODUCE_TIME").toString()),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.channel),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.statusCode),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("NO").toString()),Qt::DisplayRole);
            items.append(item);

            model->appendRow(items);
        }
    }

    qDebug()<<__FUNCTION__<<ret;
    return ret;
}

bool DBMgr::queryDetCountByTaskIds(const QString &taskIds, QStandardItemModel *model)
{
    int ret = 0;
    int retd = 0;
    QSqlQuery query(m_db);
    model->removeRows(0, model->rowCount());
//    retd = query.exec("select distinct OUTCODE from DET_PRODUCE"); // 去重
    QString sql = "SELECT * FROM DET_PRODUCE WHERE TASKID in " + taskIds;
    ret = query.exec(sql);
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
            det.ID = query.value("ID").toInt();
            det.outcode = query.value("OUTCODE").toByteArray();
            det.barcode = query.value("BARCODE").toByteArray();
            det.incode = query.value("INCODE").toByteArray();
            det.pwd = query.value("PWD").toByteArray();
            det.channel = query.value("CHANNEL").toInt();
            det.detType = query.value("DET_TYPE").toInt();
            det.statusCode = query.value("STATUS_CODE").toInt();
            det.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            det.lineLength = query.value("LINE_LENGTH").toInt();
            det.factory = query.value("FACTORY").toInt();
            det.feature = query.value("FEATURE").toByteArray().at(0);
            det.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            det.produceTime = QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");

            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(det.ID)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.outcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.barcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.incode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.pwd)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("PRODUCE_TIME").toString()),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.channel),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.statusCode),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("NO").toString()),Qt::DisplayRole);
            items.append(item);

            model->appendRow(items);
        }
    }

    qDebug()<<__FUNCTION__<<ret;
    return ret;
}

bool DBMgr::queryDetCountByOutcodePrefix(const QString &PWD, int &detCount)
{
    QSqlQuery query(m_db);
    QString queryBeforeOutcode_sql = QString("SELECT count(*) FROM DET_PRODUCE WHERE TASKID=\'%0\'").arg(QString(PWD));
    detCount = query.exec(queryBeforeOutcode_sql);
    if (query.next())
    {
       detCount= query.value(0).toInt();
    }
    else
    {
        return false;
    }
    return detCount;
}

int DBMgr::queryDetCountByErrorCode(const QString &PWD)
{
    int detCount = 0;
    QSqlQuery query(m_db);
    QString queryBeforeOutcode_sql = QString("SELECT count(*) FROM DET_PRODUCE WHERE TASKID=\'%0\' AND STATUS_CODE != 0").arg(QString(PWD));
    detCount = query.exec(queryBeforeOutcode_sql);
    if (query.next())
    {
       detCount= query.value(0).toInt();
    }
    else
    {
        return false;
    }
    return detCount;
}

bool DBMgr::countDetbyCodePrefix(const QString &codePrefix)
{
    QSqlQuery query(m_db);
    int detCount;
    QString countCodePreFix_sql = QString("SELECT count(*) FROM DET_PRODUCE WHERE CODEPREFIX=\'%0\'").arg(QString(codePrefix));
    detCount = query.exec(countCodePreFix_sql);
    if (query.next())
    {
       detCount= query.value(0).toInt();
        return true;
    }
    else
    {
        return false;
    }
    return detCount;
}

int DBMgr::queryInitialSqlCheck(const QString &encipherRangeMin, const QString &encipherRangeMax)
{
    QString startout =  encipherRangeMin;
    QString endout =  encipherRangeMax;
    //工厂码 年 月 日 特征码  盒号 序号
    QByteArray array = startout.toLocal8Bit();
    int factory = (array.at(0)-'0') * 10 + (array.at(1)-'0');
    int year = (array.at(2)-'0');
    int month = (array.at(3)-'0') * 10 + (array.at(4)-'0');
    int day = (array.at(5)-'0') * 10 + (array.at(6)-'0');
    QByteArray featureArr; featureArr.append(array.at(7));

    int start = QString(array.mid(8, 5)).toInt();

    array = endout.toLocal8Bit();
    int end = QString(array.mid(8, 5)).toInt();

    QDate date;
    date.setDate(year + 2020, month, day);

    int ret = 0;
    QSqlQuery query(m_db);
    QString sql = QString("SELECT * FROM DET_PRODUCE WHERE FACTORY = %0 AND DET_DATE = \'%1\' AND FEATURE = \'%2\' AND NO >= %3 AND NO <= %4;")
            .arg(QString::number(factory),
                 date.toString("yyyy-MM-dd"),
                 QString(featureArr),
                 QString::number(start),
                 QString::number(end));
    //qDebug()<<sql;
    ret = query.exec(sql);
    int i = 0;
    if(ret)
    {
        while (query.next())
        {
            struct DetInfo det;
            det.ID = query.value("ID").toInt();
            det.outcode = query.value("OUTCODE").toByteArray();
            det.barcode = query.value("BARCODE").toByteArray();
            det.incode = query.value("INCODE").toByteArray();
            det.pwd = query.value("PWD").toByteArray();
            det.channel = query.value("CHANNEL").toInt();
            det.detType = query.value("DET_TYPE").toInt();
            det.statusCode = query.value("STATUS_CODE").toInt();
            det.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            det.lineLength = query.value("LINE_LENGTH").toInt();
            det.factory = query.value("FACTORY").toInt();
            det.feature = query.value("FEATURE").toByteArray().at(0);
            det.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            det.produceTime = QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");

            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(det.ID)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.outcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.barcode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.incode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(det.pwd)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("PRODUCE_TIME").toString()),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.channel),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.statusCode),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(det.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(query.value("NO").toString()),Qt::DisplayRole);
            items.append(item);
            i = items.size();
        }
    }
    qDebug()<<__FUNCTION__<<ret;
    return i;
}
