﻿#ifndef DBMGR_H
#define DBMGR_H

#include <QList>
#include <QByteArray>
#include <QDate>
#include <QString>
#include <QDateTime>
#include <QtSql/QSqlDatabase>
#include <QStandardItemModel>



struct Output{
    QDateTime produceTime;
    QByteArray outcode;
    QByteArray barcode;
    int detType;
    QByteArray incode;
};

class DBMgr
{
public:
    static DBMgr* instance(){
        static DBMgr* _single = new DBMgr();
        return _single;
    }

    void init();

    bool createDetTable();
    //
    bool queryMaxID(int& id);

    bool insertDet(const struct DetInfo& det);
    bool insertDets(const QList<struct DetInfo>& dets);
    bool insertDetTest();
    bool queryDet(QList<struct DetInfo>& dets);

    bool queryDet(QStandardItemModel* model);
    bool queryDetNormalCode(QStandardItemModel* model);
    bool queryDetByOutcode(int factory, QDate date, QByteArray feature, int start, int end, QStandardItemModel* model);
    bool queryDetByProduceTime(const QDateTime& start_time, const QDateTime& end_time, QStandardItemModel* model);

    bool queryDetByErrorCode(QStandardItemModel* model);


    bool deleteDet(int ID);

    QSqlDatabase m_db;

//    bool updateDetByOutCode(struct DetInfo& det);

//    bool queryDetByOutcodePrefix(const QByteArray& outcode_prefix/*管壳码前8位*/, QList<struct DetInfo>& dets);

//    bool queryDetCountByOutcode(const QByteArray& start_outcode, const QByteArray& end_outcode, int& detCount);
//    bool queryDetCountByProduceYear(const int year, int& detCount);
//    bool queryDetCountByProduceYearMonth(int year, int month, int& detCount);
//    bool queryDetCountByProduceDate(int year, int month, int day, int& detCount);
//    bool queryDetCountByProduceDate(QDate produce_date, int& detCount);
    bool queryDetCountByTaskId(const QString& taskId, QStandardItemModel* model);  //根据taskid查找
    bool queryDetCountByTaskIds(const QString& taskIds, QStandardItemModel* model);
    bool queryDetCountByOutcodePrefix(const QString& PWD, int& detCount);  // 计算已经生产数据
    int queryDetCountByErrorCode(const QString& PWD);   // 计算异常数据
    bool countDetbyCodePrefix(const QString& codePrefix);  // 查找是否存在codePrefix
    int queryInitialSqlCheck(const QString& encipherRangeMin, const QString& encipherRangeMax);

//    bool deleteDetBeforeProduceTime(const QDateTime time);

//    bool deleteDetByOutcode(const QByteArray& start_outcode, const QByteArray& end_outcode);
//    bool deleteDetByProduceTime(const QDateTime start_time, const QDateTime end_time);

//    bool deleteDetTable();

private:
    explicit DBMgr();


};

#endif // DBMGR_H
