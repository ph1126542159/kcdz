#ifndef DATAMANAGEMENT_H
#define DATAMANAGEMENT_H

#include <QList>
#include <QByteArray>
#include <QDate>
#include <QString>
#include <QDateTime>
#include <QtSql/QSqlDatabase>
#include "./DBMgr/DBMgr.h"
#include "ProductionSet.h"
#include "gen_excel_file.h"
#include <QStandardItemModel>


struct DetProductMission{
    int ID;
    QString taskId;
    QString codePrefix;
    int accomplishNum = 0;  // 已完成
    int detType = 1;
    int assignmentNum = 100;   // 任务数量
    int abnormalNum = 0;  // 异常数量
    int produceStage = 3; //生产环节
    int factory = 0; //工厂码
    int lineLength = 10; //脚线长度
    int cntboxInPack = 5; //箱内数量
    int startBox = 0; //起始盒号
    int startNo = 0;  //起始序号
    int produceNum = 0;  //生产数量
    int channel = 0; //通道数
    int detcoreType = 0; //芯片类型
    int productionLineID = 0; //机台号
    int produceWritedNum = 0;
    int lotNum = 0; // 批号
    QString statusCode = "未开始"; // 状态
    QString productStatus = "未开始";   //生产状态
    int pwd = 0;
    int no = 0;
    int numberInBox = 5; // 盒内数
    QByteArray outcodePrefix = 0; //管码前8位
    QByteArray outCode = "111111";
    QByteArray incode = "2";
    QByteArray barcode = " 987979";
    QString staff = ""; // 工作人员
    QString produceComment = "无"; // 备注
    QString encipherRange = "321852"; // 编码范围

    uchar feature; //特征码
    QDate detDate;
    QDateTime produceTime =  QDateTime::currentDateTime();  //生产日期
    QString productDate = produceTime.toString("yyyy-MM-dd");


    QString channel_port;
    QString plc_ip;
    QString precheckCh_port;
};

class DataManagement
{
public:
    static DataManagement* instance(){
        static DataManagement* _single = new DataManagement();
        return _single;
    }

    void init();
    void CreateDatabaseFunc(); //创建SQLite数据库
    void CreateTableFunc(); // 创建SQLite数据表  任务列表
    bool queryMaxID(int& id);
    bool queryDetByOutcode(int factory, QDate date, QByteArray feature, int start, int end, QStandardItemModel* model);
    bool queryDetByProduceTime(const QDateTime& start_time, const QDateTime& end_time, QStandardItemModel* model);
    bool uploadSelectedData();  // 上传被选中的数据
    bool exportRecord();  // 导出记录
    bool assignmentDone(); //任务已完成
    bool exportDetCodeRecord(); // 导出管码记录
    bool insertDetProduceData(struct DetProductMission& detProduct);
    bool queryDetByOutcodePrefix(const QByteArray& PWD, QList<struct DetInfo>& dets, int &detCount);
    bool queryFindException(struct DetProductMission& detProduct, int &detCount); // 查找异常数
    bool queryQuantityProduced(struct DetProductMission& detProduct, int &detCount);  // 查找已经生产的数量
    bool deleteDet(int ID);  //删除生产数据
    bool countDetbyCodePrefix(const QString& codePrefix);  // 查找是否存在codePrefix
    bool queryDetProductMission(QStandardItemModel* model); // 查询生产任务
    bool updataProductedMission(const QString &PWD, int &accomplishNum);  //更新完成度
    bool updataProductMissionState(const QString &PWD, QString &productStatus);  //更新生产状态
    int queryProductedNum(const QString &taskId); // 查找当前任务数
    int queryProductedTotalNum(); //查找总的任务数
    int queryHasProducedTotalNum(); //查找已经生产的总数
public slots:
      void insertDetProduceDataTest();  // 新增任务
private:
    explicit DataManagement();
    QSqlDatabase m_sqldb; // 创建数据库连接

};
#endif // DATAMANAGEMENT_H
