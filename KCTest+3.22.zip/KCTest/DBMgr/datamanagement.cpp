#include "datamanagement.h"
#include <QString>
#include <QApplication>
#include <QDebug>
#include <QVariant>
#include <QSqlTableModel>
#include <QTableView>
#include <QMessageBox>
#include <QSqlQuery>
#include <QDir>
#include "DBMgr.h"
#include "AllConfig.h"


DataManagement::DataManagement()
{
     CreateDatabaseFunc();
     CreateTableFunc();
}

void DataManagement::CreateDatabaseFunc()
{
    if(QSqlDatabase::contains("DetDB")){
        m_sqldb = QSqlDatabase::database("DetDB");
    } else {
        m_sqldb = QSqlDatabase::addDatabase("QSQLITE","DetDB");
    }

    QString DBPth = QDir::currentPath();
    DBPth += "/DB";
    QDir dir(DBPth);
    if(!dir.exists())
    {
        dir.mkdir(DBPth);
    }
    DBPth += "/DetDB.db";

    m_sqldb.setDatabaseName(DBPth);
    //3: 打开数据库是否成功
    if(m_sqldb.open()==true)
    {
//       QMessageBox::information(0,"正确","恭喜你，数据库连接打开成功！",QMessageBox::Ok);
    }
    else
    {
//       QMessageBox::critical(0,"错误","数据库连接打开失败！",QMessageBox::Ok);
    }
}

void DataManagement::CreateTableFunc()
{
    QSqlQuery query = QSqlQuery(m_sqldb);
    // 创建SQL语句
    QString dataSheel = "create table productDetData20 (id integer primary key ,  TASKID CHAR(10), CODEPREFIX CHAR(10), OUTCODE CHAR(13),  encipherRange CHAR(2),  PRODUCE_TIME DATETIME, INCODE CHAR(16), PWD CHAR(8), STATUS_CODE CHAR(10),  assignmentNum int,accomplishNum INT, abnormalNum CHAR(30),  lotNum CHAR(50),   staff CHAR(50), produceComment CHAR(50),\
            BARCODE CHAR(13),\
            DET_TYPE CHAR(13), \
            PRODUCTION_LINE_ID CHAR(13), \
            LINE_LENGTH CHAR(13), \
            FACTORY CHAR(13), \
            FEATURE CHAR(13), \
            NO CHAR(13), \
            CHANNEL CHAR(13),\
            DET_DATE CHAR(13),\
            numberInBox CHAR(13),\
            startBox CHAR(13),\
            startNo CHAR(13))";
    // 执行SQL语句
    query.prepare(dataSheel);
    int ret = query.exec();
    if(!ret)
    {
//       QMessageBox::critical(0,"失败","数据表创建失败，请重新检查",QMessageBox::Ok);
    }
    else
    {
//       QMessageBox::information(0,"成功","数据表创建成功",QMessageBox::Ok);
    }
}

bool DataManagement::queryMaxID(int& maxID)
{
    QSqlQuery query = QSqlQuery(m_sqldb);

    int ret = query.exec("SELECT MAX(ID) FROM productDetData20;");
    if(ret){
        while (query.next())
        {
            maxID = query.value("MAX(ID)").toInt();
        }
    }
    return ret;
}

bool DataManagement::insertDetProduceData(struct DetProductMission& detProduct)
{
    struct ProduceConfigType* config = AllConfig::instance()->getProduceConfig();
    detProduct.taskId = AllConfig::instance()->randString();
    int id = 0;
    queryMaxID(id);
    QSqlQuery query = QSqlQuery(m_sqldb);
    QString insert_sql = QString("INSERT INTO productDetData20 (\
                                 ID,\
                                 TASKID,\
                                 CODEPREFIX,\
                                 OUTCODE,\
                                 encipherRange,\
                                 PRODUCE_TIME, \
                                 INCODE, \
                                 PWD, \
                                 STATUS_CODE,\
                                 assignmentNum,\
                                 accomplishNum, \
                                 abnormalNum,\
                                 lotNum,\
                                 staff, \
                                 produceComment,\
                                 BARCODE,\
                                 DET_TYPE, \
                                 PRODUCTION_LINE_ID, \
                                 LINE_LENGTH, \
                                 FACTORY, \
                                 FEATURE, \
                                 NO, \
                                 CHANNEL,\
                                 DET_DATE,\
                                 numberInBox,\
                                 startBox,\
                                 startNo) \
                               VALUES (\'%1', \'%2\', \'%3\', \'%4\', \'%5\', \'%6\', \'%7\', \'%8\', \'%9\', \'%10\', \'%11\', \'%12\',\'%13\',\'%14\',\'%15\',\'%16\',\'%17\',\'%18\',\'%19\',\'%20\',\'%21\',\'%22\',\'%23\',\'%24\',\'%25\',\'%26\',\'%27\')")
                                 .arg(QString::number(id+1),
                                      QString(detProduct.taskId),
                                      QString(detProduct.codePrefix),
                                      QString(detProduct.outCode),
                                      QString(detProduct.encipherRange),
                                      detProduct.produceTime.toString("yyyy-MM-dd hh:mm:ss"),
                                      QString(detProduct.incode),
                                      QString::number(detProduct.pwd),
                                      QString(detProduct.productStatus),
                                      QString::number(detProduct.assignmentNum),
                                      QString::number(detProduct.accomplishNum),
                                      QString::number(detProduct.abnormalNum),
                                      QString::number(detProduct.lotNum),
                                      QString(detProduct.staff),
                                      QString(detProduct.produceComment),
                                      QString(detProduct.barcode),
                                      QString::number(detProduct.detType),
                                      QString::number(detProduct.productionLineID),
                                      QString::number(detProduct.lineLength),
                                      QString::number(detProduct.factory),
                                      QString(detProduct.feature),
                                      QString::number(detProduct.no),
                                      QString::number(detProduct.channel),
                                      detProduct.productDate,
                                      QString::number(detProduct.numberInBox),
                                      QString::number(detProduct.startBox),
                                      QString::number(detProduct.startNo));
    query.prepare(insert_sql);
    int ret = query.exec();
    if(!ret)
    {
       QMessageBox::critical(0,"失败","任务新增失败，请重新检查",QMessageBox::Ok);
    }
    else
    {
       QMessageBox::information(0,"成功","任务新增成功",QMessageBox::Ok);
    }
}

void DataManagement::insertDetProduceDataTest()
{
    QSqlQuery query = QSqlQuery(m_sqldb);
    QString insert_sqlT = QString("INSERT INTO productDetData20 (ID,\
                                 OUTCODE,\
                                 CHANNEL,\
                                 PRODUCE_TIME, \
                                 INCODE, \
                                 PWD, \
                                 STATUS_CODE,\
                                 assignmentNum,\
                                 accomplishNum, \
                                 encipherRange, \
                                 abnormalNum,\
                                 lotNum,\
                                 staff, \
                                 produceComment,\
                                 BARCODE,\
                                 DET_TYPE, \
                                 PRODUCTION_LINE_ID, \
                                 LINE_LENGTH, \
                                 FACTORY, \
                                 FEATURE, \
                                 NO, \
                                 DET_DATE) VALUES (%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12,%13,%14,%15,%16,%17,%18,%19,%20,%21)")\
                                 .arg(("990")).arg(QString("2")).arg(QString("3")).arg(QString("4"))\
                                 .arg(QString("3")).arg(QString("3")).arg(QString("3")).arg(QString("0"))\
                                 .arg(QString("3")).arg(QString("4")).arg(QString("5")).arg(QString("0")).arg(QString("0"));

    query.prepare(insert_sqlT);
    int ret = query.exec();
    if(!ret)
    {
       QMessageBox::critical(0,"失败","数据新增失败，请重新检查",QMessageBox::Ok);
    }
    else
    {
       QMessageBox::information(0,"成功","数据新增成功",QMessageBox::Ok);
    }
}

bool DataManagement::queryDetByOutcodePrefix(const QByteArray &PWD, QList<DetInfo> &dets, int &detCount)
{
    QSqlQuery query(m_sqldb);
    QString queryBeforeOutcode_sql = QString("SELECT count(*) FROM productDetData20 WHERE PWD=\'%0\'").arg(QString(PWD));
    detCount = query.exec(queryBeforeOutcode_sql);
    if (query.next())
    {
       detCount= query.value(0).toInt();
       return true;
    }
    else
    {
        QMessageBox::critical(0,"失败","数据计数失败，请重新检查",QMessageBox::Ok);
        return false;
    }
    return detCount;
}

bool DataManagement::queryDetProductMission(QStandardItemModel* model)
{
    int ret = 0;
    QSqlQuery query(m_sqldb);

    model->removeRows(0, model->rowCount());
    ret = query.exec("SELECT * FROM productDetData20;");
    if(ret)
    {
        while (query.next())
        {
            struct DetProductMission detProduct;
            detProduct.ID = query.value("ID").toInt();
            detProduct.taskId = query.value("TASKID").toString();
            detProduct.outCode = query.value("OUTCODE").toByteArray();
            detProduct.encipherRange = query.value("encipherRange").toByteArray();
            detProduct.assignmentNum = query.value("assignmentNum").toInt();
            detProduct.accomplishNum = query.value("accomplishNum").toInt();
            detProduct.abnormalNum = query.value("abnormalNum").toInt();
            detProduct.produceTime =  QDateTime::fromString(query.value("PRODUCE_TIME").toString(), "yyyy-MM-dd hh:mm:ss");
            detProduct.lineLength = query.value("LINE_LENGTH").toInt();
            detProduct.lotNum = query.value("lotNum").toInt();
            detProduct.staff = query.value("staff").toByteArray();
            detProduct.productStatus = query.value("STATUS_CODE").toString();
            detProduct.produceComment = query.value("produceComment").toByteArray();

            detProduct.pwd = query.value("PWD").toInt();
            detProduct.detType = query.value("DET_TYPE").toInt();
            detProduct.factory = query.value("FACTORY").toInt();
            detProduct.feature = query.value("FEATURE").toByteArray().at(0);
            detProduct.numberInBox = query.value("numberInBox").toInt();
            detProduct.startBox = query.value("startBox").toInt();
            detProduct.startNo = query.value("startNo").toInt();
            detProduct.productionLineID = query.value("PRODUCTION_LINE_ID").toInt();
            detProduct.detDate = QDate::fromString(query.value("DET_DATE").toString(), "yyyy-MM-dd");
            detProduct.codePrefix = query.value("CODEPREFIX").toString();
            qDebug() << detProduct.detDate << detProduct.produceTime <<query.value("DET_DATE").toString() << query.value("PRODUCE_TIME").toString() <<"555555555555555";
            QList<QStandardItem*> items;
            QStandardItem* item;

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString::number(detProduct.ID)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(detProduct.taskId)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(detProduct.outCode)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(detProduct.encipherRange)),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.assignmentNum),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.accomplishNum),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.abnormalNum),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.produceTime.toString("yyyy-MM-dd")),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.lineLength),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.lotNum),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.staff),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.productStatus),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.produceComment),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.pwd),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.detType),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.factory),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.feature),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.numberInBox),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.startBox),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.startNo),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.productionLineID),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(detProduct.detDate),Qt::DisplayRole);
            items.append(item);

            item = new QStandardItem();
            item->setData(QVariant::fromValue(QString(detProduct.codePrefix)),Qt::DisplayRole);
            items.append(item);
            model->appendRow(items);
        }
    } else
    {
        QMessageBox::critical(0,"失败","数据查询失败，请重新检查",QMessageBox::Ok);
    }
    qDebug()<<__FUNCTION__<<ret;
    return ret;
}

bool DataManagement::updataProductedMission(const QString &PWD, int &accomplishNum)
{
     int ret = 0;
     QSqlQuery query(m_sqldb);
     QString sql = QString("UPDATE productDetData20 SET accomplishNum = \'%0\' WHERE TASKID = \'%1\'").arg(QString::number(accomplishNum), QString(PWD));
     qDebug() <<sql;
     ret = query.exec(sql);
     if(ret)
     {

     }

     return ret;
}

bool DataManagement::updataProductMissionState(const QString &PWD, QString &productStatus)
{
    int ret = 0;
    QSqlQuery query(m_sqldb);
    QString sql = QString("UPDATE productDetData20 SET STATUS_CODE = \'%0\' WHERE TASKID = \'%1\'").arg(QString(productStatus), QString(PWD));
    ret = query.exec(sql);
    if(ret)
    {

    }

    return ret;
}

int DataManagement::queryProductedNum(const QString &taskId)
{
    int ret = 0;
    int produceNum = 0;
    QSqlQuery query(m_sqldb);
    QString queryProductedNum_sql = QString("SELECT FROM productDetData20 WHERE TASKID=\'%0\'").arg(QString(taskId));
    ret = query.exec(queryProductedNum_sql);
    if(ret)
    {
        while (query.next())
        {
            produceNum = query.value("accomplishNum").toInt();
        }
    }
    return produceNum;
}

int DataManagement::queryProductedTotalNum()
{
    int productedTotalNum = 0 ;
    int ret =0;
    QSqlQuery query(m_sqldb);
    QString queryProductedTotalNum_sql = QString("SELECT * FROM productDetData20");
    ret = query.exec(queryProductedTotalNum_sql);
    qDebug() << ret << "231131";
    if(ret)
    {
        while (query.next())
        {
            productedTotalNum = productedTotalNum + query.value("assignmentNum").toInt();
        }
    }
    return productedTotalNum;
}

int DataManagement::queryHasProducedTotalNum()
{
    int queryHasProductedTotalNum = 0 ;
    int ret =0;
    QSqlQuery query(m_sqldb);
    QString queryProductedTotalNum_sql = QString("SELECT * FROM productDetData20");
    ret = query.exec(queryProductedTotalNum_sql);
    if(ret)
    {
        while (query.next())
        {
            queryHasProductedTotalNum = queryHasProductedTotalNum + query.value("accomplishNum").toInt();
        }
    }
    return queryHasProductedTotalNum;
}

bool DataManagement::deleteDet(int ID)
{
    int ret = 0;
    QSqlQuery query(m_sqldb);

    QString sql = QString("DELETE FROM productDetData20 WHERE ID = %0;").arg(ID);
    qDebug() <<sql;
    ret = query.exec(sql);
    if(ret)
    {

    }

    return ret;
}

bool DataManagement::countDetbyCodePrefix(const QString &codePrefix)
{
    QSqlQuery query(m_sqldb);
    int detCount;
    QString countCodePreFix_sql = QString("SELECT count(*) FROM productDetData20 WHERE encipherRange=\'%0\'").arg(QString(codePrefix));
    detCount = query.exec(countCodePreFix_sql);
    if (query.next())
    {
       detCount= query.value(0).toInt();
    }
    else
    {
        return false;
    }
    qDebug() << detCount << "111111111";
    return detCount;
}


