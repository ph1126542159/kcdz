﻿#include "KLog.h"
#include <QString>
#include <QDir>
#include <QFile>
#include <QDateTime>
#include <QDebug>
#include <QThread>
#include <QDebug>
#include "MainWindow.h"

KLog::KLog(QObject *parent) : QObject(parent)
{

}

KLog::~KLog()
{
    logfile.close();
}

void KLog::init(QString logName)
{
    QString runPth = QDir::currentPath();
    runPth += "/Log/";
    QDir dir(runPth);
    if(!dir.exists())
    {
        dir.mkdir(runPth);
    }
    runPth += logName + QDateTime::currentDateTime().toString("yyyy-MM-dd hh-mm-ss") + ".txt";

    logfile.setFileName(runPth);
    if(logfile.open(QIODevice::ReadWrite| QIODevice::Text))
    {
        qDebug()<<"logfile open OK";
    }

    connect(this, &KLog::sigLog, MainWindow::instance(), &MainWindow::slot_writeLog, Qt::QueuedConnection);
}

void KLog::write(QString msg)
{
    QString time = QDateTime::currentDateTime().toString("[yyyy-MM-dd hh:mm:ss.zzz]");
    QString mm = time+ QString().asprintf("%p", QThread::currentThreadId())+ " " + msg;
    QString msg2 = mm+  + "\n";
    logfile.write(msg2.toLocal8Bit());
    logfile.flush();

    emit sigLog(mm);
}


