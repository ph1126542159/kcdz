﻿#ifndef KLOG_H
#define KLOG_H

#include <QString>
#include <QDir>
#include <QFile>
#include <QDateTime>
#include <QObject>


class KLog: public QObject
{
    Q_OBJECT
public:
    explicit KLog(QObject *parent = nullptr);

    ~KLog();

    void init(QString logName);

    void write(QString msg);

signals:
    void sigLog(QString msg);

private:
    QFile logfile;
};

#endif // KLOG_H
