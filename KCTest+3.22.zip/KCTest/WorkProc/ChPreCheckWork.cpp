﻿#include "ChPreCheckWork.h"
#include "AllConfig.h"

#define LOG_DEBUG(s)   mlog->write(s)


ChPreCheckWork::ChPreCheckWork(QObject *parent) : QObject(parent)
{
    mlog = new KLog();
    mlog->init("CHPRECHECK_LOG");
    mlog->write("CHPRECHECK_LOG inited");

     m_chPreCheck = new ChannelCmd();
    int ret = m_chPreCheck->init(AllConfig::instance()->getProduceConfig()->precheckCh_port, 57600);
    if(!ret){
        LOG_DEBUG(QStringLiteral("串口初始化失败"));
    }else{
        LOG_DEBUG(QStringLiteral("串口初始化成功"));
    }
    //半成品检测指令 01100000002346003030303030303030303030303000303030303030303030303030300030303030303030303030303030003030303030303030303030303000303030303030303030303030307255

    //读取检测结果指令1通道 0103010000144439

    //成品写码指令 0110000000234630353233303230334530303030313035323330323033453030303032303532333032303345303030303330353233303230334530303030343035323330323033453030303035221b
//    m_chPreCheck->startCheck();
//    ushort ch = 0;
//    ushort checkRslt = 0;
//    QByteArray incode;
//    QByteArray pwd;
//    uchar detType = 0;
//    QByteArray outcode;
//    checkRslt = 0xFF;
//     ret = m_chPreCheck->readCheckRslt(1, ch, checkRslt,incode, pwd, detType, outcode);

//    QByteArray outcodes;

//        outcodes.append("05230203E00001");
//        outcodes.append("05230203E00002");
//        outcodes.append("05230203E00003");
//        outcodes.append("05230203E00004");
//        outcodes.append("05230203E00005");

//        m_chPreCheck->startWriteCode(outcodes);
}


void ChPreCheckWork::doWorkPreCheck()
{
    uchar rsltAll = 0;
    PreCheck(rsltAll);
    emit finished_PreCheck(rsltAll);
}

bool ChPreCheckWork::PreCheck(uchar& rsltAll)
{
    LOG_DEBUG(QString(QStringLiteral("开始半成品检")));
    LOG_DEBUG(QString(QStringLiteral("串口发送检测指令")));
    int ret = m_chPreCheck->startCheck();
    if(-1 == ret){
        LOG_DEBUG(QStringLiteral("串口发送检测指令失败"));
    }else if(0 == ret){
        LOG_DEBUG(QStringLiteral("串口接收数据超时"));
    }else{
        QString msg = QString("SERIL RECV: %0").arg(ret);
        LOG_DEBUG(msg);
    }
    if(ret)
    {
        for(int i = 0; i < 5; i++)
        {
            int channel = i +1;

            ushort ch = 0;
            ushort checkRslt = 0;
            QByteArray incode;
            QByteArray pwd;
            uchar detType = 0;
            QByteArray outcode;

            checkRslt = 0xFF;
            int ret = m_chPreCheck->readCheckRsltTimeout(channel, 5000, ch, checkRslt,incode, pwd, detType, outcode);
            if(-1 == ret){
                LOG_DEBUG(QStringLiteral("串口发送数据失败"));
            }else if(0 == ret){
                LOG_DEBUG(QStringLiteral("串口接收数据超时"));
            }else{
                QString msg = QString("SERIL RECV: %0").arg(ret);
                LOG_DEBUG(msg);
            }
            if(checkRslt == 0x00){
                rsltAll = rsltAll |(1<<(i));
            }

            LOG_DEBUG(QString("Channel:%0 CheckRslt:%1 CH:%2").arg(channel).arg(checkRslt).arg(ch));
        }
    }
    LOG_DEBUG(QString(QStringLiteral("完成半成品检")));

    return true;
}

