﻿#ifndef CHANNELPROC_H
#define CHANNELPROC_H

#include <QObject>
#include "ULog/KLog.h"
#include "ChannelCmd.h"
#include <QMutex>
#include <QMutexLocker>

struct DetInfo{
    int ID;
    QString taskId;
    QString codePrefix = "0";
    QByteArray outcode;
    QByteArray incode;
    QByteArray pwd;
    QByteArray barcode;
    int detType;
    ushort statusCode;
    int channel;
    int productionLineID;
    int lineLength;
    int factory;
    uchar feature;
    int no;
    QDate detDate;
    QDateTime produceTime;
};

class ChannelProc : public QObject
{
    Q_OBJECT
public:
    static ChannelProc* instance();
    ~ChannelProc();


    bool readDetData(struct DetInfo* dets);

private:
    bool WriteCode(const QList<QByteArray>& outcodes);


public slots:
    void doWorkWriteCode(const QList<QByteArray> outcodes);

signals:
    void finished_WriteCode();

private:
    explicit ChannelProc(QObject *parent = nullptr);


    KLog* mlog;
    ChannelCmd* m_chWriteCode;

    QMutex m_lock;
    bool valid;
    struct DetInfo m_detInfo[5];

};

#endif // CHANNELPROC_H
