﻿#ifndef CHPRECHECKWORK_H
#define CHPRECHECKWORK_H

#include <QObject>
#include "ULog/KLog.h"
#include "ChannelCmd.h"
#include <QMutex>
#include <QMutexLocker>

class ChPreCheckWork : public QObject
{
    Q_OBJECT
public:
    explicit ChPreCheckWork(QObject *parent = nullptr);

private:
    bool PreCheck(uchar& rslt);

public slots:
    void doWorkPreCheck();

signals:
    void finished_PreCheck(uchar rslt);

private:
    KLog* mlog;

    ChannelCmd* m_chPreCheck;
};

#endif // CHPRECHECKWORK_H
