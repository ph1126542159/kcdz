﻿#include "PlcPreCheckProc.h"
#include <QTime>
#include <QEventLoop>
#include "AllConfig.h"
#include "ULog/ulog.h"
#include "ULog/KLog.h"

#define IP_PORT  9600


#define LOG_DEBUG(s)   mlog->write(s)


static void Delay(int msec){
    QEventLoop loop;
    QTimer::singleShot(msec, &loop,SLOT(quit()));
    loop.exec();
}

PlcPreCheckProc::PlcPreCheckProc(QObject *parent) : QThread(parent),
    m_isRunning(false)
{

}

void PlcPreCheckProc::init()
{
    m_heart = 0;
    m_startPreCheck = false;
    m_reset = false;

    m_plCcmd = new PLCCmd();
    m_plCcmd->init(AllConfig::instance()->getProduceConfig()->plc_ip, IP_PORT, 0x89);

    m_chCmd = new ChannelCmd();
    m_chCmd->init(AllConfig::instance()->getProduceConfig()->precheckCh_port, 57600);

    mlog = new KLog();
    mlog->init("PRECHECK_LOG_");
    mlog->write("PlcPreCheckProc inited");

    qDebug()<<"PlcPreCheckProc Thread Info: "<<QThread::currentThreadId()<<QThread::currentThread();
}

void PlcPreCheckProc::startProduce()
{
    m_isRunning = true;
    qDebug() << "ppppppppppp";
    LOG_DEBUG(QString(QStringLiteral("半成品检启动生产")));
    qDebug()<<"startProduce : "<<QThread::currentThreadId()<<QThread::currentThread();
}

void PlcPreCheckProc::stopProduce()
{
    m_isRunning = false;
    qDebug() << "ppppppppppp";
    LOG_DEBUG(QString(QStringLiteral("半成品检停止生产")));

    qDebug()<<"stopProduce : "<<QThread::currentThreadId()<<QThread::currentThread();
}


void PlcPreCheckProc::run()
{
    static int plcDisConnectCnt = 0;
    init();
    while(1){

        int ret = m_plCcmd->isConnected();
        if(!ret){
            plcDisConnectCnt++;
            if(plcDisConnectCnt==1){
                LOG_DEBUG(QStringLiteral("PLC连接失败"));
                LOG_DEBUG(QString("tcpConnect = %0, finsConnect = %1 functionCode = %2").arg(m_plCcmd->m_tcpConnect).arg(m_plCcmd->m_finsConnect).arg(m_plCcmd->m_funcCode));
            }
        }
        else
        {
            plcDisConnectCnt = 0;

            if(m_isRunning)
            {
                do_PreCheck();
                qDebug()<<"PlcPreCheckProc : "<<QThread::currentThreadId()<<QThread::currentThread();
            }else{
                m_plCcmd->PreCheck_WriteHeart(m_sndheart);
            }
        }
        msleep(50);
    }
}


void PlcPreCheckProc::do_PreCheck()
{

    int heart;
    bool startPreCheck;
    bool reset;

    int rsltAll = 0;

    int ret = m_plCcmd->PreCheck_Read(heart, startPreCheck, reset);
    if(ret){
        if(heart != m_heart){
        }

        if((startPreCheck != m_startPreCheck)&&(startPreCheck == true))
        {
            m_sndheart = 0;
            m_enPreCheck = true;
            m_recvCheck = true;
            m_finished = false;
            m_rslt = 0;

            LOG_DEBUG(QString(QStringLiteral("收到PLC半成品检指令")));
            m_plCcmd->PreCheck_Write(m_sndheart, m_enPreCheck, m_recvCheck, m_finished, m_rslt);

            LOG_DEBUG(QString(QStringLiteral("开始半成品检")));
            ret = m_chCmd->startCheck();
            if(ret)
            {
                for(int i = 0; i < 5; i++)
                {
                    int channel = i +1;

                    ushort ch = 0;
                    ushort checkRslt = 0;
                    QByteArray incode;
                    QByteArray pwd;
                    uchar detType = 0;
                    QByteArray outcode;

                    checkRslt = 0xFF;
                    int ret = m_chCmd->readCheckRsltTimeout(channel, 10000, ch, checkRslt,incode, pwd, detType, outcode);
                    if(!ret){
                        qDebug()<<"serial connect failed";
                        LOG_DEBUG(QStringLiteral("读通道超时Timeout"));
                    }
                    if(checkRslt == 0x00){
                        rsltAll = rsltAll |(1<<(i));
                    }

                    LOG_DEBUG(QString("Channel:%0 CheckRslt:%1 CH:%2").arg(channel).arg(checkRslt).arg(ch));

                    qDebug()<<"channel precheck rslt = "<<channel<<(int)rsltAll<<checkRslt<<ch;
                }
            }
            LOG_DEBUG(QString(QStringLiteral("完成半成品检")));


            m_sndheart = 0;
            m_enPreCheck = true;
            m_recvCheck = true;
            m_finished = true;
            m_rslt = rsltAll;

            m_plCcmd->PreCheck_Write(m_sndheart, m_enPreCheck, m_recvCheck, m_finished, m_rslt);
            LOG_DEBUG(QString(QStringLiteral("回复PLC完成半成品检")));

        }

        if((reset != m_reset)&&(reset == true))
        {
            m_sndheart = 0;
            m_enPreCheck = true;
            m_recvCheck = false;
            m_finished = false;
            m_rslt = 0;
            LOG_DEBUG(QString(QStringLiteral("收到PLC复位指令")));

            m_plCcmd->PreCheck_Write(m_sndheart, m_enPreCheck, m_recvCheck, m_finished, m_rslt);
        }

        m_heart = heart;
        m_startPreCheck = startPreCheck;
        m_reset = reset;
    }
    else{
        LOG_DEBUG(QString(QStringLiteral("读数据失败")));
        LOG_DEBUG(QString("tcpConnect = %0, finsConnect = %1 functionCode = %2").arg(m_plCcmd->m_tcpConnect).arg(m_plCcmd->m_finsConnect).arg(m_plCcmd->m_funcCode));
        LOG_DEBUG(QStringLiteral("PORT %0").arg(m_plCcmd->getSocketPort()));
    }

    //LOG_DEBUG(QString(QStringLiteral("发送心跳")));
    m_plCcmd->PreCheck_WriteHeart(m_sndheart);
}
