﻿#include "ChannelProc.h"
#include <QDebug>
#include "AllConfig.h"
#include <QMutex>
#include <QMutexLocker>


#define LOG_DEBUG(s)   mlog->write(s)


static ChannelProc* _single = NULL;

ChannelProc::ChannelProc(QObject *parent) : QObject(parent)
{
    mlog = new KLog();
    mlog->init("CHWRITECODE_LOG_");
    mlog->write("CHWRITECODE_LOG inited");

    m_chWriteCode = new ChannelCmd();
    int ret = m_chWriteCode->init(AllConfig::instance()->getProduceConfig()->channel_port, 57600);
    if(!ret){
        LOG_DEBUG(QStringLiteral("串口初始化失败"));
    }else{
        LOG_DEBUG(QStringLiteral("串口初始化成功"));
    }
}

ChannelProc::~ChannelProc()
{
    if(_single != NULL){
        delete  _single;
        _single = NULL;
    }

}

ChannelProc* ChannelProc::instance(){
    if(_single == NULL){
        _single = new ChannelProc();
    }
    return _single;
}


bool ChannelProc::readDetData(struct DetInfo* dets)
{
    QMutexLocker locker(&m_lock);

    if(valid)
    {
        for(int i = 0; i < 5; i++)
        {
           dets[i].outcode   =  m_detInfo[i].outcode;
           dets[i].incode    =  m_detInfo[i].incode ;
           dets[i].pwd       =  m_detInfo[i].pwd  ;
           dets[i].barcode   =  m_detInfo[i].barcode ;
           dets[i].detType   =  m_detInfo[i].detType;
           dets[i].statusCode=  m_detInfo[i].statusCode;
           dets[i].channel   =  m_detInfo[i].channel;
           dets[i].productionLineID=  m_detInfo[i].productionLineID;
           dets[i].lineLength=  m_detInfo[i].lineLength;
           dets[i].factory   =  m_detInfo[i].factory ;
           dets[i].feature    =  m_detInfo[i].feature;
           dets[i].no          =  m_detInfo[i].no ;
           dets[i].detDate     =  m_detInfo[i].detDate;
           dets[i].produceTime=  m_detInfo[i].produceTime;
           dets[i].taskId = m_detInfo[i].taskId;
        }
        valid = false;
        return true;
    }
    LOG_DEBUG(QString(QStringLiteral("写码检测数据无效")));
    return false;
}


extern bool testDetCode(const QByteArray& outcode, int detType, const QByteArray& incode);

bool ChannelProc::WriteCode(const QList<QByteArray>& outcodes)
{
    LOG_DEBUG(QString(QStringLiteral("检测仪写码开始")));
    QByteArray outcodes_tochannel;

    for(int i = 0; i < 5; i++)
    {
        outcodes_tochannel.append("0");
        outcodes_tochannel.append(outcodes.at(i));
    }

    LOG_DEBUG(QStringLiteral("串口发送写码指令"));
    int ret = m_chWriteCode->startWriteCode(outcodes_tochannel);
    if(-1 == ret){
        LOG_DEBUG(QStringLiteral("串口发送写码指令失败"));
    }else if(0 == ret){
        LOG_DEBUG(QStringLiteral("串口接收数据超时"));
    }else{
        QString msg = QString("SERIL RECV: %0").arg(ret);
        LOG_DEBUG(msg);
    }

    for(int i = 0; i < 5; i++)
    {
        int channel = i+1;

        ushort ch = 0;
        ushort checkRslt = 0;
        QByteArray incode;
        QByteArray pwd;
        uchar detType = 0;
        QByteArray outcode;


        checkRslt = 0xFF;
        int ret = m_chWriteCode->readCheckRsltTimeout(channel, 15000, ch, checkRslt,incode, pwd, detType, outcode);
        if(-1 == ret){
            LOG_DEBUG(QStringLiteral("串口发送数据失败"));
        }else if(0 == ret){
            LOG_DEBUG(QStringLiteral("串口接收数据超时"));
        }else{
            QString msg = QString("SERIL RECV: %0").arg(ret);
            LOG_DEBUG(msg);
        }

        qDebug()<<"CHANNEL = "<<channel<<ch<<checkRslt<<detType;
        qDebug()<<outcode;
        qDebug()<<QString(incode.toHex())<<QString(pwd.toHex())<<endl;

        QString msg = QString("").asprintf("Chanel:%d, Rslt:%d, DetType:%d, Outcode:%s, Incode:%s", ch, checkRslt, detType, outcode.data(), incode.toHex().data());
        LOG_DEBUG(msg);

        bool retC = testDetCode(outcode, detType, incode);
        if(!retC){
            LOG_DEBUG(QStringLiteral("管码数据转码出错"));
            LOG_DEBUG(m_chWriteCode->m_readdata.toHex());
        }

        struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
        //保存检测结果
        if(ret > 0) //数据有效
        {
            QMutexLocker locker(&m_lock);
            int index = i;
            m_detInfo[index].outcode = outcode;
            m_detInfo[index].incode  = incode.toHex();
            m_detInfo[index].pwd     = pwd.toHex();
            m_detInfo[index].barcode = outcode + (char)(detType+'0');
            m_detInfo[index].detType = detType;
            m_detInfo[index].statusCode = checkRslt;
            m_detInfo[index].channel = ch ;
            m_detInfo[index].productionLineID = cfg->produceLineID;
            m_detInfo[index].lineLength = cfg->lineLength;
            m_detInfo[index].factory = cfg->factory;

            m_detInfo[index].feature = cfg->feature;
            m_detInfo[index].no = QString(outcode.mid(8, 5)).toInt();
            m_detInfo[index].detDate = QDate::fromString(cfg->productDate, "yyyy.MM.dd");
            m_detInfo[index].produceTime = QDateTime::currentDateTime();
            m_detInfo[index].taskId = cfg->taskId;
        }
        else //数据无效
        {
            QMutexLocker locker(&m_lock);
            int index = i;
            m_detInfo[index].outcode = QByteArray("1234512345123");
            m_detInfo[index].incode  = QByteArray("\0");
            m_detInfo[index].pwd     = QByteArray("\0");

            m_detInfo[index].barcode = m_detInfo[index].outcode+'\0';
            m_detInfo[index].detType = 0;
            m_detInfo[index].statusCode = 0xFF;
            m_detInfo[index].channel = ch ;
            m_detInfo[index].productionLineID = 0;
            m_detInfo[index].lineLength = 0;
            m_detInfo[index].factory = 0;

            m_detInfo[index].feature = 0;
            m_detInfo[index].no = 0;
            m_detInfo[index].detDate = QDate::fromString(cfg->productDate, "yyyy.MM.dd");
            m_detInfo[index].produceTime = QDateTime::currentDateTime();
            m_detInfo[index].taskId = cfg->taskId;
        }
    }
    {
        QMutexLocker locker(&m_lock);
        valid = true;
    }
    LOG_DEBUG(QString(QStringLiteral("检测仪写码结束")));

    return true;
}


void ChannelProc::doWorkWriteCode(const QList<QByteArray> outcodes)
{
    WriteCode(outcodes);
    emit finished_WriteCode();
}
