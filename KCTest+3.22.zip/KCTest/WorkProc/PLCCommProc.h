﻿#ifndef PLCCOMMPROC_H
#define PLCCOMMPROC_H

#include <QObject>
#include <QThread>
#include "PLCCmd.h"
#include "ChannelCmd.h"
#include "DBMgr/DBMgr.h"
#include "ULog/KLog.h"
#include "ChannelProc.h"
#include "ChPreCheckWork.h"

enum WriteCodeStatus{
    RcvWriteCmd = 0,
    WriteFinished,
    TiaoHao,
    BuTiaoHao

};


class PLCCommProc : public QObject
{
    Q_OBJECT
public:
    static PLCCommProc* instance();
    ~PLCCommProc();
    bool isRunning();


    void do_WriteCodeWork();
    void do_PreCheckWork();

public slots:
    void startProduce();
    void stopProduce();

    void run();
    void init();

private:
    void creatOutCodes(QList<QByteArray>& M_outcodes);

signals:
    //给UI显示连接状态
    void sigConnect(bool plc, bool ch);

    //给UI显示状态
    void sigWriteCodeStatus(int status);
    void sigWriteCodeRslt(QList<QByteArray> M_outcodesCH, QList<QByteArray> M_faultcodes);
    void sigWriteCodePLCStatus(int heart, bool writeCodeOK, bool tiaohao, bool butiaohao, ushort lineLength);
    void sigProduceFinished(int num);
    void sigCurrentTaskFinished(int num); // 当前任务

    //给UI显示半成品检状态
    void sigPreCheckStatus(int status, int rslt);


    //给检测仪指令
    void sigStartPreCheck();
    void sigStartWriteCode(const QList<QByteArray> outcodes);

public slots:
    void slot_finishPreCheck(uchar rslt);
    void slot_finishWriteCode();
private:
    explicit PLCCommProc(QObject *parent = nullptr);

    bool m_running;

//    ChannelCmd* m_chCmd;
    PLCCmd* m_plCcmd;

    KLog* mlog;

    int m_pcheart;
    bool m_reset;


    int m_wrheart;
    bool m_writeCodeCmd;
    bool m_tiaohao;
    bool m_butiaohao;
    ushort m_lineLength;

    QTimer* m_timer;


    struct DetInfo m_detInfo[5];
    bool m_saveToDB = false;

    QList<QByteArray> M_outcodes;


    int m_Aheart;
    bool m_AstartPreCheck;
    bool m_Areset;

    ushort m_Asndheart;
    bool m_AenPreCheck;
    bool m_ArecvCheck;
    bool m_Afinished;
    char m_Arslt;


};

#endif // PLCCOMMPROC_H
