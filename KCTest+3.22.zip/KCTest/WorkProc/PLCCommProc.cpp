﻿#include "PLCCommProc.h"
#include <QTimer>
#include <QTime>
#include "AllConfig.h"
#include "DBMgr/DBMgr.h"
#include <QDebug>
#include "ULog/ulog.h"
#include <QDir>
#include <QFile>
#include <QDateTime>
#include "ULog/KLog.h"
#include "ChannelProc.h"
#include "ChPreCheckWork.h"
#include "datamanage.h"

#define IP_ADDR  "192.168.20.20"
#define IP_PORT  9600

#define LOG_DEBUG(s)   mlog->write(s)




enum PLCCOMStatus{
    ConnectOK,
    ConnectFail,
    ConnectError

};
static PLCCommProc* _single = NULL;


PLCCommProc::PLCCommProc(QObject *parent) : QObject(parent)
{
//    init();
}

PLCCommProc::~PLCCommProc()
{
    if(_single != NULL){
        delete _single;
        _single = NULL;
    }
}

PLCCommProc* PLCCommProc::instance(){
    if(_single == NULL){
        _single = new PLCCommProc();
    }
    return _single;
}


void PLCCommProc::init()
{
    m_running = false;
    m_plCcmd = new PLCCmd();
    m_plCcmd->init(AllConfig::instance()->getProduceConfig()->plc_ip, IP_PORT, 0x89);

    qDebug()<<"PLCCommProc Thread Info: "<<QThread::currentThreadId()<<QThread::currentThread();

    mlog = new KLog();
    mlog->init("PLC_LOG_");
    mlog->write("PLCCommProc inited");

    QTimer* _timer = new QTimer();
    connect(_timer, &QTimer::timeout, this, [=](){
        run();
    });
    _timer->start(50);
}

bool PLCCommProc::isRunning()
{
    return m_running;
}

void PLCCommProc::startProduce()
{
    m_running = true;
    qDebug() << "1111111111111";
    LOG_DEBUG(QString(QStringLiteral("成品检启动生产")));
}

void PLCCommProc::stopProduce()
{
    m_running = false;
    qDebug() << "222222222222";
    LOG_DEBUG(QString(QStringLiteral("成品检停止生产")));
}


void Delay(int msec){
    QEventLoop loop;
    QTimer::singleShot(msec, &loop,SLOT(quit()));
    loop.exec();
}


void PLCCommProc::run()
{
    static int plcDisConnectCnt = 0;
    static int cnt = 0;

    cnt++;
    if(cnt%200 == 0){
        LOG_DEBUG(QStringLiteral("PLC Run"));
    }


    int ret = m_plCcmd->isConnected();
    if(!ret){
        plcDisConnectCnt++;
        if(plcDisConnectCnt == 1){
            LOG_DEBUG(QStringLiteral("PLC连接失败"));
            LOG_DEBUG(QString("tcpConnect = %0, finsConnect = %1 functionCode = %2").arg(m_plCcmd->m_tcpConnect).arg(m_plCcmd->m_finsConnect).arg(m_plCcmd->m_funcCode));
            emit sigConnect(false, true);
        }
    }
    else
    {
        if(plcDisConnectCnt != 0){
            plcDisConnectCnt = 0;
            emit sigConnect(true, true);
        }

        if(m_running)
        {
            do_WriteCodeWork();
            do_PreCheckWork();
            qDebug()<<"PLCCommProc : "<<QThread::currentThreadId()<<QThread::currentThread();
        }else{
            m_plCcmd->WriteCode_WriteHeart();
            m_plCcmd->PreCheck_WriteHeart(m_Asndheart);
        }
    }
}



void PLCCommProc::creatOutCodes(QList<QByteArray>& outcodes)
{
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
    QDate date = QDate::fromString(cfg->productDate, "yyyy.MM.dd");

    QString codePrefix = QString("").asprintf("%02d%d%02d%02d%c",cfg->factory, date.year()%10,
                                              date.month(), date.day(), cfg->feature);


    outcodes.clear();
    for(int i = 0; i < 5; i++)
    {
        int cnt = cfg->produceWritedNum + i;
        int box = cfg->startBox + (cnt/cfg->numInBox);
        int numInbox = cfg->startNo + (cnt%cfg->numInBox);
        QString log = QString("雷管序号：") + QString::number(cnt) + " 盒号：" + QString::number(box) + "盒内序号：" + QString::number(cnt);
        LOG_DEBUG(log);

        QByteArray outcode = codePrefix.toLocal8Bit() + QString("").asprintf("%03d%02d",box,numInbox).toLocal8Bit();

        outcodes.append(outcode);
    }
}


#define _DEBUG_  0

#define CHECK_RET(ret, msg) do{\
    if(!ret){\
        qDebug()<<ret<<msg;\
        LOG_DEBUG(msg);\
    }\
    }while(0)


void PLCCommProc::do_WriteCodeWork()
{
    int heart = 0;
    bool enableWriteCode = true;
    bool tiaohao = false;
    bool butiaohao = false;
    ushort lineLength = 0;

    int ret = m_plCcmd->WriteCode_Read(heart, enableWriteCode, tiaohao, butiaohao, lineLength);
    //CHECK_RET(ret, "PLC Read");

#if _DEBUG_
    ret = true;
    enableWriteCode = true;
#endif

    if(!ret){
        //qDebug()<<"plc connect failed";
        return ;
    }

    emit sigWriteCodePLCStatus(heart, enableWriteCode, tiaohao, butiaohao, lineLength);


    qDebug()<<__FUNCTION__<<heart;
    if(ret){

#if _DEBUG_
    m_writeCodeCmd = false;
#endif
        if(enableWriteCode != m_writeCodeCmd)
        {
            m_writeCodeCmd = enableWriteCode;
            qDebug()<<__FUNCTION__<<"writeCodeOK changed"<<enableWriteCode;
            if(enableWriteCode == true)
            {
                emit sigWriteCodeStatus(RcvWriteCmd);
                LOG_DEBUG(QString(QStringLiteral("收到PLC写码指令")));

                QList<QByteArray> outcodes;

                creatOutCodes(outcodes);
                ret = m_plCcmd->WriteCode_WriteWrittingCode(); //写码中
                CHECK_RET(ret, "WriteCode_WriteWrittingCode");
                LOG_DEBUG(QString(QStringLiteral("发送给PLC写码中")));


                LOG_DEBUG(QString(QStringLiteral("检测仪开始写码")));

                LOG_DEBUG(QString(QStringLiteral("发送写码指令1")));
                emit sigStartWriteCode(outcodes);
                LOG_DEBUG(QString(QStringLiteral("发送写码指令2")));
            }
        }

        if(tiaohao != m_tiaohao){
            m_tiaohao = tiaohao;
            if(m_tiaohao == true){
                QString mm = QString(QStringLiteral("收到PLC写码跳号指令")) + QString::number(AllConfig::instance()->getProduceConfig()->produceWritedNum);
                LOG_DEBUG(mm);

                struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();

                cfg->produceWritedNum += 5;
                ret = m_plCcmd->WriteCode_WriteTiaoHao();    //跳号
                CHECK_RET(ret, "WriteCode_WriteTiaoHao");

                //保存数据 判断数据有效性
                if(m_saveToDB){
                    for(int i = 0 ; i < 5; i++)
                    {
                        DBMgr::instance()->insertDet(m_detInfo[i]);
                    }
                    LOG_DEBUG(QString(QStringLiteral("保存写码数据完成")));
                    m_saveToDB = false;
                }else{
                    LOG_DEBUG(QString(QStringLiteral("无写码数据需要保存")));
                }

                emit sigWriteCodeStatus(TiaoHao);
                QString mm2 = QString(QStringLiteral("回复PLC写码跳号指令")) + QString::number(AllConfig::instance()->getProduceConfig()->produceWritedNum);
                LOG_DEBUG(mm2);
                DataManage::instance()->refreshErrAndAcc(AllConfig::instance()->getProduceConfig()->produceWritedNum);
                emit sigProduceFinished(cfg->hasProductedTotalNum);
                emit sigCurrentTaskFinished(cfg->produceWritedNum);

                if(cfg->produceWritedNum >= cfg->produceNum && AllConfig::instance()->getProduceConfig()->finalProduceFlag)
                {
                    QString log = QString("Produce Finished Count: ") + QString::number(cfg->hasProductedTotalNum);
                    LOG_DEBUG(QString(QStringLiteral("生产完成")));
                    LOG_DEBUG(log);
                }
            }
        }

        if(butiaohao != m_butiaohao){
            m_butiaohao = butiaohao;
            if(m_butiaohao == true){
                LOG_DEBUG(QString(QStringLiteral("收到PLC写码不跳号指令")));

                ret = m_plCcmd->WriteCode_WriteBuTiaoHao();  //不跳号
                CHECK_RET(ret, "WriteCode_WriteTiaoHao");
                emit sigWriteCodeStatus(BuTiaoHao);
                LOG_DEBUG(QString(QStringLiteral("回复PLC写码不跳号指令")));
            }
        }

        if(lineLength != m_lineLength){
            m_lineLength = lineLength;
            qDebug()<<__FUNCTION__<<"lineLength = "<<lineLength;
        }

        m_wrheart = heart;
        m_writeCodeCmd = enableWriteCode;
        m_tiaohao = tiaohao;
        m_butiaohao = butiaohao;
        m_lineLength = lineLength;
    }else{
        LOG_DEBUG(QString(QStringLiteral("接收PLC成品检数据失败")));
        LOG_DEBUG(QString("tcpConnect = %0, finsConnect = %1 functionCode = %2").arg(m_plCcmd->m_tcpConnect).arg(m_plCcmd->m_finsConnect).arg(m_plCcmd->m_funcCode));
        LOG_DEBUG(QStringLiteral("PORT %0").arg(m_plCcmd->getSocketPort()));
    }

    ret = m_plCcmd->WriteCode_WriteHeart2();
    ret = m_plCcmd->WriteCode_WriteProduceNum();
    //ret = m_plCcmd->WriteCode_WriteBuTiaoHao();
    qDebug()<<__FUNCTION__<<"lineLength = "<<lineLength;
}




void PLCCommProc::do_PreCheckWork()
{
    int heart;
    bool startPreCheck;
    bool reset;
    int ret = m_plCcmd->PreCheck_Read(heart, startPreCheck, reset);
    if(ret){
        if(heart != m_Aheart){
        }

        if((startPreCheck != m_AstartPreCheck)&&(startPreCheck == true))
        {
            m_Asndheart = 0;
            m_AenPreCheck = true;
            m_ArecvCheck = true;
            m_Afinished = false;
            m_Arslt = 0x00;

            emit sigPreCheckStatus(1, 0);

            LOG_DEBUG(QString(QStringLiteral("收到PLC半成品检指令")));
            m_plCcmd->PreCheck_Write(m_Asndheart, m_AenPreCheck, m_ArecvCheck, m_Afinished, m_Arslt);

            LOG_DEBUG(QString(QStringLiteral("发送检测指令1")));
            emit sigStartPreCheck();
            LOG_DEBUG(QString(QStringLiteral("发送检测指令2")));
        }

        if((reset != m_Areset)&&(reset == true))
        {
            m_Asndheart = 0;
            m_AenPreCheck = true;
            m_ArecvCheck = false;
            m_Afinished = false;
            m_Arslt = 0x00;
            LOG_DEBUG(QString(QStringLiteral("收到PLC半成品复位指令")));

            emit sigPreCheckStatus(2, 0);

            m_plCcmd->PreCheck_Write(m_Asndheart, m_AenPreCheck, m_ArecvCheck, m_Afinished, m_Arslt);
        }

        m_Aheart = heart;
        m_AstartPreCheck = startPreCheck;
        m_Areset = reset;
    }
    else{
        LOG_DEBUG(QString(QStringLiteral("接收PLC半成品检数据失败")));
        LOG_DEBUG(QString("tcpConnect = %0, finsConnect = %1 functionCode = %2").arg(m_plCcmd->m_tcpConnect).arg(m_plCcmd->m_finsConnect).arg(m_plCcmd->m_funcCode));
        LOG_DEBUG(QStringLiteral("PORT %0").arg(m_plCcmd->getSocketPort()));
    }

    m_plCcmd->PreCheck_WriteHeart(m_Asndheart);
}



void PLCCommProc::slot_finishPreCheck(uchar rslt)
{
    qDebug()<<QThread::currentThread()<<QThread::currentThreadId()<<__FUNCTION__;
    m_Asndheart = 0;
    m_AenPreCheck = true;
    m_ArecvCheck = false;
    m_Afinished = true;
    m_Arslt = rslt;

    m_plCcmd->PreCheck_Write(m_Asndheart, m_AenPreCheck, m_ArecvCheck, m_Afinished, m_Arslt);
    LOG_DEBUG(QString(QStringLiteral("回复PLC完成半成品检")));
}


void PLCCommProc::slot_finishWriteCode()
{
    LOG_DEBUG(QString(QStringLiteral("检测仪写码返回")));

    uchar rslt = 0;
    QList<QByteArray> outcodes;
    QList<QByteArray> faultcodes;

    int ret = ChannelProc::instance()->readDetData(m_detInfo);
    if(ret)
    {
        m_saveToDB = true;
        for(int i = 0; i < 5; i++)
        {
            if(m_detInfo[i].statusCode == 0x00){
                rslt = rslt |(1<<(i));
            }

            ushort checkRslt = m_detInfo[i].statusCode;
            //故障代码转换 0-故障 1-正常
            if(checkRslt == 0){
                checkRslt = 1;
            }else if (checkRslt == 1){
                checkRslt = 0;
            }
            QByteArray fault;
            fault.append((checkRslt>>8)&0xFF);
            fault.append(checkRslt&0xFF);
            faultcodes.append(fault);
            outcodes.append(m_detInfo[i].outcode);
        }

        qDebug()<<QThread::currentThread()<<QThread::currentThreadId()<<__FUNCTION__;

        int ret = m_plCcmd->WriteCode_WriteWriteCodeFinished(rslt, outcodes, faultcodes); //写码完成
        CHECK_RET(ret, "WriteCode_WriteWriteCodeFinished");
        emit sigWriteCodeStatus(WriteFinished);
        LOG_DEBUG(QString(QStringLiteral("发送给PLC写码完成")));

        if( (rslt&0x1f) != 0x1f)
        {
            LOG_DEBUG(QString(QStringLiteral("写码数据故障")));
        }
        emit sigWriteCodeRslt(outcodes, faultcodes);
        LOG_DEBUG(QString(QStringLiteral("发送给PLC写码结果")));
    }
    else
    {
        LOG_DEBUG(QString(QStringLiteral("获取检测数据失败")));
        for(int i = 0; i < 5; i++)
        {
            rslt = 0;
            //故障代码转换 0-故障 1-正常
            ushort checkRslt = 0xFD;
            QByteArray fault;
            fault.append((checkRslt>>8)&0xFF);
            fault.append(checkRslt&0xFF);
            faultcodes.append(fault);
            outcodes.append("1111111111111");
        }

        LOG_DEBUG(QString(QStringLiteral("获取写码结果数据失败")));
        int ret = m_plCcmd->WriteCode_WriteWriteCodeFinished(rslt, outcodes, faultcodes); //写码完成
        CHECK_RET(ret, "WriteCode_WriteWriteCodeFinished");
        emit sigWriteCodeStatus(WriteFinished);
        LOG_DEBUG(QString(QStringLiteral("发送给PLC写码完成")));
    }

}
