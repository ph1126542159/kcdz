﻿#ifndef MGR_H
#define MGR_H

#include <QObject>
#include "ChPreCheckWork.h"
#include "PLCCommProc.h"
#include "ChannelProc.h"


class Mgr : public QObject
{
    Q_OBJECT
public:
    explicit Mgr(QObject *parent = nullptr);

    ~Mgr();


signals:
    void sigPlcInit();

private:

    ChannelProc* m_WriteCodeWork;
    QThread* m_WriteCoddeThread;

    ChPreCheckWork* m_ChPreCheckWork;
    QThread* m_ChPreCheckThread;

    QThread* m_PLCThread;

};

#endif // MGR_H
