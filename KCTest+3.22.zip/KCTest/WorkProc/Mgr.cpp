﻿#include "Mgr.h"
#include "MainWindow.h"
#include "datamanage.h"
#include "ProductionSet.h"

Mgr::Mgr(QObject *parent) : QObject(parent)
{
    qRegisterMetaType<QList<QByteArray>>("QList<QByteArray>");
    qRegisterMetaType<QList<QByteArray>>("QList<QByteArray>&");

    PLCCommProc::instance();
    m_PLCThread = new QThread();

    m_WriteCodeWork = ChannelProc::instance();
    m_WriteCoddeThread = new QThread();
    connect(ProductionSet::instance(), &ProductionSet::signalsRefreshTable, DataManage::instance(), &DataManage::slotsRefreshTable, Qt::QueuedConnection);

    connect(PLCCommProc::instance(), &PLCCommProc::sigStartWriteCode, m_WriteCodeWork, &ChannelProc::doWorkWriteCode);
    connect(m_WriteCodeWork, &ChannelProc::finished_WriteCode, PLCCommProc::instance(), &PLCCommProc::slot_finishWriteCode);
    m_WriteCodeWork->moveToThread(m_WriteCoddeThread);
    m_WriteCoddeThread->start();


    m_ChPreCheckWork= new ChPreCheckWork();
    m_ChPreCheckThread  = new QThread();
    connect(PLCCommProc::instance(), &PLCCommProc::sigStartPreCheck, m_ChPreCheckWork, &ChPreCheckWork::doWorkPreCheck);
    connect(m_ChPreCheckWork, &ChPreCheckWork::finished_PreCheck, PLCCommProc::instance(), &PLCCommProc::slot_finishPreCheck);
    m_ChPreCheckWork->moveToThread(m_ChPreCheckThread);
    m_ChPreCheckThread->start();

    PLCCommProc::instance()->moveToThread(m_PLCThread);
    m_PLCThread->start();

    connect(this, &Mgr::sigPlcInit, PLCCommProc::instance(), &PLCCommProc::init);


    //////////////
    connect(PLCCommProc::instance(), &PLCCommProc::sigWriteCodePLCStatus, MainWindow::instance(), &MainWindow::slot_WriteCodePLCStatus, Qt::QueuedConnection);
    connect(PLCCommProc::instance(), &PLCCommProc::sigWriteCodeStatus, MainWindow::instance(), &MainWindow::slot_WriteCodeStatus, Qt::QueuedConnection);
    connect(PLCCommProc::instance(), &PLCCommProc::sigWriteCodeRslt, MainWindow::instance(), &MainWindow::slot_WriteCodeRslt, Qt::QueuedConnection);
    connect(MainWindow::instance(), &MainWindow::sigStart, PLCCommProc::instance(), &PLCCommProc::startProduce, Qt::QueuedConnection);
    connect(MainWindow::instance(), &MainWindow::sigEnd, PLCCommProc::instance(), &PLCCommProc::stopProduce, Qt::QueuedConnection);

    connect(DataManage::instance(), &DataManage::signalsStart, PLCCommProc::instance(), &PLCCommProc::startProduce, Qt::QueuedConnection);
    connect(DataManage::instance(), &DataManage::signalsEnd, PLCCommProc::instance(), &PLCCommProc::stopProduce, Qt::QueuedConnection);

    connect(PLCCommProc::instance(), &PLCCommProc::sigConnect, MainWindow::instance(), &MainWindow::slot_ConnectStatus, Qt::QueuedConnection);
    connect(PLCCommProc::instance(), &PLCCommProc::sigProduceFinished, MainWindow::instance(), &MainWindow::slot_ProduceFinished, Qt::QueuedConnection);
    connect(PLCCommProc::instance(), &PLCCommProc::sigProduceFinished, DataManage::instance(), &DataManage::slotsProduceFinished, Qt::QueuedConnection);
    connect(PLCCommProc::instance(), &PLCCommProc::sigCurrentTaskFinished, DataManage::instance(), &DataManage::slotsCurrentTaskFinished, Qt::QueuedConnection);
    connect(PLCCommProc::instance(), &PLCCommProc::sigPreCheckStatus, MainWindow::instance(), &MainWindow::slot_PreCheckStatus, Qt::QueuedConnection);

}

Mgr::~Mgr()
{
//    m_WriteCoddeThread->quit();
//    m_WriteCoddeThread->wait();

//    m_ChPreCheckThread->quit();
//    m_ChPreCheckThread->wait();

//    m_PLCThread->quit();
//    m_PLCThread->wait();

//    delete m_WriteCodeWork;
//    delete m_ChPreCheckWork;
//    delete PLCCommProc::instance();

//    delete m_PLCThread;
//    delete m_WriteCoddeThread;
//    delete m_ChPreCheckThread;

//    m_PLCThread = nullptr;
//    m_WriteCoddeThread = nullptr;
//    m_ChPreCheckThread = nullptr;
}
