﻿#ifndef PLCPRECHECKPROC_H
#define PLCPRECHECKPROC_H

#include <QObject>
#include <QThread>
#include "PLCCmd.h"
#include "ChannelCmd.h"
#include "ULog/KLog.h"


class PlcPreCheckProc : public QThread
{
    Q_OBJECT
public:
    static PlcPreCheckProc* instance(){
        static PlcPreCheckProc* _single = new PlcPreCheckProc();
        return _single;
    }

    void init();


    void do_PreCheck();

public slots:
    void startProduce();
    void stopProduce();

 protected:
    void run() ;

signals:

private:
    explicit PlcPreCheckProc(QObject *parent = nullptr);

    KLog* mlog;
    PLCCmd* m_plCcmd;
    ChannelCmd* m_chCmd;

    int m_heart;
    bool m_startPreCheck;
    bool m_reset;

    bool m_isRunning;


    ushort m_sndheart;
    bool m_enPreCheck;
    bool m_recvCheck;
    bool m_finished;
    char m_rslt;

};

#endif // PLCPRECHECKPROC_H
