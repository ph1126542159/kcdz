﻿#include "datamanage.h"
#include "ui_DataManage.h"
#include <QDebug>
#include <QFileDialog>
#include <QDateTime>
#include "gen_excel_file.h"
#include <QStandardItemModel>
#include <QTableView>
#include <QListWidgetItem>
#include <QMessageBox>
#include "UI/ProductionSet.h"
#include "AllConfig.h"
#include "PLCCommProc.h"
#include <QTableWidgetItem>
#include "MainWindow.h"
#include <QInputDialog>
#ifdef ENABLE_XLSS
#include <QtXlsx>
#endif
using namespace std;
using namespace generate_excel;

enum TableHeadNo{
    T_ID  = 0 ,
    T_TASKID,
    T_OUTCODE   ,
    T_ENCIPHERRANRE,
    T_ASSIGNMENTNUM    ,
    T_ACCOMPLISHNUM       ,
    T_ABNORMALNUM   ,
    T_PRODUCETIME,
    T_LINE_LENGTH,
    T_LOTNUM,
    T_STAFF,
    T_STATUSCODE    ,
    T_PRODUCECOMMENT,
    T_PWD  ,
    T_DETTYPE   ,
    T_FACTORY    ,
    T_FEATURE,
    T_NUMBERINBOX,
    T_STARTBOX,
    T_T_STARTNO,
    T_PRODUCTIONLINEID,
    T_DETDATE,
    T_CODEPREFIX
};

DataManage::DataManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DataManage)
{
     ui->setupUi(this);
     //设置列数
     init();
     connect(ui->tableView_2, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked(const QModelIndex &)));
     QTimer* _timer = new QTimer();
     connect(_timer, &QTimer::timeout, this, [=](){
         on_refreshAssignment_clicked();
     });
     _timer->start(30000);
     connect(ProductionSet::instance(), &ProductionSet::signalsRefreshTable, this, [=](){
         slotsRefreshTable();
     });
}


void DataManage::init()
{
    m_model = new QStandardItemModel(10,1,this);
    QStringList headers;
    headers << "序号" << "任务ID" << "管壳码" <<"编码范围" <<"任务量"<<"已完成"<<"异常数量"<<"日期"
             <<"脚线长度"<<"批号"<<"工作人员"<<"状态"<<"备注" << "PWD" <<"雷管类型" <<"工厂" << "特征码" << "盒内数" << "起始盒号" << "起始序号" << "机台号" << "雷管日期" << "管码前8位";
    m_model->setHorizontalHeaderLabels(headers);

    ui->tableView_2->setModel(m_model);
    ui->tableView_2->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
    ui->tableView_2->verticalHeader()->setHidden(true);

    ui->tableView_2->horizontalHeader()->setStyleSheet("QHeaderView::section{background:lightblue;}"); //设置表头颜色
    ui->tableView_2->setColumnWidth(T_ID, 50);
    ui->tableView_2->setColumnWidth(T_TASKID, 80);
    ui->tableView_2->setColumnHidden(T_OUTCODE, true);
    ui->tableView_2->setColumnWidth(T_ENCIPHERRANRE, 200);
    ui->tableView_2->setColumnWidth(T_ASSIGNMENTNUM, 100);
    ui->tableView_2->setColumnWidth(T_ACCOMPLISHNUM, 80);
    ui->tableView_2->setColumnWidth(T_ABNORMALNUM, 80);
    ui->tableView_2->setColumnWidth(T_PRODUCETIME, 80);
    ui->tableView_2->setColumnWidth(T_LINE_LENGTH, 80);
    ui->tableView_2->setColumnWidth(T_LOTNUM, 80);
    ui->tableView_2->setColumnWidth(T_STAFF, 80);
    ui->tableView_2->setColumnWidth(T_STATUSCODE, 80);
    ui->tableView_2->setColumnWidth(T_PRODUCECOMMENT, 80);
    ui->tableView_2->setColumnHidden(T_PWD, true);
    ui->tableView_2->setColumnHidden(T_DETTYPE, true);
    ui->tableView_2->setColumnHidden(T_FACTORY, true);
    ui->tableView_2->setColumnHidden(T_FEATURE, true);
    ui->tableView_2->setColumnHidden(T_NUMBERINBOX, true);
    ui->tableView_2->setColumnHidden(T_STARTBOX, true);
    ui->tableView_2->setColumnHidden(T_T_STARTNO, true);
    ui->tableView_2->setColumnHidden(T_PRODUCTIONLINEID, true);
    ui->tableView_2->setColumnHidden(T_DETDATE, true);
    ui->tableView_2->setColumnHidden(T_CODEPREFIX, true);

    ui->tableView_2->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView_2->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableView_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_model->removeRows(0, m_model->rowCount());

    DataManagement::instance()->queryDetProductMission(m_model);
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
    productedTotalNum = DataManagement::instance()->queryProductedTotalNum();
    cfg->produceNumTotal = productedTotalNum;
    ui->detCount_2->setText(QString("共" + QString::number(m_model->rowCount()) + "个任务," + QString::number(productedTotalNum) + "发"));
}

void DataManage::refreshErrAndAcc(int &accomplishNum)              //设置定时器 一定时间更新表格
{
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
    DataManagement::instance()->updataProductedMission(cfg->taskId,accomplishNum);
    cfg->hasProductedTotalNum = DataManagement::instance()->queryHasProducedTotalNum();
    DBMgr::instance()->queryDetCountByErrorCode(cfg->taskId);
}

bool DataManage::runCurentNext()
{

    struct ProduceConfigType* config =  AllConfig::instance()->getProduceConfig();
    QString productStatus = "已完成";
    m_pwd = ui->tableView_2->model()->index(config->m_currentRunRow,1).data().toString();
    DataManagement::instance()->updataProductMissionState(m_pwd,productStatus);
    config->m_currentRunRow =config->m_currentRunRow + 1;
    if(config->m_currentRunRow <= ui->tableView_2->model()->rowCount()-1){
        if (ui->tableView_2->model()->index(config->m_currentRunRow,11).data().toString() == "已完成")
        {
            runCurentNext();
            return false;
        }

        config->factory =   ui->tableView_2->model()->index(config->m_currentRunRow,15).data().toInt();
        config->detType =  ui->tableView_2->model()->index(config->m_currentRunRow,14).data().toInt();
        config->productDate = ui->tableView_2->model()->index(config->m_currentRunRow,21).data().toDate().toString("yyyy.MM.dd");
        config->feature =  ui->tableView_2->model()->index(config->m_currentRunRow,16).data().toInt();
        config->numInBox = ui->tableView_2->model()->index(config->m_currentRunRow,17).data().toInt();
        config->startBox = ui->tableView_2->model()->index(config->m_currentRunRow,18).data().toInt();
        config->startNo = ui->tableView_2->model()->index(config->m_currentRunRow,19).data().toInt();
        config->lineLength = ui->tableView_2->model()->index(config->m_currentRunRow,8).data().toInt();
        config->produceNum = ui->tableView_2->model()->index(config->m_currentRunRow,4).data().toInt();
        config->produceLineID = ui->tableView_2->model()->index(config->m_currentRunRow,20).data().toInt();
        config->produceWritedNum = ui->tableView_2->model()->index(config->m_currentRunRow,5).data().toInt();
        config->codePrefix = ui->tableView_2->model()->index(config->m_currentRunRow,22).data().toInt();

        config->taskId = ui->tableView_2->model()->index(config->m_currentRunRow,1).data().toString();
        if (m_model->rowCount()-1 == config->m_currentRunRow)
        {
            config->finalProduceFlag = true;
        }
        else
        {
            config->finalProduceFlag = false;
        }
        qDebug()<< QThread::currentThreadId() << QThread::currentThread() << "生产中...";
        m_pwd = ui->tableView_2->model()->index(config->m_currentRunRow,1).data().toString();
        QString productStatus = "生产中";
        DataManagement::instance()->updataProductMissionState(m_pwd,productStatus);
        DataManagement::instance()->queryDetProductMission(m_model);
        AllConfig::instance()->saveConfig();
        AllConfig::instance()->readConfig();
        QMessageBox::information(this, "提示", "正在执行下一个生产...");
        return true;
    } else {
        QMessageBox::information(this, "提示", "任务已完成");
        PLCCommProc::instance()->stopProduce();
        return true;
    }
}

bool DataManage::exportDataTable()
{

}

void DataManage::slotsRefreshTable()
{
      qDebug()<< QThread::currentThreadId() << QThread::currentThread() << "生产中...";
      on_refreshAssignment_clicked();
      DataManagement::instance()->queryDetProductMission(m_model);
}

void DataManage::slotsProduceFinished(int num)
{
//    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
//    if (cfg->produceWritedNum >= cfg->produceNum && cfg->finalProduceFlag)
//    {
//        PLCCommProc::instance()->stopProduce();
//    }
}
DataManage::~DataManage()
{
    delete ui;
}

void DataManage::on_exportSelectedData_clicked()
{
    QList<QModelIndex> list =  ui->tableView_2->selectionModel()->selectedIndexes();
    for (int i=0; i < list.size()/23; i++)
    {
        int T = 1 + i*23;
        QString listExport = list[T].data().toString();
        integerList.append(listExport);
    }
    if(ui->tableView_2->currentIndex().isValid()){
        QMessageBox::StandardButton sButton = QMessageBox::question(NULL, (QObject::tr("提示")), (QObject::tr("是否导出此任务!")));
        if (sButton == QMessageBox::StandardButton::Yes)
        {
            QString taskIdDataSql = "";
            for (int i = 0; i < integerList.size(); i++)
            {
               if(i!=(integerList.size()-1)){
                     taskIdDataSql += integerList[i] + ",";
                }else{
                     taskIdDataSql += integerList[i];
                }
            }
            QString sqlExport = "SELECT * FROM DET_PRODUCE WHERE TASKID in (" + taskIdDataSql + ")";
            emit signalExport(sqlExport);
        }
    } else {
        QMessageBox::information(this, "提示", "请选择需要导出的任务");
    }
}

void DataManage::on_establishAssignment_clicked()
{
    static ProductionSet dlg(this);
    int ret = dlg.exec();
    if (ret == 1){
        struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
        productedTotalNum = DataManagement::instance()->queryProductedTotalNum();
        cfg->produceNumTotal = productedTotalNum;
        ui->detCount_2->setText(QString("共" + QString::number(m_model->rowCount()) + "个任务," + QString::number(productedTotalNum) + "发"));
        DataManagement::instance()->queryDetProductMission(m_model);
    }
}

void DataManage::on_refreshAssignment_clicked()
{
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
    productedTotalNum = DataManagement::instance()->queryProductedTotalNum();
    cfg->produceNumTotal = productedTotalNum;
    ui->detCount_2->setText(QString("共" + QString::number(m_model->rowCount()) + "个任务," + QString::number(productedTotalNum) + "发"));
    DataManagement::instance()->queryDetProductMission(m_model);
}

void DataManage::on_searchAssignment_clicked()
{
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
    productedTotalNum = DataManagement::instance()->queryProductedTotalNum();
    cfg->produceNumTotal = productedTotalNum;
    ui->detCount_2->setText(QString("共" + QString::number(m_model->rowCount()) + "个任务," + QString::number(productedTotalNum) + "发"));
    DataManagement::instance()->queryDetProductMission(m_model);
}

void DataManage::on_deleteSelected_2_clicked()
{
    if(ui->tableView_2->currentIndex().isValid()){
        QList<QModelIndex> list =  ui->tableView_2->selectionModel()->selectedIndexes();    // 获取当前行数据

        if (list[11].data().toString() == "生产中")
        {
            QMessageBox::information(this, "提示", "请先暂停任务");
        }
        else
        {
            QMessageBox::StandardButton sButton = QMessageBox::question(NULL, (QObject::tr("提示")), (QObject::tr("该数据是否删除!")));
            if (sButton == QMessageBox::StandardButton::Yes)
            {
                int row = ui->tableView_2->currentIndex().row();
                DataManagement::instance()->deleteDet(list[0].data().toInt());
                m_model->removeRows(row, 1);
                struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
                productedTotalNum = DataManagement::instance()->queryProductedTotalNum();
                cfg->produceNumTotal = productedTotalNum;
                ui->detCount_2->setText(QString("共" + QString::number(m_model->rowCount()) + "个任务," + QString::number(productedTotalNum) + "发"));
                QMessageBox::information(this, "提示", "已删除选中");
            }
        }
    }
    else
    {
         QMessageBox::information(this, "提示", "请选中要删除的任务");
    }
}

void DataManage::on_startProduce_clicked()
{
    if(ui->tableView_2->currentIndex().isValid()){
        if (PLCCommProc::instance()->isRunning())
        {
            QMessageBox::information(this, "提示", "请先暂停上一个任务");
        }
        else
        {
            listSelected =  ui->tableView_2->selectionModel()->selectedIndexes();    // 获取当前行数据
            if (listSelected[11].data().toString() == "已完成") {
                QMessageBox::information(this, "提示", "此任务已结束");
            } else if (listSelected[11].data().toString() == "生产中")
            {
                QMessageBox::information(this, "提示", "此任务正在生产中...");
            }
            else
            {
                currentRowParameterSet();    //   获取行当前数据
                struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
                   qDebug()<< QThread::currentThreadId() << QThread::currentThread() << "生产中...";
                    QString msg = QString("已生产%0发,是否继续生产?").arg(listSelected[5].data().toInt());
                    QMessageBox::StandardButton ret = QMessageBox::question(this, "提示", msg);
                    if(ret == QMessageBox::Yes)
                    {
                        cfg->m_currentRunRow = ui->tableView_2->currentIndex().row();

                        if (m_model->rowCount() == cfg->m_currentRunRow)
                        {
                            cfg->finalProduceFlag = true;
                        }
                        else
                        {
                            cfg->finalProduceFlag = false;
                        }
                        PLCCommProc::instance()->startProduce();
                        m_pwd = listSelected[1].data().toString();
                        cfg->taskId = listSelected[1].data().toString();
                        QString productStatus = "生产中";
                        DataManagement::instance()->updataProductMissionState(m_pwd,productStatus);
                        DataManagement::instance()->queryDetProductMission(m_model);
                        QMessageBox::information(this, "提示", "生产中...");
                    }
            }
        }
    } else {
        QMessageBox::information(this, "提示", "请选中要生产的任务");
    }
}

void DataManage::currentRowParameterSet()
{
    QList<QModelIndex> list =  ui->tableView_2->selectionModel()->selectedIndexes();    // 获取当前行数据

    struct ProduceConfigType* config =  AllConfig::instance()->getProduceConfig();

    config->factory =  list[15].data().toInt();
    config->detType =  list[14].data().toInt();
    config->productDate =  list[21].data().toDate().toString("yyyy.MM.dd");
    config->feature = list[16].data().toByteArray().at(0);
    config->numInBox = list[17].data().toInt();
    config->startBox = list[18].data().toInt();
    config->startNo = list[19].data().toInt();
    config->lineLength = list[8].data().toInt();
    config->produceNum = list[4].data().toInt();
    config->produceLineID = list[20].data().toInt();
    config->produceWritedNum = list[5].data().toInt();
    config->codePrefix = list[20].data().toString();
    AllConfig::instance()->saveConfig();

    AllConfig::instance()->readConfig();
}

void DataManage::on_deleteAll_2_clicked()
{
    if (PLCCommProc::instance()->isRunning())
    {
        QMessageBox::information(this, "提示", "请先暂停任务");
    }
    else
    {
        QMessageBox::StandardButton sButton = QMessageBox::question(NULL, (QObject::tr("提示")), (QObject::tr("该数据是否删除!")));
        if (sButton == QMessageBox::StandardButton::Yes)
        {
            int ret = 0;
            int rowCount = m_model->rowCount();
            for(int i = 0; i < rowCount; i++)
            {
                ret |= DataManagement::instance()->deleteDet(m_model->item(i, T_ID)->text().toInt());
            }
            m_model->removeRows(0, m_model->rowCount());
            struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
            productedTotalNum = DataManagement::instance()->queryProductedTotalNum();
            cfg->produceNumTotal = productedTotalNum;
            ui->detCount_2->setText(QString("共" + QString::number(m_model->rowCount()) + "个任务," + QString::number(productedTotalNum) + "发"));
            QMessageBox::information(this, "提示", "已删除所有");
            qDebug()<<__FUNCTION__<<ret;
         }
    }
}

void DataManage::on_pauseProductTask_clicked()
{
     if (ui->tableView_2->currentIndex().isValid())
     {
             listSelected =  ui->tableView_2->selectionModel()->selectedIndexes();    // 获取当前行数据
             if (listSelected[11].data().toString() != "生产中")
             {
                QMessageBox::information(this, "提示", "此任务未生产");
             } else {
                 PLCCommProc::instance()->stopProduce();
                 QString productStatus = "暂停生产";
                 QString currentTaskId = listSelected[1].data().toString();
                 DataManagement::instance()->updataProductMissionState(currentTaskId,productStatus);
                 DataManagement::instance()->queryDetProductMission(m_model);
                 QMessageBox::information(this, "提示", "暂停生产");
             }
     }
     else
     {
        QMessageBox::information(this, "提示", "请选择需要暂停的任务");
     }
}

void DataManage::on_pushButton_clicked()
{

    bool ok;
    QString text = QInputDialog::getText(this, tr("Enter Password"),
                                         tr("Password:"), QLineEdit::Password,
                                         "", &ok);
     if(ok)
        if (text != "12345678")
        {
            QMessageBox::information(this, "提示", "密码输入错误");
            return;
            qDebug() << "Password entered:" << text;
            }
}

void DataManage::printAllSelect()
{
    QList<QModelIndex> list =  ui->tableView_2->selectionModel()->selectedIndexes();
    for (int i=0; i < list.size()/23; i++)
    {
        int T = 1 + i*23;
        QString listExport = list[T].data().toString();
        integerList.append(listExport);
    }
   for(int i=0; i < list.count(); i++ ){

   }

}

void DataManage::onTableClicked(const QModelIndex &index)
 {
     if (index.isValid())
     {
         if(ui->tableView_2->currentIndex().isValid())
         {
             QList<QModelIndex> list =  ui->tableView_2->selectionModel()->selectedIndexes();    // 获取当前行数据
             qDebug() << list.size() << "5453452342";
             if (list.size() > 0)
             {
                 taskIdData = list[1].data().toString();
                 emit signalUpdateProduce(list);
             }
         }

     }
}

void DataManage::slotsCurrentTaskFinished(int num)
{
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
    if (num == cfg->produceNum)
    {
        QString productStatus = "已完成";
        DataManagement::instance()->updataProductMissionState(m_pwd,productStatus);
        runCurentNext();
    }

    AllConfig::instance()->saveConfig();
    DataManagement::instance()->queryDetProductMission(m_model);
}
