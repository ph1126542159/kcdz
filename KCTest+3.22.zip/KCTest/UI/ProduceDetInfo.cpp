﻿#include "ProduceDetInfo.h"
#include "ui_ProduceDetInfo.h"

#include "DBMgr/DBMgr.h"
#include "AllConfig.h"
#include <QHeaderView>
#include <QFileDialog>
#include <QTextEdit>
#include <QTextStream>
#include <QDebug>
#include <QDateTime>
#include <QMessageBox>
#include <iostream>
#include "gen_excel_file.h"
#include <QInputDialog>

#ifdef ENABLE_XLSS
#include <QtXlsx>
#endif

using namespace std;
using namespace generate_excel;

enum TableHeadNo{
    T_ID  = 0 ,
    T_OUTCODE   ,
    T_BARCODE   ,
    T_INCODE    ,
    T_PWD       ,
    T_DETTYPE   ,
    T_PRODUCETIME,
    T_CHANNEL    ,
    T_FAULTCODE  ,
    T_LINE_ID    ,
    T_FACTORY    ,
    T_FEATURE    ,
    T_LINE_LENGTH
};

ProduceDetInfo::ProduceDetInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProduceDetInfo)
{
    ui->setupUi(this);
//    dataManage = new DataManage(this);
    init();
    static QStandardItemModel * theModel; //数据模型

}

ProduceDetInfo::~ProduceDetInfo()
{
    delete ui;
}

bool ProduceDetInfo::exportDataTable_old()
{
    qDebug() << "222222222222";
    QString filepath = QFileDialog::getSaveFileName(this, tr("Save as..."),
            QDateTime::currentDateTime().toString("yyyy-MM-dd hh-mm-ss")+".xls", tr("EXCEL files (*.xls *.xlsx)"));

    if(!filepath.isEmpty()){
        gen_excel_file xls;

        if (SUCCESS != xls.create_file(filepath.toLocal8Bit().data()))
        {
            qDebug()<<filepath<<"open failed"<<endl;
            return false;
        }

        xls.set_column_width(1, 200);
        xls.set_column_width(1, 150);
        xls.set_column_width(1, 150);
        xls.set_column_width(1, 150);
        xls.set_column_width(1, 200);

        xls.start_new_line(16);
        xls.fill_cell(CELL_ROWSPAN(1, 38,BDR_DOUBLE(1.0),""), QString(QStringLiteral("生产时间")).toLocal8Bit().data());
        xls.fill_cell(CELL_ROWSPAN(1, 38,BDR_DOUBLE(1.0),""), QString(QStringLiteral("管壳码")).toLocal8Bit().data());
        xls.fill_cell(CELL_ROWSPAN(1, 38,BDR_DOUBLE(1.0),""), QString(QStringLiteral("条码")).toLocal8Bit().data());
        xls.fill_cell(CELL_ROWSPAN(1, 38,BDR_DOUBLE(1.0),""), QString(QStringLiteral("雷管类型")).toLocal8Bit().data());
        xls.fill_cell(CELL_ROWSPAN(1, 38,BDR_DOUBLE(1.0),""), QString(QStringLiteral("内码")).toLocal8Bit().data());
        xls.end_curr_line();


        int row = m_model->rowCount();
        for (int i = 0; i < row; i++)
        {
            int detType = m_model->item(i, T_DETTYPE)->text().toInt();
            QString type;
            if(detType == 1){
                type = "XA03J-PD1";
            }else{
                type = m_model->item(i, T_DETTYPE)->text();
            }
            xls.start_new_line(16);
            xls.fill_cell(CELL_ROWSPAN(1,38,BDR_DOUBLE(1.0),""), m_model->item(i, T_PRODUCETIME)->text().toLocal8Bit().data());
            xls.fill_cell(CELL_ROWSPAN(1,38,BDR_DOUBLE(1.0),""), m_model->item(i, T_OUTCODE)->text().toLocal8Bit().data());
            xls.fill_cell(CELL_ROWSPAN(1,38,BDR_DOUBLE(1.0),""), m_model->item(i, T_BARCODE)->text().toLocal8Bit().data());
            xls.fill_cell(CELL_ROWSPAN(1,38,BDR_DOUBLE(1.0),""), type.toLocal8Bit().data());
            xls.fill_cell(CELL_ROWSPAN(1,38,BDR_DOUBLE(1.0),""), m_model->item(i, T_INCODE)->text().toLocal8Bit().data());
            xls.end_curr_line();
        }
        xls.end_file();
    }
}

bool ProduceDetInfo::exportDataTable2()
{

#ifdef ENABLE_XLSS
    QString filepath = QFileDialog::getSaveFileName(this, tr("Save as..."),
            QDateTime::currentDateTime().toString("yyyy-MM-dd hh-mm-ss")+".xls", tr("EXCEL files (*.xls *.xlsx)"));

    {
        QXlsx::Document xlsx;

        xlsx.addSheet("生产数据");
        xlsx.write("A1", QString(QStringLiteral("生产时间")));
        xlsx.write("B1", QString(QStringLiteral("管壳码")));
        xlsx.write("C1", QString(QStringLiteral("条码")));
        xlsx.write("D1", QString(QStringLiteral("雷管类型")));
        xlsx.write("E1", QString(QStringLiteral("内码")));

        int row = m_model->rowCount();
        for (int i = 0; i < row; i++)
        {
            int index = i + 2;
            int detType = m_model->item(i, T_DETTYPE)->text().toInt();
            QString type;
            if(detType == 1){
                type = "XA03J-PD1";
            }else if(detType == 2){
                type = "KC3J_MA";
            }else if(detType == 3){
                type = "XA03J-PD2";
            }else {
                type = m_model->item(i, T_DETTYPE)->text();
            }

            xlsx.write(index, 1, m_model->item(i, T_PRODUCETIME)->text());
            xlsx.write(index, 2, m_model->item(i, T_OUTCODE)->text());
            xlsx.write(index, 3, m_model->item(i, T_BARCODE)->text());
            xlsx.write(index, 4, type);
            xlsx.write(index, 5, m_model->item(i, T_INCODE)->text());
        }

        xlsx.saveAs(filepath);
    }
#endif

    return true;
}

void ProduceDetInfo::exportDataByTaskId(QString taskId)
{
   DBMgr::instance()->queryDetCountByTaskId(taskId,m_model);
   exportDataTable();
}

bool ProduceDetInfo::exportDataTable()
{
#ifdef ENABLE_XLSS
    QString filepath = QFileDialog::getSaveFileName(this, tr("Save as..."),
            QDateTime::currentDateTime().toString("yyyy-MM-dd hh-mm-ss")+".xls", tr("EXCEL files (*.xls *.xlsx)"));

    {
        QXlsx::Document xlsx;

        xlsx.addSheet("产品数据");
        xlsx.write("A1", QString(QStringLiteral("生产时间")));
        xlsx.write("B1", QString(QStringLiteral("管码")));
        xlsx.write("C1", QString(QStringLiteral("脚线长度")));
        xlsx.write("D1", QString(QStringLiteral("雷管类型")));
        xlsx.write("E1", QString(QStringLiteral("条码")));


        int row = m_model->rowCount();
        for (int i = 0; i < row; i++)
        {
            int index = i + 2;
            int detType = m_model->item(i, T_DETTYPE)->text().toInt();
            QString type;
            if(detType == 1){
                type = "XA03J-PD1";
            }else if(detType == 2){
                type = "KC3J_MA";
            }else if(detType == 3){
                type = "XA03J-PD2";
            }else {
                type = m_model->item(i, T_DETTYPE)->text();
            }

            xlsx.write(index, 1, m_model->item(i, T_PRODUCETIME)->text());
            xlsx.write(index, 2, m_model->item(i, T_OUTCODE)->text());
            xlsx.write(index, 3, m_model->item(i, T_LINE_LENGTH)->text());
            xlsx.write(index, 4, type);
            xlsx.write(index, 5, m_model->item(i, T_BARCODE)->text());
        }

        xlsx.saveAs(filepath);
    }
#endif

    return true;
}



void ProduceDetInfo::init()
{
    m_model = new QStandardItemModel(10,1,this);


    QStringList headers;
    headers << "ID号" << "管壳码"<<"条码" <<"内码"<<"密码"<<"雷管类型"<<"生产时间"
            <<"通道号"<<"故障码"<<"机台号"<<"工厂码"<<"特征码"<<"脚线长度"<<"编号";
    m_model->setHorizontalHeaderLabels(headers);

    ui->tableView->setModel(m_model);
    ui->tableView->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

    ui->tableView->setColumnHidden(T_ID, true);
    ui->tableView->setColumnHidden(T_PWD, true);

    ui->tableView->setColumnWidth(T_OUTCODE, 150);
    ui->tableView->setColumnWidth(T_BARCODE, 200);
    ui->tableView->setColumnWidth(T_INCODE, 200);
    ui->tableView->setColumnWidth(T_PWD, 150);
    ui->tableView->setColumnWidth(T_DETTYPE, 100);
    ui->tableView->setColumnWidth(T_PRODUCETIME, 220);
    ui->tableView->setColumnWidth(T_CHANNEL, 80);
    ui->tableView->setColumnWidth(T_FAULTCODE, 80);
    ui->tableView->setColumnWidth(T_LINE_ID, 80);
    ui->tableView->setColumnHidden(T_FACTORY, true);
    ui->tableView->setColumnHidden(T_FEATURE, true);
    ui->tableView->setColumnHidden(T_LINE_LENGTH, true);

    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_model->removeRows(0, m_model->rowCount());

    /////////////////////
    m_modelError = new QStandardItemModel(10,1,this);
    m_modelError->setHorizontalHeaderLabels(headers);

    ui->tableViewError->setModel(m_modelError);
    ui->tableViewError->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

    ui->tableViewError->setColumnHidden(T_ID, true);
    ui->tableViewError->setColumnHidden(T_PWD, true);

    ui->tableViewError->setColumnWidth(T_OUTCODE, 150);
    ui->tableViewError->setColumnWidth(T_BARCODE, 200);
    ui->tableViewError->setColumnWidth(T_INCODE, 200);
    ui->tableViewError->setColumnWidth(T_PWD, 150);
    ui->tableViewError->setColumnWidth(T_DETTYPE, 100);
    ui->tableViewError->setColumnWidth(T_PRODUCETIME, 220);
    ui->tableViewError->setColumnWidth(T_CHANNEL, 80);
    ui->tableViewError->setColumnWidth(T_FAULTCODE, 80);
    ui->tableViewError->setColumnWidth(T_LINE_ID, 80);
    ui->tableView->setColumnHidden(T_FACTORY, true);
    ui->tableView->setColumnHidden(T_FEATURE, true);
    ui->tableView->setColumnHidden(T_LINE_LENGTH, true);

    ui->tableViewError->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_modelError->removeRows(0, m_modelError->rowCount());

    //////////////////////////////

#if 0
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();

    struct DetInfo det;

    det.detType = 1;
    det.statusCode = 0;
    det.channel = 1;
    det.productionLineID = cfg->produceLineID;
    det.lineLength = cfg->lineLength;
    det.factory = cfg->factory;
    det.feature = cfg->feature;
    det.detDate = QDate::fromString(cfg->productDate, "yyyy.MM.dd");
    det.produceTime = QDateTime::currentDateTime();


    for(int i = 10; i < 22; i++){
        det.no = (cfg->startBox + (cfg->startNo + cfg->produce_pos + i)/cfg->numInBox) * 100 + ((cfg->startNo + cfg->produce_pos + i)%cfg->numInBox);

        struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();
        QDate date = QDate::fromString(cfg->productDate, "yyyy.MM.dd");
        QString codePrefix = QString("").asprintf("%02d%d%02d%02d%c",cfg->factory, date.year()%10,
                         date.month(), date.day(), cfg->feature);
        det.outcode = codePrefix.toLocal8Bit()
                + QString("").asprintf("%03d%02d",
                                       (cfg->startBox + (cfg->startNo + cfg->produce_pos + i)/cfg->numInBox)
                                       , ((cfg->startNo + cfg->produce_pos + i)%cfg->numInBox) ).toLocal8Bit();
        det.barcode = det.outcode + (char)(det.detType + '0');
        det.incode  = "0011223300112233";
        det.pwd     = "00112233";

//        det.outcode = "523020590010";
//        det.outcode.append(i + '0');
//        det.no = QString(det.outcode.mid(8, 5)).toInt();
//        qDebug()<<QString(det.outcode.mid(8, 5))<<det.no;
        DBMgr::instance()->insertDet(det);
    }

//    DBMgr::instance()->insertDet(det);
//    DBMgr::instance()->insertDet(det);
//    DBMgr::instance()->insertDet(det);


    DBMgr::instance()->queryDet(m_model);
    ui->detCount->setText(QString("共" + QString::number(m_model->rowCount()) + "发雷管"));

#endif
}


void ProduceDetInfo::on_exportData_clicked()
{
    exportDataTable();
}

void ProduceDetInfo::on_searchData_clicked()
{
    const QDateTime start_time = ui->startTime->dateTime();
    const QDateTime end_time = ui->endTime->dateTime();
    DBMgr::instance()->queryDetByProduceTime(start_time, end_time, m_model);

    ui->detCount->setText(QString("共" + QString::number(m_model->rowCount()) + "发雷管"));
}

void ProduceDetInfo::on_searchOutside_clicked()
{
    QString startout =  ui->startOutside->text();
    QString endout =  ui->endOutside->text();

    if(startout.size() != 13){
        QMessageBox::information(this, "提示", "管码输入有误");
        qDebug()<<"start outcode error";
        return ;
    }
    if(endout.size() != 13){
        QMessageBox::information(this, "提示", "管码输入有误");
        qDebug()<<"end outcode error";
        return ;
    }
    //工厂码 年 月 日 特征码  盒号 序号
    QByteArray array = startout.toLocal8Bit();
    int factory = (array.at(0)-'0') * 10 + (array.at(1)-'0');
    int year = (array.at(2)-'0');
    int month = (array.at(3)-'0') * 10 + (array.at(4)-'0');
    int day = (array.at(5)-'0') * 10 + (array.at(6)-'0');
    QByteArray featureArr; featureArr.append(array.at(7));

    int start = QString(array.mid(8, 5)).toInt();

    array = endout.toLocal8Bit();
    int end = QString(array.mid(8, 5)).toInt();

    QDate date;
    date.setDate(year + 2020, month, day);

    DBMgr::instance()->queryDetByOutcode(factory, date, featureArr, start, end, m_model);

    ui->detCount->setText(QString("共" + QString::number(m_model->rowCount()) + "发雷管"));
}

void ProduceDetInfo::on_searchAll_clicked()
{
    DBMgr::instance()->queryDet(m_model);

    ui->detCount->setText(QString("共" + QString::number(m_model->rowCount()) + "发雷管"));
}

void ProduceDetInfo::on_deleteSelected_clicked()
{
    bool ok;
    QString text = QInputDialog::getText(this, tr("Enter Password"),
                                         tr("Password:"), QLineEdit::Password,
                                         "", &ok);
    if(ok)
    {
        if (text != "12345678")
        {
            QMessageBox::information(this, "提示", "密码输入错误");
            return;
        }
    }
    else
    {
        return;
    }
    if(ui->tableView->currentIndex().isValid()){
        int row = ui->tableView->currentIndex().row();
        DBMgr::instance()->deleteDet(m_model->item(row, T_ID)->text().toInt());
        m_model->removeRows(row, 1);
        QMessageBox::information(this, "提示", "已删除选中");
    }
}

void ProduceDetInfo::on_deleteAll_clicked()
{
    bool ok;
    QString text = QInputDialog::getText(this, tr("Enter Password"),
                                         tr("Password:"), QLineEdit::Password,
                                         "", &ok);
    if(ok)
    {
        if (text != "12345678")
        {
            QMessageBox::information(this, "提示", "密码输入错误");
            return;
        }
    }
    else
    {
        return;
    }
    int ret = 0;
    int rowCount = m_model->rowCount();
    for(int i = 0; i < rowCount; i++)
    {
        ret |= DBMgr::instance()->deleteDet(m_model->item(i, T_ID)->text().toInt());
    }
    m_model->removeRows(0, m_model->rowCount());

    QMessageBox::information(this, "提示", "已删除所有");
    qDebug()<<__FUNCTION__<<ret;

}

void ProduceDetInfo::on_tabWidget_currentChanged(int index)
{

}

void ProduceDetInfo::on_pushButton_clicked()
{
     DBMgr::instance()->queryDetByErrorCode(m_modelError);
}

void ProduceDetInfo::on_pushButton_2_clicked()
{
    DBMgr::instance()->queryDetNormalCode(m_model);

    ui->detCount->setText(QString("共" + QString::number(m_model->rowCount()) + "发雷管"));
}

void ProduceDetInfo::on_foreShift_clicked()
{
    QDate date = QDate::currentDate();
    QString moTime = date.toString("yyyy-MM-dd") + " 06:00:00";
    QString afTime = date.toString("yyyy-MM-dd") + " 14:00:00";
    ui->startTime->setDateTime(QDateTime::fromString(moTime, "yyyy-MM-dd hh:mm:ss"));
    ui->endTime->setDateTime(QDateTime::fromString(afTime, "yyyy-MM-dd hh:mm:ss"));
}

void ProduceDetInfo::on_nightShift_clicked()
{
    QDate date = QDate::currentDate();
    QString moTime = date.toString("yyyy-MM-dd") + " 14:00:00";
    QString afTime = date.toString("yyyy-MM-dd") + " 22:00:00";
    ui->startTime->setDateTime(QDateTime::fromString(moTime, "yyyy-MM-dd hh:mm:ss"));
    ui->endTime->setDateTime(QDateTime::fromString(afTime, "yyyy-MM-dd hh:mm:ss"));
}
