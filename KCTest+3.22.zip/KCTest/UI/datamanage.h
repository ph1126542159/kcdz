#ifndef DATAMANAGE_H
#define DATAMANAGE_H

#include <QWidget>
#include <QTableView>
#include <QStandardItemModel>
#include <QStandardItem>
#include "./DBMgr/datamanagement.h"
#include "./DBMgr/DBMgr.h"
#include "PLCCommProc.h"
#include "ProductionSet.h"
#include "ProduceDetInfo.h"
namespace  Ui{
    class DataManage;
}

class DataManage:public QWidget
{
     Q_OBJECT
public:
    static DataManage* instance(){
        static DataManage* _single = new DataManage();
        return _single;
    }
    explicit DataManage(QWidget *parent = nullptr);
    ~DataManage();
    void init();
    void refreshErrAndAcc(int &accomplishNum);
    bool runCurentNext(); //当前任务执行结束后 运行下一个任务
    bool exportDataTable();
    QString m_pwd;   // 全局标识符
    int productedTotalNum;  // 生产总数
    int hasProductedTotalNum; //已经生产的总数
    QString taskIdData;
    QList<QString> integerList; // 导出数据
public slots:
    void slotsRefreshTable();
    void slotsProduceFinished(int num); // 生产完成信号
    void onTableClicked(const QModelIndex &index);
    void slotsCurrentTaskFinished(int num); // 当前生产

private slots:
    void on_exportSelectedData_clicked();

//    void on_finishAssignment_clicked();

    void on_establishAssignment_clicked();

    void on_refreshAssignment_clicked();

    void on_searchAssignment_clicked();
    
    void on_deleteSelected_2_clicked();

    void on_startProduce_clicked();

    void on_deleteAll_2_clicked();

    void on_pauseProductTask_clicked();

    void on_pushButton_clicked();

    void printAllSelect();

signals:
    void signalsStart();
    void signalsEnd();
    void signalExport(QString taskId);
    void signalUpdateProduce(QList<QModelIndex> list);

private:
     Ui::DataManage *ui;
     QStandardItemModel* m_model;
     void currentRowParameterSet();  // 当前行参数设置

     QList<QModelIndex> listSelected;
     int m_currentRunRow;   // 当前运行的行数
     PLCCommProc *m_plcCommProc;
     QString lastTaskId;

};

#endif // DATAMANAGE_H
