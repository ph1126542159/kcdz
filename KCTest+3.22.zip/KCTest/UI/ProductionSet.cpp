﻿#include "ProductionSet.h"
#include "ui_ProductionSet.h"
#include "./DBMgr/DBMgr.h"
#include "AllConfig.h"
#include <QFile>
#include <QDir>
#include <QMessageBox>

ProductionSet::ProductionSet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProductionSet)
{
    ui->setupUi(this);

    AllConfig::instance();

    struct ProduceConfigType* config =  AllConfig::instance()->getProduceConfig();
    ui->productDate->setDate(QDate::fromString(config->productDate, "yyyy.MM.dd"));
    ui->lineLength->setText(QString::number(config->lineLength)); //脚线长度
    ui->machineIDSet->setText(QString::number(config->produceLineID));
    ui->numberInBox->setText(QString::number(config->numInBox));  //盒内数量
    ui->boxMin->setText(QString::number(config->startBox)); //起始盒号
    ui->serialMin->setText(QString::number(config->startNo));  //起始序号
    ui->detCount->setText(QString::number(config->produceNum));  //生产数量
     qDebug() <<  QDate::fromString(config->productDate, "yyyy.MM.dd") << "909090";
}

ProductionSet::~ProductionSet()
{
    delete ui;
}

bool ProductionSet::preinstallInit()
{

}

void ProductionSet::on_ok_clicked()
{
    bool item;
    QByteArray featureArr = ui->feature->text().toLocal8Bit();
    if(featureArr.size() != 1){
        QMessageBox::information(this, "提示", "特征码输入有误");
        return ;
    }else {
        char ff = featureArr.at(0);
        if( (ff >= '0' && ff <= '9') || (ff >= 'A' && ff <= 'F') || (ff >= 'a' && ff <= 'f')){
            ;
        }else{
            QMessageBox::information(this, "提示", "特征码输入有误");
            return ;
        }
    }

    if(ui->numberInBox->text().toInt() < 0){
        QMessageBox::information(this, "提示", "盒内数量应>0");
        return ;
    }

    if(ui->numberInBox->text().toInt() % 5 != 0){
        QMessageBox::information(this, "提示", "生产数量应为5的倍数");
        return ;
    }

    struct DetProductMission config;
    config.feature = ui->feature->text().toLocal8Bit().at(0);
    config.productDate = ui->productDate->date().toString("yyyy-MM-dd");
    config.lineLength = ui->lineLength->text().toInt(); //脚线长度
    config.productionLineID = ui->machineIDSet->text().toInt(); // 机台号
    config.numberInBox = ui->numberInBox->text().toInt();  //盒内数量
    config.startBox = ui->boxMin->text().toInt(); //起始盒号
    config.startNo = ui->serialMin->text().toInt();  //起始序号
    config.assignmentNum = ui->detCount->text().toInt();  //生产数量
    config.factory = ui->factory->text().toInt();
    config.detType = ui->detType->currentIndex() + 1;
    config.detDate = QDate::fromString(ui->productDate->date().toString(), "yyyy-MM-dd hh:mm:ss");

    QDate date = ui->productDate->date();
    QString codePrefixTemp = QString("").asprintf("%02d%d%02d%02d%c",config.factory, date.year()%10,
                     date.month(), date.day(), config.feature);
    int Range = config.assignmentNum;
    int rang1 = ui->detCount->text().toInt()/ui->numberInBox->text().toInt() - 1 + ui->boxMin->text().toInt();
    int rang2 = ui->numberInBox->text().toInt() - 1;
    QString strNew = QString("%1").arg(Range, 5, 10, QLatin1Char('0'));
    QString rang1Str = QString("%1").arg(rang1, 3, 10, QLatin1Char('0'));
    QString rang2Str = QString("%1").arg(rang2, 2, 10, QLatin1Char('0'));
    QString rang12Str = rang1Str + rang2Str;
    int rang12int = rang12Str.toInt();
    QString startBoxStr = QString("%1").arg(ui->boxMin->text().toInt(), 3, 10, QLatin1Char('0'));
    QString startBoxStrTemp = startBoxStr + "00";
    config.encipherRange = codePrefixTemp + "(" + startBoxStrTemp +"-" + rang12Str + ")";
    QString encipherRangeMax = codePrefixTemp + rang12Str;
    QString encipherRangeMin = codePrefixTemp + startBoxStrTemp;
    item = DBMgr::instance()->queryInitialSqlCheck(encipherRangeMin, encipherRangeMax);
    if(item > 0)
    {
        QMessageBox::information(this, "提示", "数据库有重复的管壳码");
        return;
    }
    DataManagement::instance()->insertDetProduceData(config);
    emit setProduceConfig();
    emit signalsRefreshTable();
    DataManage::instance()->slotsRefreshTable();
    done(1);
}
