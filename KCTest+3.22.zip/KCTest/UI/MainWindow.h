﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "PLCCommProc.h"
#include "ChannelCmd.h"
#include "ULog/ulog.h"
#include <QModelIndex>
#include <QList>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    static MainWindow* instance()
    {
        static MainWindow* _single = new MainWindow();
        return _single;
    }
    ~MainWindow();

signals:
    void sigStart();
    void sigEnd();

public slots:
    void on_exit_triggered();

    void on_serialPortSet_triggered();

    void on_paraSet_clicked();

    void on_startProduce_clicked();

    void slot_WriteCodePLCStatus(int heart, bool writeCodeOK, bool tiaohao, bool butiaohao, ushort lineLength);
    void slot_WriteCodeStatus(int status);
    void slot_WriteCodeRslt(QList<QByteArray> M_outcodesCH, QList<QByteArray> M_faultcodes);
    void slot_ProduceFinished(int num);

    void slot_ConnectStatus(bool plc, bool ch);

    void slot_PreCheckStatus(int status, int rslt);

    void slot_writeLog(QString log);

    void updateProduceConfigDisp(QList<QModelIndex> list);

private slots:
    void on_about_triggered();

protected:
    virtual void closeEvent(QCloseEvent *event);

private:
    explicit MainWindow(QWidget *parent = nullptr);

    void updateSerialPortCfg();


private:
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
