﻿#ifndef PRODUCEDETINFO_H
#define PRODUCEDETINFO_H

#include <QWidget>
#include <QTableView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <datamanage.h>

namespace Ui {
class ProduceDetInfo;
}

class ProduceDetInfo : public QWidget
{
    Q_OBJECT

public:
    static ProduceDetInfo* instance(){
        static ProduceDetInfo* _single = new ProduceDetInfo();
        return _single;
    }
    explicit ProduceDetInfo(QWidget *parent = nullptr);
    ~ProduceDetInfo();
    bool exportDataTable_old();
    bool exportDataTable();
    bool exportDataTable2();

    QStandardItemModel* m_model;

public slots:
    void exportDataByTaskId(QString taskId);

private slots:
    void on_exportData_clicked();

    void on_searchData_clicked();

    void on_searchOutside_clicked();

    void on_searchAll_clicked();

    void on_deleteSelected_clicked();

    void on_deleteAll_clicked();

    void on_tabWidget_currentChanged(int index);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_foreShift_clicked();

    void on_nightShift_clicked();

private:
    void init();

private:
    Ui::ProduceDetInfo *ui;

    QStandardItemModel* m_modelError;

};

#endif // PRODUCEDETINFO_H
