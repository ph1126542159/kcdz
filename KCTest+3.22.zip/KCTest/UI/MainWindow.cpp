﻿#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QMessageBox>
#include <QDebug>
#include <QTimer>
#include "AllConfig.h"
#include "UI/ProductionSet.h"
#include "UI/SerialPortSet.h"
#include "UI/ProductionSet.h"

#include "ChannelCmd.h"
#include "PLCCommProc.h"
#include "PLCCmd.h"
#include "datamanage.h"
#include "ProduceDetInfo.h"
#include <QVBoxLayout>
#include "LogWidget.h"
#include <QMetaType>
#include "ULog/ulog.h"
#include "PlcPreCheckProc.h"
#include <QFile>
#include <QDir>
#include <QThread>
#include "ChPreCheckWork.h"
#include "PLCCommProc.h"
#include "ChannelProc.h"
#include "Mgr.h"
#include <QCloseEvent>


#define VERSION  "v1.35"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    AllConfig::instance();

//    updateProduceConfigDisp();

    this->setWindowIcon(QIcon(":/icon/KunIcon.PNG"));
    this->setWindowTitle("鲲程三码软件");

    ProduceDetInfo * detInfo = new ProduceDetInfo(ui->tab_3);

    connect(ui->tab_5, &DataManage::signalExport, detInfo, &ProduceDetInfo::exportDataByTaskId);
    connect(ui->tab_5, &DataManage::signalUpdateProduce, this, &MainWindow::updateProduceConfigDisp);
    QVBoxLayout* layout = new QVBoxLayout(ui->tab_3);
    ui->tab_3->setLayout(layout);
    layout->addWidget(detInfo);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::slot_writeLog(QString log)
{
    ui->textBrowser->append(log);
}

void MainWindow::on_exit_triggered()
{
    QMessageBox::StandardButton sButton = QMessageBox::question(NULL, (QObject::tr("提示")), (QObject::tr("关闭软件!")));
    if (sButton == QMessageBox::StandardButton::Yes)
    {
        this->close();
    }
}

void MainWindow::updateProduceConfigDisp(QList<QModelIndex> list)
{
   qDebug() << list[15].data().toString() << "90909090";
   qDebug() << QDate::fromString(list[21].data().toDate().toString("yyyy-MM-dd"),"yyyy-MM-dd") << "09090909";
    ui->factory->setText(list[15].data().toString());
    ui->detType->setText(list[14].data().toString());
    ui->feature->setText(list[16].data().toString());
    ui->productDate->setDate(QDate::fromString(list[21].data().toDate().toString("yyyy-MM-dd"),"yyyy-MM-dd"));
    ui->lineLength->setText( list[8].data().toString()); //脚线长度
    ui->numberInBox->setText(list[17].data().toString());  //盒内数量
    ui->startBox->setText(list[18].data().toString()); //起始盒号
    ui->startNo->setText(list[19].data().toString());
    ui->produceNum->setText(list[4].data().toString());
    ui->machineID->setText(list[20].data().toString());
    ui->finishedNum->setText(list[5].data().toString());
//    ui->preview->setText(AllConfig::instance()->getPreviewOutCode());
}

void MainWindow::updateSerialPortCfg()
{

}

void MainWindow::on_serialPortSet_triggered()
{
    SerialPortSet dlg(this);
    if(dlg.exec() == 1){
        updateSerialPortCfg();
     }else
        return ;
}


void MainWindow::on_paraSet_clicked()
{
    struct ProduceConfigType* config =  AllConfig::instance()->getProduceConfig();

    QByteArray featureArr = ui->feature->text().toLocal8Bit();

    if(featureArr.size() != 1){
        QMessageBox::information(this, "提示", "特征码输入有误");
        return ;
    }else {
        char ff = featureArr.at(0);
        if( (ff >= '0' && ff <= '9') || (ff >= 'A' && ff <= 'F') || (ff >= 'a' && ff <= 'f')){
            ;
        }else{
            QMessageBox::information(this, "提示", "特征码输入有误");
            return ;
        }
    }

    config->factory = ui->factory->text().toInt();
    config->detType = ui->detType->text().toInt();

    config->productDate = ui->productDate->date().toString("yyyy.MM.dd");

    config->feature = ui->feature->text().toLocal8Bit().at(0);

    config->numInBox = ui->numberInBox->text().toInt();
    if(config->numInBox < 0){
        QMessageBox::information(this, "提示", "盒内数量应>0");
        return ;
    }

    config->startBox = ui->startBox->text().toInt();
    config->startNo = ui->startNo->text().toInt();
    config->lineLength = ui->lineLength->text().toInt();
    config->produceNum = ui->produceNum->text().toInt();
    if(config->numInBox % 5 != 0){
        QMessageBox::information(this, "提示", "生产数量应为5的倍数");
        return ;
    }
    config->produceLineID = ui->machineID->text().toInt();

    config->produceWritedNum = ui->finishedNum->text().toInt();
    qDebug() << "---"<< config->factory << config->detType<<config->productDate<<config->feature<<config->numInBox<<config->startBox<< config->startNo <<config->lineLength<<config->produceNum << config->produceLineID << config->produceWritedNum;

    AllConfig::instance()->saveConfig();

    AllConfig::instance()->readConfig();

//    updateProduceConfigDisp();

    QMessageBox::information(this, "提示", "设置成功");

}

void MainWindow::on_startProduce_clicked()
{
    if(PLCCommProc::instance()->isRunning()){
        ui->paraSet->setDisabled(false);
        emit sigEnd();
        ui->startProduce->setText("启动生产");
        qDebug()<< QThread::currentThreadId() << QThread::currentThread() <<"启动生产";

    } else{
        struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();

        //if(ui->finishedNum->text().toInt() != 0)
        {
            QString msg = QString("已生产%0发,是否继续生产?").arg(cfg->produceWritedNum);
            QMessageBox::StandardButton ret = QMessageBox::question(this, "提示", msg);
            if(ret == QMessageBox::Yes)
            {
                ui->paraSet->setDisabled(true);
                emit sigStart();
                ui->startProduce->setText("生产中...");
                qDebug()<< QThread::currentThreadId() << QThread::currentThread() << "生产中...";
            }
        }
    }
}



void MainWindow::slot_WriteCodePLCStatus(int heart, bool writeCodeOK, bool tiaohao, bool butiaohao, ushort lineLength)
{
    ui->plcHeart->setText(QString::number(heart));
    ui->enableWriteCode->setChecked(writeCodeOK);
    ui->tiaohaoReset->setChecked(tiaohao);
    ui->butiaohaoReset->setChecked(butiaohao);
}

void MainWindow::slot_WriteCodeStatus(int status)
{

    if(status == RcvWriteCmd){
        ui->recvWriteCodeCmd->setChecked(true);
        ui->produce_status->setText("收到PLC写码指令");
    }
    else if(status == WriteFinished)
    {
        ui->writeCodeFinished->setChecked(true);
        ui->writeCodeOK->setChecked(true);
        ui->produce_status->setText("赋码仪写码完成");
    }
    else if(status == TiaoHao)
    {
        ui->recvWriteCodeCmd->setChecked(false);
        ui->writeCodeFinished->setChecked(false);
        ui->writeCodeOK->setChecked(false);
        ui->produce_status->setText("收到PLC跳号指令");
    }
    else if(status == BuTiaoHao)
    {
        ui->recvWriteCodeCmd->setChecked(false);
        ui->writeCodeFinished->setChecked(false);
        ui->writeCodeOK->setChecked(false);
        ui->produce_status->setText("收到PLC不跳号指令");
    }

}

void MainWindow::slot_WriteCodeRslt(QList<QByteArray> outcodesCH, QList<QByteArray> faultcodes)
{
    qDebug()<<"#codes = "<<outcodesCH;
    qDebug()<<"#failedcodes = "<<faultcodes;
    if(outcodesCH.size() == 5 && faultcodes.size() == 5)
    {
        ui->outcode->setText(outcodesCH.at(0));
        ui->error->setText(QString::number(faultcodes.at(0).at(1)));

        ui->outcode_2->setText(outcodesCH.at(1));
        ui->error_2->setText(QString::number(faultcodes.at(1).at(1)));

        ui->outcode_3->setText(outcodesCH.at(2));
        ui->error_3->setText(QString::number(faultcodes.at(2).at(1)));

        ui->outcode_4->setText(outcodesCH.at(3));
        ui->error_4->setText(QString::number(faultcodes.at(3).at(1)));

        ui->outcode_5->setText(outcodesCH.at(4));
        ui->error_5->setText(QString::number(faultcodes.at(4).at(1)));
    }
}


void MainWindow::slot_ConnectStatus(bool plc, bool ch)
{
    static bool plcStatus = false;
    if(plcStatus != plc){
        plcStatus = plc;
        if(plc){
            ui->plcConnected->setText("已连接");
            ui->plcConnected->setStyleSheet("color: rgb(0, 170, 0);");
        }else{
            ui->plcConnected->setText("未连接");
            ui->plcConnected->setStyleSheet("color: rgb(170, 0, 0);");
        }
    }
}



void MainWindow::slot_ProduceFinished(int num)
{
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();

    ui->numWrited->setText(QString::number(num));

    if(cfg->produceWritedNum >= cfg->produceNum && AllConfig::instance()->getProduceConfig()->finalProduceFlag)
    {
        QMessageBox::information(this, "提示", QString("生产完成，生产数量：%0").arg(num));
    }
    AllConfig::instance()->saveConfig();
    ui->finishedNum->setText(QString::number(cfg->produceWritedNum));
}

void MainWindow::slot_PreCheckStatus(int status, int rslt)
{
    struct ProduceConfigType* cfg = AllConfig::instance()->getProduceConfig();

    if(status == 1){
        ui->precheck_status->setText("收到PLC检测指令");
    }else if(status == 2){
        ui->precheck_status->setText("收到PLC检测复位指令");
    }
}


void MainWindow::on_about_triggered()
{
    QMessageBox::information(this, QString("关于鲲程三码软件")+VERSION, QString("<font size='8'>本软件由<b>上海鲲程电子科技有限公司</b>研制并提供技术支持</font>"));
}

void MainWindow::closeEvent(QCloseEvent *event)
{

    QMessageBox::StandardButton sButton = QMessageBox::question(NULL, (QObject::tr("提示")), (QObject::tr("关闭软件!")));
    if (sButton == QMessageBox::StandardButton::Yes)
    {
        this->close();
    }
    else
    {
       event->ignore();
    }
}
