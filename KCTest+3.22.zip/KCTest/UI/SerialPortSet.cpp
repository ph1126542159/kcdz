﻿#include "SerialPortSet.h"
#include "ui_SerialPortSet.h"
#include <QStringList>
#include <QSerialPortInfo>
#include "AllConfig.h"
#include <QDebug>
#include <QFile>
#include <QDir>

SerialPortSet::SerialPortSet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SerialPortSet)
{
    ui->setupUi(this);

    QStringList serialportInfo;
    foreach(QSerialPortInfo info, QSerialPortInfo::availablePorts()){
        serialportInfo<<info.portName();
    }

    ui->port1->addItems(serialportInfo);
    ui->preCheckport->addItems(serialportInfo);


    struct ProduceConfigType* config = AllConfig::instance()->getProduceConfig();

    ui->port1->setCurrentText(config->channel_port);
    ui->ip->setText(config->plc_ip);
    ui->preCheckport->setCurrentText(config->precheckCh_port);
    qDebug()<<config->plc_ip<<config->channel_port<<ui->preCheckport;

}

SerialPortSet::~SerialPortSet()
{
    delete ui;
}

void SerialPortSet::on_ok_clicked()
{
    struct ProduceConfigType* config = AllConfig::instance()->getProduceConfig();
    config->channel_port = ui->port1->currentText();
    config->plc_ip = ui->ip->text();
    config->precheckCh_port = ui->preCheckport->currentText();

    AllConfig::instance()->saveConfig();


    qDebug()<<config->channel_port<<config->plc_ip<<config->precheckCh_port;
    this->done(1);
}
