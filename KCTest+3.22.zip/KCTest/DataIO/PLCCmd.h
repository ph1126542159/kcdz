﻿#ifndef PLCCMD_H
#define PLCCMD_H

#include <QObject>
#include <qtcpserver.h>
#include <qtcpsocket.h>

#pragma pack(1)
struct ConnectFrame{
    uchar fins[4];
    uchar len[4];
    uchar funcCode[4];
    int errcode;
    uchar selfIp[4];
};


struct DataFrame{
    uchar fins[4];
    int len;
    int funcCode;
    int errcode;

    uchar icf; //发送0x80 响应0xC0
    uchar rsv; //固定0x00
    uchar gct; //固定0x02
    uchar dna;
    uchar da1; //目标IP
    uchar da2;
    uchar sna;
    uchar sa1; //源IP
    uchar sa2;
    uchar sid;

    ushort cmd;
    uchar area;
    ushort addr;
    uchar offset;
    ushort countW;
};

#pragma pack()


struct WriteCodeRead_Reply{
    uchar head[30];
    uchar heartH;
    uchar heartL;
    uchar reserver[48];
};


class PLCCmd: public QObject
{
     Q_OBJECT
public:
    explicit PLCCmd(QObject *parent = nullptr);

    void init(const QString& hostName, quint16 port, int local_ip);

    bool isConnected();

    int getSocketPort();

    void ReConnect();

    bool TcpConnect();
    bool FinsConnect();

    bool PreCheck_Read(int& heart, bool& startPreCheck, bool& reset);
    bool WriteCode_Read(int& heart, bool& writeCodeOK, bool& tiaohao, bool& butiaohao, ushort& lineLength);
    bool Recheck_Read(int& heart, bool& startReCheck, bool& reset);



    bool PreCheck_Write(ushort heart, bool enPreCheck, bool recvCheck,
                        bool finished, char rslt);

    bool PreCheck_Write(QByteArray& data);

    bool PreCheck_WriteHeart(ushort heart);


    bool WriteCode_Write(ushort heart, bool enWriteCode, bool codeUsed, bool recvWrite,
                         bool writeFinished, bool writed, char rslt,
                         const QByteArray& codes, const QByteArray& failedcodes,
                         ushort len, ushort num, ushort writedNUm);

    bool WriteCode_WriteHeart(); //写码中
    bool WriteCode_WriteWrittingCode(); //写码中
    bool WriteCode_WriteWriteCodeFinished(uchar rslt, QList<QByteArray>& outcodes, QList<QByteArray>& failedcodes); //写码完成
    bool WriteCode_WriteBuTiaoHao();  //不跳号
    bool WriteCode_WriteTiaoHao();    //跳号

    bool WriteCode_WriteProduceNum(); //
    bool WriteCode_WriteHeart2(); //写码中



    bool Recheck_Write(ushort heart, bool enReCheck, bool recvReCheck,
                        bool recheckFinished, char rslt,
                       const QByteArray& codes, const QByteArray& failedcodes);


    bool xWR_sendWritedRslt(QByteArray& outcodes_toPlc, QByteArray& failedcodes);
    bool xWR_finishedWrite(QByteArray& outcodes_toPlc, QByteArray& failedcodes);




    bool PreCheck_Write_R();
    bool WriteCode_Write_R();
    bool Recheck_Write_R();

    QTcpSocket m_socket;

//private:
    void FinsConnectFrame(ConnectFrame& frame);

    bool packData(short cmd, uchar area, ushort addr, uchar offset, ushort num, const QByteArray& content, QByteArray& packedData);

    bool unpackData(const QByteArray& data, int& funcCode, ushort& cmd, QByteArray& content);

    bool  m_tcpConnect = false;
    bool  m_finsConnect = false;

        int m_funcCode = 0;
signals:
    void sigConnect(bool connect);

private:

    QByteArray m_sendData;
    QByteArray m_recvData;

    QByteArray m_preCheckWrite_Reply;
    QByteArray m_writeCodeWrite_Reply;
    QByteArray m_recheckWrite_Reply;

    QByteArray m_preCheckRead_Reply;
    QByteArray m_writeCodeRead_Reply;
    QByteArray m_recheckRead_Reply;

    ushort m_preCheckHeart;
    ushort m_writeCodeHeart;
    ushort m_recheckHeart;


//    ushort m_heart;
//    bool m_enWriteCode;
//    bool m_codeUsed;
//    bool m_recvWrite;
//    bool m_writeFinished;
//    bool m_writed;
//    char m_rslt;
//    QByteArray m_outcodes;
//    QByteArray m_failedcodes;
//    ushort m_len;
//    ushort m_num;
//    ushort m_writedNum;

    QString m_hostName;
    quint16 m_port;
    uchar m_localIp;

};

#endif // PLCCMD_H
