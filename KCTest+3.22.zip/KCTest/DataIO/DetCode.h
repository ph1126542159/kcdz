﻿#ifndef DETCODE_H
#define DETCODE_H

typedef unsigned long long uint64;

#pragma pack(1)

struct xIncode{ //8字节 转换成字符串 16字节  小端  serl放小端
    uint64 inBox    :7; // 盒内流水号 值域：[0,99]  bit0-bi6共7位
    uint64 box      :10;// 盒号   值域：[0,999]    bit7-bit16共10位
    uint64 day      :5; // 日     值域：[1,31]     bit17-bit21共5位
    uint64 month    :4; // 月     值域：[1,12]     bit22-bit25共4位
    uint64 yearl    :1; // 年的低位                bit26 共1位
    uint64 feature  :8; // 特征号  值域：字符     bit27-bit34共8位
    uint64 year     :4; // 年     值域：[0, 15]    bit35-bit38共4位 if year >= 5 and year <= 9:   year += 2010 else: year += 2020
    uint64 factory  :7; // 工厂代码 值域：[1,71]    bit39-bit45共7位
    uint64 detType  :5; // 雷管类型 值域：          bit46-bit50共5位
    uint64 reserve  :5; // 保留    值域：=0        bit51-bit55共5位 值域：为0
    uint64 crc      :8; // CRC8校验               bit56-bit63共8位 //前7个字节CRC8校验取反 (~GetCrc8Value(Buffer, 7))&0xFF;
};

struct xIncode_SerlPwd{
    int serl;
    int pwd;
};

struct xOutcode{ //13字节
    char factory[2];
    char year;
    char month[2];
    char day[2];
    char feature;
    char box[3];
    char inBox[2];
};



//南理工(22)+山东圣世达(36):适应起爆器扫码规则 条码=0+管壳码
struct xbarcode1{//14字节
    char detType;  //'0'
    char outcode[13]; //管壳码
};

//其他管厂通用规则：条码=管壳码+雷管类型 （条码信息全部小写转大写）
struct xbarcode2{//14字节
    char outcode[13]; //管壳码
    char detType;   //16进制显示
};
///////////////////////


//Date >= 20200527
struct xUID_ZTL{ //13字节
    char factory[2];
    char year[2]; //年份用2位表示
    char month; //月份用1位表示，1-9表示1-9月，A表示10月，C表示11月，D表示12月
    char day[2];
    char feature;
    char box[3];
    char inBox[2];
};

//山东圣世达（36）
struct xUID_36_GE20200527{ //Date >= 20200527 13字节
    struct xUID_ZTL uid;
    char spare; // 值为0
};
//山东圣世达（36）
struct xUID_36_L20200527{ //Date < 20200527 17字节
    struct xOutcode outcode; //13字节
    char crc16[4]; //小端 //在管码前加一个'0'，14字节字符串转7字节16进制，计算CRC16
};

//山西焦化（07）
struct xUID_07_GE20200609{ //Date >= 20200609 13字节
    struct xUID_ZTL uid;
    char spare; // 值为0
};

//山西焦化（07）
struct xUID_07_L20200609{ //Date < 20200609 17字节
    struct xOutcode outcode;
    char crc16[4]; //小端
};


//Date >= 20191101
struct xUID{//20字节
    //生产日期 > 20191101; uid = 工厂代码 + 年 + inner #UID码20位
    //生产日期 <= 20191101; uid = inner #UID码16位
    char factory[2];
    char year[2];  //"%02d", Year-2000
    char incode[16]; // serl + pwd  小端
};

#pragma pack()


bool Incode2OutcodeForXA3(uint64* incode, char* outcode, int* detType);


void test_detCode();

#endif // DETCODE_H
