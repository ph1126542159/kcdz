﻿#ifndef CHANNELCMD_H
#define CHANNELCMD_H

#include <QByteArray>
#include <QString>
#include <QObject>
#include "SerialPort.h"

class ChannelCmd: public QObject
{
     Q_OBJECT
public:
    ChannelCmd(QObject* parent = NULL);
    int init(QString SerialName,int Baudrate = 57600);
    QByteArray m_readdata;
    bool isConnected(){
        return m_init;
    }

    int startCheck();
    int startWriteCode(const QByteArray& outcodes);

    int readCheckRslt(int channel, ushort& ch, ushort& checkRslt,
                       QByteArray& incode, QByteArray& pwd /*8 */,
                       uchar& detType, QByteArray& outcode);


    int readCheckRsltTimeout(int channel, int timeout, ushort& ch, ushort& checkRslt,
                                   QByteArray& incode, QByteArray& pwd /*8 */,
                                   uchar& detType, QByteArray& outcode);
signals:
    void sigConnect(bool connect);

private:
    int sendAndWaitReceive(ushort cmd, QByteArray& content_in, QByteArray& content_out, int size);

private:
    SerialPort m_serial;
    int m_init;

    QByteArray m_writedata;

};


#endif // CHANNELCMD_H
