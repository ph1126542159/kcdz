﻿#include "DetCode.h"
#include <stdlib.h>
#include <stdio.h>
#include <QDebug>

#define CharDec2Int(c)  ((c >='0'&&c <='9')? (c-'0'):0)

extern unsigned char GetCrc8Value(unsigned char *data, int len);


#define GetFactoryCode(incode)  ((struct xIncode*)incode)->factory
#define GetYear(incode)         (((struct xIncode*)incode)->year+2020)
#define GetDate(incode)         (GetYear(incode)*10000 + ((struct xIncode*)incode)->month*100 + ((struct xIncode*)incode)->day)

bool isIncodeValidForXA3(uint64* incode)
{
    uchar crc = (~GetCrc8Value((uchar*)incode, 7))&0xFF;
    if(crc == *((uchar*)incode+7)){
        qDebug()<<"crc8 check ok";
        return true;
    }else{
        qDebug()<<"crc8 check failed"<<crc<<*((uchar*)incode+7);
        return false;
    }
}

bool isOutcodeValidForXA3(char* outcode)
{
    return true;
}

bool isUIDValidForXA3(char* UID)
{
    return true;
}


bool Incode2OutcodeForXA3(uint64* incode, char* outcode, int* detType)
{
    struct xIncode* xin = (struct xIncode*)incode;

    uchar crc = (~GetCrc8Value((uchar*)incode, 7))&0xFF;
    if(crc == *((uchar*)incode+7)){
        qDebug()<<"crc8 check ok";
    }else{
        qDebug()<<"crc8 check failed"<<crc<<*((uchar*)incode+7);
    }


    sprintf(outcode, "%02d%d%02d%02d%c%03d%02d", (int)xin->factory, (int)xin->year, (int)xin->month, (int)xin->day, (int)xin->feature, (int)xin->box, (int)xin->inBox);

    *detType = xin->detType;

    return true;
}


int HexCharToValue(char c)
{
    int val = 0;

//    char buf[4] = {0};
//    buf[0] = '0';
//    buf[1] = 'x';
//    buf[2] = c;
//    buf[3] = '\0';
//    val = strtol(buf, NULL, 16);

    if(c >='0'&&c <='9'){
        val = (c-'0');
    }else if(c == 'a' || c == 'A'){
        val = 10;
    }else if(c == 'b' || c == 'B'){
        val = 11;
    }else if(c == 'c' || c == 'C'){
        val = 12;
    }else if(c == 'd' || c == 'D'){
        val = 13;
    }else if(c == 'e' || c == 'E'){
        val = 14;
    }else if(c == 'f' || c == 'F'){
        val = 15;
    }
    return val;
}

int HexChar2ToValue(char charh, char charl)
{
    int val = 0;

    char buf[5] = {0};
    buf[0] = '0';
    buf[1] = 'x';
    buf[2] = charh;
    buf[3] = charl;
    buf[4] = '\0';
    val = strtol(buf, NULL, 16);

    return val;
}


bool Outcode2IncodeForXA3(char* outcode, int detType, uint64* incode)
{
    struct xIncode* xin = (struct xIncode*)incode;
    struct xOutcode* xout = (struct xOutcode*)outcode;

    xin->inBox   = CharDec2Int(xout->inBox[0])*10 + CharDec2Int(xout->inBox[1]);
    xin->box     = CharDec2Int(xout->box[0])*100 + CharDec2Int(xout->box[1])*10 + CharDec2Int(xout->box[2]);
    xin->day     = CharDec2Int(xout->day[0])*10 + CharDec2Int(xout->day[1]);
    xin->month   = CharDec2Int(xout->month[0])*10 + CharDec2Int(xout->month[1]);
    xin->feature = xout->feature;//HexCharToValue(xout->feature);//
    xin->year    = CharDec2Int(xout->year);
    xin->yearl    = ((xin->year%2) == 1)? 1:0;
    xin->factory = CharDec2Int(xout->factory[0])*10 + CharDec2Int(xout->factory[1]);
    xin->detType = detType;
    xin->reserve = 0;

    xin->crc = (~GetCrc8Value((uchar*)incode, 7))&0xFF;

    return true;
}


bool Incode2UID_ZTL(uint64* incode, char* UID)
{
    struct xIncode* xin = (struct xIncode*)incode;

    sprintf(UID, "%02d%02d%c%02d%c%03d%02d", (int)xin->factory, (int)xin->year, (int)xin->month, (int)xin->day, (int)xin->feature, (int)xin->box, (int)xin->inBox);

    return true;
}

extern unsigned char GetCrc16Value(unsigned char *data, int len);

bool Incode2UID(uint64* incode, char* UID)
{
    struct xIncode* xin = (struct xIncode*)incode;
    int year = GetYear(incode) - 2000;
    int date = GetDate(incode);
    int factory = GetFactoryCode(incode);

    if(factory == 36)//山东圣世达（36）
    {
        if(date >= 20200527){
            Incode2UID_ZTL(incode, UID);
        }else{
            int detType = 0;
            char outcode_forcrc[7] = {0};
            char* out = NULL;
            xUID_36_L20200527* UID_36 = (xUID_36_L20200527*)UID;
            Incode2OutcodeForXA3(incode, (char*)&UID_36->outcode, &detType);

            out = (char*)&UID_36->outcode;
            outcode_forcrc[0] = HexChar2ToValue('0', out[0]);
            for(int i = 1; i < 7; i++) {
                outcode_forcrc[i] = HexChar2ToValue(out[i*2-1], out[i*2]);
            }

            unsigned short crc16 = GetCrc16Value((unsigned char*)outcode_forcrc, 7);

            sprintf(UID_36->crc16, "%02d%02d", crc16&0xFF, (crc16>>8)&0xFF);
        }
    }
    else if(factory == 7)//山西焦化 (07)
    {
        if(date >= 20200527){
            Incode2UID_ZTL(incode, UID);
        }else{
            int detType = 0;
            xUID_07_L20200609* UID_07 = (xUID_07_L20200609*)UID;
            Incode2OutcodeForXA3(incode, (char*)&UID_07->outcode, &detType);

            unsigned short crc16 = GetCrc16Value((unsigned char*)&UID_07->outcode, 13);

            sprintf(UID_07->crc16, "%02d%02d", crc16&0xFF, (crc16>>8)&0xFF);
        }
    }
    else
    {
        if(date >= 20191101)
        {
            uchar* pin = (uchar*)incode;
            sprintf(UID, "%02d%02d%02d%02d%02d%02d%02d%02d%02d%02d",
                    (int)xin->factory, (int)year, (int)pin[0], (int)pin[1], (int)pin[2], (int)pin[3], (int)pin[4], (int)pin[5], (int)pin[6], (int)pin[7]);
        }
        else
        {
            uchar* pin = (uchar*)incode;
            sprintf(UID, "%02d%02d%02d%02d%02d%02d%02d%02d",
                    (int)pin[0], (int)pin[1], (int)pin[2], (int)pin[3], (int)pin[4], (int)pin[5], (int)pin[6], (int)pin[7]);

        }

    }

    return true;
}


union INCODE_UNION {
    uint64 inValue;
    char inBuf[8];
};

void test_detCode()
{
    INCODE_UNION in;
    //in.inValue = 0x12823c96095100b3;
    in.inValue = 0x095100b312823c96;

    char outcode[20] = "5230301261100";
    char UID[21] = {0};
    int detType = 1;

    in.inValue = 0x8000c294195a00d8;

    //Incode2OutcodeForXA3(&in.inValue, outcode, &detType);

    qDebug()<<__FUNCTION__<<QByteArray(outcode);

    uint64 incode;
    //struct xIncode xin;

    INCODE_UNION u_in;

    //5230301200001

    INCODE_UNION incode_buf;
    incode_buf.inBuf[0] = 0x01;
    incode_buf.inBuf[1] = 0x00;
    incode_buf.inBuf[2] = 0xc2;
    incode_buf.inBuf[3] = 0x94;
    incode_buf.inBuf[4] = 0x19;
    incode_buf.inBuf[5] = 0x5a;
    incode_buf.inBuf[6] = 0x00;
    incode_buf.inBuf[7] = 0x8d;


    struct xIncode* xin_shaohua = (struct xIncode*)&incode_buf;

    //shaohua 0100c294195a008d
    //0100c210185a0034

    Outcode2IncodeForXA3(outcode, detType, (uint64*)&u_in);

    struct xIncode* xin = (struct xIncode*)&u_in;

    QByteArray array(u_in.inBuf, 8);
    qDebug()<<array.toHex();

//    Incode2UID(&in.inValue, UID);
//    qDebug()<<__FUNCTION__<<QByteArray(UID);

}


bool testDetCode(const QByteArray& outcode, int detType, const QByteArray& incode)
{
    INCODE_UNION incodebuf;

    Outcode2IncodeForXA3((char*)outcode.data(), detType, (uint64*)&incodebuf);

    if((incodebuf.inBuf[0] == incode.at(0))
            &&(incodebuf.inBuf[1] == incode.at(1))
            &&(incodebuf.inBuf[2] == incode.at(2))
            &&(incodebuf.inBuf[3] == incode.at(3))
            &&(incodebuf.inBuf[4] == incode.at(4))
            &&(incodebuf.inBuf[5] == incode.at(5))
            &&(incodebuf.inBuf[6] == incode.at(6))
            &&(incodebuf.inBuf[7] == incode.at(7))
            ){
        return true;
    }


    return false;
}
