﻿#ifndef SERIALPORT_H
#define SERIALPORT_H

#include <QDebug>
#include <QEventLoop>
#include <QTimer>
#include <QtEndian>

#include <QSerialPort>
#include <QSerialPortInfo>
#include "RingBuf.h"


class SerialPort:public QObject
{
    Q_OBJECT

public:
    SerialPort();
    bool OpenSerial(QString SerialName,int Baudrate);

    bool writeData(QByteArray &data);
    int readData(QByteArray &outdata, int size, int timeoutMs = 1000);


private:
    int verifydata(QByteArray& data);

    void enablePrint();
    void disablePrint();



signals:
    void serialMsgReady();

private slots:
    void readDataReady();
    void readDataReady_test();

private:
    RingBuf m_RBuf;
    QByteArray m_data;

    QByteArray m_curSndData;
    QByteArray m_curRcvData;


    QString m_portName;
    int m_baudRate;

    QSerialPort serialport;


    int m_waitTime;

    int m_readSize = 0;
};

#endif // SERIAL_H
