﻿#include "RingBuf.h"

#define _HEAD_   (0xC0)
#define _TAIL_   (0xC0)

#define _ADDR_   (0x41)

RingBuf::RingBuf()
{

}


void RingBuf::push(QByteArray& arr)
{
    for(char c:arr)
    {
        push(c);
    }
    //CBuf_findHead();
}

bool RingBuf::pop(QByteArray& out, int n)
{
    out.clear();
    for(int i = 0; i < n; i++)
    {
        out.append(pop());
    }
    return true;
}

void RingBuf::push(char c)
{
    if(!isFull()){
        CBuf[m_tail] = c;
        m_tail = (m_tail+1)%CBUF_MAXSIZE;
    }else{
        qDebug()<<__FUNCTION__<<"erro";
    }
}

char RingBuf::pop()
{
    char out = 0;
    if(!isEmpty()){
        out = CBuf[m_head];
        CBuf[m_head] = 0;
        m_head = (m_head+1)%CBUF_MAXSIZE;
        //qDebug()<<__FUNCTION__<<"pop "<<m_head;
    }else{

        qDebug()<<__FUNCTION__<<"erro";
    }

    return out;
}

int RingBuf::contains(char c)
{

    return 0;
}

void RingBuf::getHead(void* out)
{

}

bool RingBuf::checkCmdHead()
{
    return false;
}

bool RingBuf::findHead()
{
    while(!isEmpty() && (unsigned int)CBuf[m_head] != (unsigned int)0x46)
    {
        //qDebug()<<__FUNCTION__<<"pop";
        pop();
    }
    return false;
}

char RingBuf::getData(int pos)
{
    int _pos = (m_head+pos)%CBUF_MAXSIZE;
    if(_pos == m_tail){
        return 0;
    }

    return CBuf[_pos];
}


bool RingBuf::containsCmd()
{
    return false;
}

void RingBuf::popCmd(QByteArray& out)
{

}

bool RingBuf::isFull()
{
    if(m_head == (m_tail+1)%CBUF_MAXSIZE)
    {
        qDebug()<<__FUNCTION__<<" FULL"<<m_head<<m_tail<<size();
        return true;
    }
    return false;
}

bool RingBuf::isEmpty()
{
    if(m_head == m_tail)
    {
        qDebug()<<__FUNCTION__<<" Empty";
        return true;
    }
    return false;
}

int RingBuf::size()
{
    if(m_head <= m_tail)
    {
        return m_tail - m_head;
    }
    else
    {
        return CBUF_MAXSIZE-(m_head-m_tail);
    }
}

void RingBuf::clear(){
    m_head = 0;
    m_tail = 0;
}
