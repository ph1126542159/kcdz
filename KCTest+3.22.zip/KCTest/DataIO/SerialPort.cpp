﻿#include "SerialPort.h"
#include <QReadWriteLock>
#include <QTime>
#include <QDateTime>
#include <QRandomGenerator>

SerialPort::SerialPort()
{
    m_waitTime = 10000;
    connect(&serialport, SIGNAL(readyRead()), this, SLOT(readDataReady()));

//    QTimer *timer = new QTimer(this);
//    connect(timer, SIGNAL(timeout()), this, SLOT(readDataReady_test()));
//    timer->start(1000);

}

void SerialPort::readDataReady_test()
{
    static QByteArray data_row = "c0410010ffff04417fd594c5fbab8ae1a07cf10c4f143de6c379aa0a80e918b9a8ca896fb4bfecb5f4f07f2dad59fb93f733649b34fb66a969d361b5d07247a943294708dbddaa6e1cc0";
    static int index = 0;
    int cnt = 0;

    QByteArray data_hex = QByteArray::fromHex(data_row);
    int size = data_hex.size();

    QRandomGenerator rng(QTime::currentTime().msecsSinceStartOfDay());

    cnt = rng.bounded(4, size);

    if(cnt > 0)
    {
        QByteArray data;
        for(int i = 0; i < cnt; i++)
        {
            data.append(data_hex.at((index + i)%size));
        }
        index += cnt;

        //qDebug()<<__FUNCTION__<<"PUSH DATA "<<data.toHex();
        QByteArray Cmd;

        m_RBuf.push(data);
        if(m_RBuf.containsCmd())
        {
            m_RBuf.popCmd(Cmd);
            m_curRcvData = Cmd;
            emit serialMsgReady();
            //qDebug() <<__FUNCTION__<<"readAll cmd="<<QString(m_curRcvData.toHex());
        }
        else{
            //qDebug() <<__FUNCTION__<<"CBuf_containsCmd false";
        }
    }
    else
    {
        qInfo()<<serialport.portName()<<" no answer ";
    }
}

bool SerialPort::OpenSerial(QString SerialName,int Baudrate)
{
    serialport.setPortName(SerialName);
    serialport.setBaudRate(Baudrate);
    serialport.setDataTerminalReady(true);
    if (serialport.isOpen())
    {
        //串口已打开
        //qDebug() <<SerialName<< Baudrate <<" is opened!";
        return true;
    }

    if(serialport.open(QIODevice::ReadWrite))
    {
        //QReadWriteLock lock;
        //connect(&serialdata, SIGNAL(readyRead()), this, SLOT(readDataReady()));
        serialport.clear();
        qDebug() <<SerialName<<  Baudrate <<" is opened!";
        return true;
    }
    else
    {
        qDebug() <<SerialName<< Baudrate <<" is not opened!";
        return false;
    }
}


static int printFlag = 0;

#define PRINT if(printFlag)

void SerialPort::enablePrint()
{
    printFlag = 1;
}

void SerialPort::disablePrint()
{
    printFlag = 0;
}

void SerialPort::readDataReady()
{
    if(serialport.bytesAvailable() > 0)
    {
        QByteArray data = serialport.readAll();
        QByteArray Cmd;

        m_RBuf.push(data);
       // qDebug() <<__FUNCTION__<<"push data "<<data.toHex();
        if(m_RBuf.getData(0) == 0x01 )
        {
            if(m_RBuf.size() == 5)
            {//01 90 06 CC 02
                if((uchar)m_RBuf.getData(1) == 0x90
                   && (uchar)m_RBuf.getData(2) == 0x06
                   && (uchar)m_RBuf.getData(3) == 0xCC
                   && (uchar)m_RBuf.getData(4) == 0x02
                   )
                {
                    m_RBuf.pop(Cmd, 5);
                    m_curRcvData = Cmd;
                    emit serialMsgReady();
                }
            }
            else if(m_RBuf.size() >= m_readSize)
            {

                m_RBuf.pop(Cmd, m_readSize);
                m_curRcvData = Cmd;
                emit serialMsgReady();
            }

            //qDebug() <<__FUNCTION__<<"readAll cmd="<<QString(m_curRcvData.toHex());
        }
        else{
            //qDebug() <<__FUNCTION__<<"CBuf_containsCmd false";
        }
    }
    else
    {
        qInfo()<<serialport.portName()<<" no answer ";
    }
}


int SerialPort::readData(QByteArray &outdata, int size, int timeoutMs)
{
#if 1
    int ret = 0;
    m_curRcvData.clear();
    m_readSize = size;

    QEventLoop eventLoop;
    QTimer::singleShot(timeoutMs, &eventLoop, &QEventLoop::quit);
    QObject::connect(this, SIGNAL(serialMsgReady()), &eventLoop, SLOT(quit()));

    QTime time1 = QTime::currentTime();
    eventLoop.exec();
    QTime time2 = QTime::currentTime();

    int interval = (time2.msec() + time2.second()*1000) - (time1.msec()+ time1.second()*1000);

    if(interval > timeoutMs-300){
        qDebug()<<__FUNCTION__<<"Time1 = "<<time1;
        qDebug()<<__FUNCTION__<<"Time2 = "<<time2;
        qDebug()<<__FUNCTION__<<"######Timeout interval = "<<interval;
        ret = 0;
    }
#endif


     QByteArray data_content;
     if(m_curRcvData.isEmpty())
     {
        m_RBuf.pop(m_curRcvData, m_RBuf.size());
     }

     outdata = m_curRcvData;

    return outdata.size();
}


bool SerialPort::writeData(QByteArray &data)
{
    m_curRcvData.clear();
    serialport.clear();
    m_RBuf.clear();
    int ret = serialport.write(data);
    if(!ret)
        return false;

    m_curSndData = data;
    m_curRcvData = data;

    if(!serialport.waitForBytesWritten(5000))
    {
        qDebug() <<" writeData error";
        return false;
    }

    PRINT qDebug() <<__FUNCTION__<<"Write data="<< QString(data.toHex());

    m_curSndData = data;
    return true;
}

int SerialPort::verifydata(QByteArray& data)
{
    return 0;
}
