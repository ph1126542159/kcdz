﻿#include "ChannelCmd.h"
#include "CRC.h"
#include "AllConfig.h"

#define CH_NUM  5


#pragma pack(1)
struct MsgDef{
    uchar head;
    uchar funcCode;
    uchar addr[2];
    uchar sizeW[2];
    uchar  size;

    uchar data[14*CH_NUM];
    uchar crc16_l;
    uchar crc16_h;
};
#pragma pack(0)



struct channelStatus{
    uchar head;
    uchar funcCode;
};

ChannelCmd::ChannelCmd(QObject* parent)
    :QObject(parent)
{
    //init(AllConfig::instance()->getProduceConfig()->channel_port, 57600);
}


int ChannelCmd::init(QString SerialName,int Baudrate)
{
    m_init = m_serial.OpenSerial(SerialName, Baudrate);
    return m_init;
}

//返回值 -1-发送失败  0-数据接收超时  接收数据长度
int ChannelCmd::sendAndWaitReceive(ushort cmd, QByteArray& content_in, QByteArray& content_out, int size)
{
    m_writedata.clear();
    m_readdata.clear();

    m_writedata = content_in;
    int ret = m_serial.writeData(m_writedata);
    if(!ret){
        return -1;
    }

    ret = m_serial.readData(m_readdata, size);
    content_out = m_readdata;

    return ret;
}

int ChannelCmd::startCheck()
{
    struct MsgDef msg;
    msg.head = 0x01;
    msg.funcCode = 0x10;
    msg.addr[0] = 0x00;
    msg.addr[1] = 0x00;
    msg.sizeW[0] = 0x00;
    msg.sizeW[1] = 7*CH_NUM;
    msg.size = 14*CH_NUM;


    memset(msg.data, 0, 14*5);

    for(int i = 0; i < CH_NUM; i++){
        msg.data[i*14 + 0] = 0;
        for(int k = 1; k < 14; k++){
            msg.data[i*14 + k] = '0';
        }
    }

    QByteArray data = QByteArray((char*)&msg, sizeof(msg)-2);
    ushort crc16 = crc16_zh(data);
    msg.crc16_h = (crc16>>8)&0xFF;
    msg.crc16_l = (crc16>>0)&0xFF;

    QByteArray msgArr = QByteArray((char*)&msg, sizeof (msg));
    QByteArray content_out;
    qDebug()<<msgArr.toHex();
    int ret = sendAndWaitReceive(0, msgArr, content_out, 8); //5

    //01 90 06 CC 02
    return ret;
}

//ret=-2 传入数据有误
int ChannelCmd::startWriteCode(const QByteArray& outcodes)
{
    int ret = 0;
    struct MsgDef msg;
    msg.head = 0x01;
    msg.funcCode = 0x10;
    msg.addr[0] = 0x00;
    msg.addr[1] = 0x00;
    msg.sizeW[0] = 0x00;
    msg.sizeW[1] = 7*CH_NUM;
    msg.size = 14*CH_NUM;

    memset(msg.data, 0, 14*CH_NUM);
    if(outcodes.size() != 14*CH_NUM){
        ret = -2;
        return false;
    }

    for(int i = 0; i < CH_NUM*14; i++){
        msg.data[i] = outcodes.at(i);
    }

    QByteArray data = QByteArray((char*)&msg, sizeof(msg)-2);
    ushort crc16 = crc16_zh(data);
    msg.crc16_h = (crc16>>8)&0xFF;
    msg.crc16_l = (crc16>>0)&0xFF;


    QByteArray msgArr = QByteArray((char*)&msg, sizeof (msg));
    QByteArray content_out;

    qDebug()<<msgArr.toHex();
    ret = sendAndWaitReceive(0, msgArr, content_out, 8);

    return ret;
}



int ChannelCmd::readCheckRslt(int channel, ushort& ch, ushort& checkRslt,
                               QByteArray& incode, QByteArray& pwd /*8 */,
                               uchar& detType, QByteArray& outcode)
{
    char msg[12];
    msg[0] = 0x01;
    msg[1] = 0x03;
    msg[2] = ((0x0100 + (channel-1)*0x14)>>8)&0xFF;
    msg[3] = ((0x0100 + (channel-1)*0x14)>>0)&0xFF;
    msg[4] = 0x00;
    msg[5] = 0x14;

    msg[6] = 0x00;
    msg[7] = 0x00;

    QByteArray data = QByteArray((char*)&msg, 6);
    ushort crc16 = crc16_zh(data);
    msg[7] = (crc16>>8)&0xFF;
    msg[6] = (crc16>>0)&0xFF;

    QByteArray msgArr = QByteArray((char*)msg, 8);
    QByteArray out;
//    qDebug()<<msgArr.toHex();

    int ret = sendAndWaitReceive(0, msgArr, out, 45);
//    out = "010328000200ff013278cc00000000000000000000084b5de0e1fa000031000000000000000000000000000971";
    if(ret & (out.size() >= 45)){
        ch = ((out.at(3+0)<<8)&0xFF00) | (out.at(4)&0xFF);
        checkRslt = ((out.at(5)<<8)&0xFF00) | (out.at(6)&0xFF);

        for(int i = 0; i < 8; i++){
            incode.append(out.at(7+i));
        }
        for(int i = 0; i < 6; i++){
            pwd.append(out.at(23+i));
        }
        detType  = out.at(29)-'0';
        for(int i = 0; i < 13; i++){
            outcode.append(out.at(30+i));
        }
    }else{
        return false;
    }

    return ret;
}

static void Delay(int msec){
    QEventLoop loop;
    QTimer::singleShot(msec, &loop,SLOT(quit()));
    loop.exec();
}

int ChannelCmd::readCheckRsltTimeout(int channel, int timeout, ushort& ch, ushort& checkRslt,
                               QByteArray& incode, QByteArray& pwd /*8 */,
                               uchar& detType, QByteArray& outcode)
{
    incode.clear();
    outcode.clear();
    pwd.clear();

    int ret;
    QTime start = QTime::currentTime();
    ushort rsltRead = 0xFF;
    while((rsltRead&0xFF) == 0xFF)
    {
        incode.clear();
        pwd.clear();
        outcode.clear();
        Delay(50);
        ret = readCheckRslt(channel, ch, rsltRead, incode, pwd, detType, outcode);
        if(!ret){
            qDebug()<<"serial connect failed";
            //continue;
        }

        QTime current = QTime::currentTime();
        int interval = (current.msec() + current.second()*1000) - (start.msec()+ start.second()*1000);

//        if(interval >= timeout){
//            checkRslt = 0xFE;
//            ret = false;
//            return ret;
//        }

    }

    checkRslt = rsltRead;
    return ret;
}
