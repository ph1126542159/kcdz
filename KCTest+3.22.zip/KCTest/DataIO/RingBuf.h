﻿#ifndef RINGBUF_H
#define RINGBUF_H
#include <QDebug>
#include <QByteArray>

#define CBUF_MAXSIZE  (256)


class RingBuf
{
public:
    RingBuf();

    void push(QByteArray& arr);
    bool pop(QByteArray& out, int n);
    void push(char c);
    char pop();
    int  contains(char c);

    void getHead(void* out);
    bool checkCmdHead();
    bool findHead();
    bool containsCmd();
    void popCmd(QByteArray& out);


    char getData(int pos);

    bool isFull();
    bool isEmpty();
    int  size();
    void clear();

private:
    char CBuf[CBUF_MAXSIZE] = {0};
    int m_head = {0};
    int m_tail = {0};

};

#endif // RINGBUFFER_H
