﻿#ifndef CRC_H
#define CRC_H

#include <QString>


QString M_CRC16MOBUS(const QString &hexText);

ushort crc16_zh(const QByteArray& data);




#endif // CRC16_H
