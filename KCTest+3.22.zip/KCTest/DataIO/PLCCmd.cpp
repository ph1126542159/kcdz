﻿#include "PLCCmd.h"
#include <qtcpsocket.h>
#include <QTimer>
#include "AllConfig.h"
#include <QThread>

#define IP_ADDR  "192.168.20.20"
#define IP_PORT  9600



#define PLC_IP (0x14)
#define PC_IP (0x89)

#define READ_CMD  0x0101
#define WRITE_CMD 0x0102

#define AREA  0x82


PLCCmd::PLCCmd(QObject *parent):
    QObject(parent)
{


}

void PLCCmd::init(const QString& hostName, quint16 port, int local_ip)
{
    m_preCheckHeart = 0;
    m_writeCodeHeart = 0;
    m_recheckHeart = 0;
    m_socket.setParent(this);

    m_hostName = hostName;
    m_port = port;
    m_localIp = local_ip;

    TcpConnect();
    connect(&m_socket, &QTcpSocket::disconnected, this, [=]()
    {
        qDebug() << QString("**tcp disconnect ");
        //ui.talk->append("断开连接");
        //socket->deleteLater();//释放指向的内存
        m_tcpConnect = false;
        m_finsConnect = false;
    });

    connect(&m_socket, &QTcpSocket::connected, this, [=]()
    {
        qDebug() << QString("**tcp connect ok");

        m_tcpConnect = true;
    });

    FinsConnect();

//    QTimer* _timer = new QTimer(this);
//    connect(_timer, &QTimer::timeout, this, [=](){
//        this->sigConnect(this->isConnected());
//    });
//    _timer->start(2000);
}

bool PLCCmd::isConnected()
{
    if(m_tcpConnect){
        if(m_finsConnect){
            return true;
        }else{
            FinsConnect();
        }
    }else{
        int ret = TcpConnect();
        if(ret){
            FinsConnect();
        }
    }

    return false;
}

int PLCCmd::getSocketPort()
{
    return m_socket.localPort();

}

void PLCCmd::FinsConnectFrame(ConnectFrame& frame)
{
    frame.fins[0] = 0x46;
    frame.fins[1] = 0x49;
    frame.fins[2] = 0x4E;
    frame.fins[3] = 0x53;
    frame.len[0] = 0;
    frame.len[1] = 0;
    frame.len[2] = 0;
    frame.len[3] = sizeof(ConnectFrame) - 8;

    frame.funcCode[0] = 0;
    frame.funcCode[1] = 0;
    frame.funcCode[2] = 0;
    frame.funcCode[3] = 0;
    frame.errcode = 0;
    frame.selfIp[0] = 0;
    frame.selfIp[1] = 0;
    frame.selfIp[2] = 0;
    frame.selfIp[3] = m_localIp;
}

#define SwapEndia32(a)  ( ((a>>24)&0xff)|((a>>8)&0xff00)|((a<<8)&0xff0000)|((a<<24)&0xff000000) )
#define SwapEndia16(a)  ( ((a>>8)&0xff)|((a<<8)&0xff00) )


bool PLCCmd::packData(short cmd, uchar area, ushort addr, uchar offset, ushort num, const QByteArray& content, QByteArray& packedData)
{
    DataFrame frame;
    frame.fins[0] = 0x46;
    frame.fins[1] = 0x49;
    frame.fins[2] = 0x4E;
    frame.fins[3] = 0x53;

    frame.funcCode = SwapEndia32(0x02);
    frame.errcode = 0;
    int len = sizeof(DataFrame) - 8 + content.size();
    frame.len = SwapEndia32(len);

    frame.icf = 0x80; //发送0x80 响应0xC0
    frame.rsv = 0x00; //固定0x00
    frame.gct = 0x02; //固定0x02
    frame.dna = 0x00;
    frame.da1 = PLC_IP; //目标IP
    frame.da2 = 0x00;
    frame.sna = 0x00;
    frame.sa1 = PC_IP; //源IP
    frame.sa2 = 0x00;
    frame.sid = 0x00;

    frame.sid = 0x00;

    frame.cmd = SwapEndia16(cmd);
    frame.area = area;
    frame.addr = SwapEndia16(addr);
    frame.offset = offset;
    frame.countW = SwapEndia16(num);

    packedData = QByteArray((char*)&frame, sizeof(frame)) + content;
    return true;
}


bool PLCCmd::unpackData(const QByteArray& data, int& funcCode, ushort& cmd, QByteArray& content)
{
    if(data.size() >= 24)
    {
        DataFrame frame;
        frame.fins[0] = data.at(0);
        frame.fins[1] = data.at(1);
        frame.fins[2] = data.at(2);
        frame.fins[3] = data.at(3);


        frame.len       = (data.at(4)<<24)|(data.at(5)<<16)|(data.at(6)<<8)|(data.at(7)<<0);
        frame.funcCode  = (data.at(8)&0xff<<24)|(data.at(9)&0xff<<16)|(data.at(10)&0xff<<8)|(data.at(11)&0xff<<0);
        frame.errcode   = (data.at(11)<<24)|(data.at(12)<<16)|(data.at(13)<<8)|(data.at(14)<<0);

        funcCode = frame.funcCode;
    //    frame.icf = data.at(15); //发送0x80 响应0xC0
    //    frame.rsv = data.at(16); //固定0x00
    //    frame.gct = data.at(17); //固定0x02
    //    frame.dna = data.at(18);
    //    frame.da1 = data.at(19); //目标IP
    //    frame.da2 = data.at(20);
    //    frame.sna = data.at(21);
    //    frame.sa1 = data.at(22); //源IP
    //    frame.sa2 = data.at(23);
    //    frame.sid = data.at(24);

    //    cmd = (data.at(25)<<8)|(data.at(26)<<0);
        return true;
    }
    return false;
}

void PLCCmd::ReConnect()
{
    if(m_tcpConnect){
        if(m_finsConnect){

        }else{
            FinsConnect();
        }
    }else{
        TcpConnect();
    }
}

bool PLCCmd::TcpConnect()
{
    if(0 == m_socket.localPort())
    {
        m_socket.connectToHost(QHostAddress(m_hostName), m_port);
        if(m_socket.waitForReadyRead(1000))
        {
            qDebug()<<QThread::currentThreadId()<<QThread::currentThread()<<"Reconnected localPort = "<<m_socket.localPort()<<m_socket.isValid();
            m_tcpConnect = true;
        }
    }else{
        m_tcpConnect = true;
    }

    qDebug()<<QThread::currentThreadId()<<QThread::currentThread()<<"localPort = "<<m_socket.localPort()<<m_socket.isValid();

    return m_tcpConnect;
}


//FINS Connect SEND:  "46494e530000000c000000000000000000000089"
//FINS Connect RECV:  "46494e530000001000000001000000000000008900000014"

bool PLCCmd::FinsConnect()
{
    ConnectFrame frame;
    FinsConnectFrame(frame);
    QByteArray frame_arr((char*)&frame, sizeof(frame));
    m_socket.write(frame_arr);

  //  qDebug()<<"FINS Connect SEND: "<<frame_arr.toHex();
    if(m_socket.waitForReadyRead(500))
    {
        QByteArray m_recvData = m_socket.readAll();//接受服务器发送的信息

        qDebug() <<"FINS Connect RECV: "<< m_recvData.toHex();
        int funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, funcCode, cmd, content);

        qDebug()<<"funcCode = "<<funcCode;
        if(funcCode == 0x00000001){

            m_finsConnect = true;
            int errcode   = (m_recvData.at(11)<<24)|(m_recvData.at(12)<<16)|(m_recvData.at(13)<<8)|(m_recvData.at(14)<<0);
            qDebug()<<"errcode = "<<errcode;

            if(errcode == 0x02){

//                FINS Connect SEND:  "46494e530000000c000000000000000000000089"
//                FINS Connect RECV:  "46494e530000001000000001000000210000008900000014"

//                FINS Connect SEND:  "46494e530000000c000000000000000000000089"
//                FINS Connect RECV:  "46494e530000001000000001000000000000008900000014"
            }
        }
        else if(funcCode == 0x00000002)
        {

        }
        else if(funcCode == 0x00000003)
        {
            m_tcpConnect = false;
            m_finsConnect = false;
        }
    }


    return false;
}





bool PLCCmd::WriteCode_Read(int& heart, bool& writeCodeOK, bool& tiaohao, bool& butiaohao, ushort& lineLength)
{
    QByteArray content_in;
    QByteArray content_out;

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = 3;
    ushort addr = 3081;
    int offset = 0;

    packData(READ_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
    //qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();//接受服务器发送的信息

       // qDebug() <<"RECV : "<< m_recvData.toHex();
        int funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, funcCode, cmd, content);

      //  qDebug()<<"funcCode = "<<funcCode;
        if(funcCode == 0x00000001){
            m_finsConnect = true;
        }  else if(funcCode == 0x00000002)   {
            m_writeCodeWrite_Reply = m_recvData;

            heart = (m_recvData.at(30+0)&0xFF)<<8 | (m_recvData.at(30+1)&0xFF);

            writeCodeOK = (m_recvData.at(30+3)>>0)&0x01;
            tiaohao = (m_recvData.at(30+3)>>1)&0x01;
            butiaohao = (m_recvData.at(30+3)>>2)&0x01;
            lineLength = (m_recvData.at(30+4)&0xFF)<<8 | (m_recvData.at(30+5)&0xFF);

            qDebug()<<__FUNCTION__<<heart <<writeCodeOK<<tiaohao<<butiaohao<<lineLength;

            return true;
        }else if(funcCode == 0x00000003)  {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }

    return false;
}

bool PLCCmd::PreCheck_Read(int& heart, bool& startPreCheck, bool& reset)
{
    QByteArray content_in;
    QByteArray content_out;

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = 3;
    ushort addr = 3121;
    int offset = 0;

    packData(READ_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
  //  qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();

       // qDebug() <<"RECV : "<< m_recvData.toHex();

        m_funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, m_funcCode, cmd, content);

       // qDebug()<<"funcCode = "<<funcCode;
        if(m_funcCode == 0x00000001){
            m_finsConnect = true;
        }  else if(m_funcCode == 0x00000002)   {
            m_preCheckWrite_Reply = m_recvData;

            heart = (m_recvData.at(30+0)&0xFF)<<8 | (m_recvData.at(30+1)&0xFF);

            startPreCheck = (m_recvData.at(30+3)>>0)&0x01;
            reset = (m_recvData.at(30+3)>>1)&0x01;
          //  qDebug()<<__FUNCTION__<<heart <<startPreCheck;

            return true;
        }else if(m_funcCode == 0x00000003)  {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }


    return false;
}

bool PLCCmd::Recheck_Read(int& heart, bool& startReCheck, bool& reset)
{
    QByteArray content_in;
    QByteArray content_out;

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = 3;
    ushort addr = 3281;
    int offset = 0;

    packData(READ_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
   // qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();

      //  qDebug() <<"RECV : "<< m_recvData.toHex();

        m_funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, m_funcCode, cmd, content);

      //  qDebug()<<"funcCode = "<<funcCode;
        if(m_funcCode == 0x00000001){
            m_finsConnect = true;
        }  else if(m_funcCode == 0x00000002)   {
            m_recheckWrite_Reply = m_recvData;
            heart = (m_recvData.at(30+0)&0xFF)<<8 | (m_recvData.at(30+1)&0xFF);

            startReCheck = (m_recvData.at(30+3)>>0)&0x01;
            reset = (m_recvData.at(30+3)>>1)&0x01;
        //    qDebug()<<__FUNCTION__<<heart <<startReCheck;

            return true;
        }else if(m_funcCode == 0x00000003)  {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }

    return false;
}




bool PLCCmd::PreCheck_Write(ushort heart, bool enPreCheck, bool recvCheck,
                            bool finished, char rslt)
{
    QByteArray content_in;
    QByteArray content_out;

     m_preCheckHeart++;
    content_in.append((m_preCheckHeart>>8)&0xFF);
    content_in.append((m_preCheckHeart>>0)&0xFF);
    content_in.append((char)0);
    content_in.append((char)((1&0x01)<<0)|((enPreCheck&0x01)<<1));
    content_in.append((char)0);
    content_in.append((char)((recvCheck&0x01)<<0)|((finished&0x01)<<1)|((rslt&0x1F)<<2));


    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = content_in.size()/2;
    ushort addr = 3101;
    int offset = 0;

    packData(WRITE_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
    qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();//接受服务器发送的信息

        qDebug() <<"RECV : "<< m_recvData.toHex();
        int funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, funcCode, cmd, content);

        qDebug()<<"funcCode = "<<funcCode;
        if(funcCode == 0x00000001){
            m_finsConnect = true;
        }
        else if(funcCode == 0x00000002)
        {
            m_preCheckRead_Reply = m_recvData;

//            ushort heart = ((m_preCheckRead_Reply.at(30)<<8)&0xFF00) | m_preCheckRead_Reply.at(31);
//            qDebug()<<heart;

            return true;

        }else if(funcCode == 0x00000003)
        {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }

    return false;
}

bool PLCCmd::PreCheck_Write(QByteArray& data)
{

}

bool PLCCmd::PreCheck_WriteHeart(ushort heart)
{
    QByteArray content_in;
    QByteArray content_out;

     m_preCheckHeart++;
    content_in.append((m_preCheckHeart>>8)&0xFF);
    content_in.append((m_preCheckHeart>>0)&0xFF);

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = content_in.size()/2;
    ushort addr = 3101;
    int offset = 0;

    packData(WRITE_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
//    qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();//接受服务器发送的信息

//        qDebug() <<"RECV : "<< m_recvData.toHex();
        int funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, funcCode, cmd, content);

//        qDebug()<<"funcCode = "<<funcCode;
        if(funcCode == 0x00000001){
            m_finsConnect = true;
        }
        else if(funcCode == 0x00000002)
        {
            m_preCheckRead_Reply = m_recvData;

//            ushort heart = ((m_preCheckRead_Reply.at(30)<<8)&0xFF00) | m_preCheckRead_Reply.at(31);
//            qDebug()<<heart;

            return true;

        }else if(funcCode == 0x00000003)
        {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }

    return false;
}


bool PLCCmd::WriteCode_Write(ushort heart, bool enWriteCode, bool codeUsed, bool recvWrite,
                             bool writeFinished, bool writed, char rslt,
                             const QByteArray& codes, const QByteArray& failedcodes,
                             ushort len, ushort num, ushort writedNUm)
{
//    if(!isConnected()){
//        return false;
//    }

    QByteArray content_in;
    QByteArray content_out;

    m_writeCodeHeart++;
    content_in.append((m_writeCodeHeart>>8)&0xFF);
    content_in.append((m_writeCodeHeart>>0)&0xFF);
    content_in.append((char)0);
    content_in.append((char)((1&0x01)<<0)|((enWriteCode&0x01)<<1)|((codeUsed&0x01)<<2));
    content_in.append((char)0);
    content_in.append((char)((recvWrite&0x01)<<0)|((writeFinished&0x01)<<1)|((rslt&0x1F)<<2)|((writed&0x01)<<7));

    content_in += codes; //5*22*2
    content_in += failedcodes; //5*1*2
    content_in.append((len>>8)&0xFF);
    content_in.append((len>>0)&0xFF);

    content_in.append((num>>8)&0xFF);
    content_in.append((num>>0)&0xFF);

    content_in.append((writedNUm>>8)&0xFF);
    content_in.append((writedNUm>>0)&0xFF);

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = content_in.size()/2;
    ushort addr = 0x0bb9;
    int offset = 0;

    packData(WRITE_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    int reTry = 3;
    int ret = -1;
    while (ret == -1)
    {
        ret = m_socket.write(m_sendData);
        reTry--;
        if(reTry==0){
            break;
        }
    }

    if(ret != -1)
    {
        qDebug()<<"SEND :"<<m_sendData.toHex()<<ret;

        if(m_socket.waitForReadyRead(5000))
        {
            m_recvData = m_socket.readAll();//接受服务器发送的信息

            //qDebug() <<"RECV : "<< m_recvData.toHex();
            int funcCode = 0;
            ushort cmd = 0;
            QByteArray content;
            unpackData(m_recvData, funcCode, cmd, content);

            qDebug()<<"funcCode = "<<funcCode;
            if(funcCode == 0x00000001){
                m_finsConnect = true;
            }
            else if(funcCode == 0x00000002)
            {
                m_writeCodeRead_Reply = m_recvData;
                return true;
            }
            else if(funcCode == 0x00000003)
            {

            }
        }
    }



    return false;
}

bool PLCCmd::WriteCode_WriteHeart()
{
    QByteArray content_in;
    QByteArray content_out;

    m_writeCodeHeart++;
    content_in.append((m_writeCodeHeart>>8)&0xFF);
    content_in.append((m_writeCodeHeart>>0)&0xFF);

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = content_in.size()/2;
    ushort addr = 0x0bb9; //3001 3064
    int offset = 0;

    packData(WRITE_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    int reTry = 3;
    int ret = -1;
    while (ret == -1)
    {
        ret = m_socket.write(m_sendData);
        reTry--;
        if(reTry==0){
            break;
        }
    }

    if(ret != -1)
    {
        //qDebug()<<"SEND :"<<m_sendData.toHex()<<ret;

        if(m_socket.waitForReadyRead(5000))
        {
            m_recvData = m_socket.readAll();//接受服务器发送的信息

            //qDebug() <<"RECV : "<< m_recvData.toHex();
            int funcCode = 0;
            ushort cmd = 0;
            QByteArray content;
            unpackData(m_recvData, funcCode, cmd, content);

            qDebug()<<"funcCode = "<<funcCode;
            if(funcCode == 0x00000001){
                m_finsConnect = true;
            }
            else if(funcCode == 0x00000002)
            {
                m_writeCodeRead_Reply = m_recvData;
                return true;
            }
            else if(funcCode == 0x00000003)
            {

            }
        }
    }

    return false;
}

bool PLCCmd::WriteCode_WriteHeart2()
{
    QByteArray content_in;
    QByteArray content_out;

    int codeUsed = 0;

    ushort num = AllConfig::instance()->getProduceConfig()->produceNum;
    ushort writedNum = AllConfig::instance()->getProduceConfig()->produceWritedNum;
    if(writedNum >= num && AllConfig::instance()->getProduceConfig()->finalProduceFlag){
       codeUsed = 1;
    }else{
       codeUsed = 0;
    }

    m_writeCodeHeart++;
    content_in.append((m_writeCodeHeart>>8)&0xFF);
    content_in.append((m_writeCodeHeart>>0)&0xFF);
    content_in.append((char)0);
    content_in.append((char)((1&0x01)<<0)|((1&0x01)<<1)|((codeUsed&0x01)<<2));


    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = content_in.size()/2;
    ushort addr = 0x0bb9; //3001 3064
    int offset = 0;

    packData(WRITE_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    int reTry = 3;
    int ret = -1;
    while (ret == -1)
    {
        ret = m_socket.write(m_sendData);
        reTry--;
        if(reTry==0){
            break;
        }
    }

    if(ret != -1)
    {
        //qDebug()<<"SEND :"<<m_sendData.toHex()<<ret;

        if(m_socket.waitForReadyRead(5000))
        {
            m_recvData = m_socket.readAll();//接受服务器发送的信息

            //qDebug() <<"RECV : "<< m_recvData.toHex();
            int funcCode = 0;
            ushort cmd = 0;
            QByteArray content;
            unpackData(m_recvData, funcCode, cmd, content);

            qDebug()<<"funcCode = "<<funcCode;
            if(funcCode == 0x00000001){
                m_finsConnect = true;
            }
            else if(funcCode == 0x00000002)
            {
                m_writeCodeRead_Reply = m_recvData;
                return true;
            }
            else if(funcCode == 0x00000003)
            {

            }
        }
    }

    return false;
}

bool PLCCmd::WriteCode_WriteProduceNum()
{
    QByteArray content_in;
    QByteArray content_out;

//    m_writeCodeHeart++;
//    content_in.append((m_writeCodeHeart>>8)&0xFF);
//    content_in.append((m_writeCodeHeart>>0)&0xFF);

    ushort len = AllConfig::instance()->getProduceConfig()->lineLength;
    ushort num = AllConfig::instance()->getProduceConfig()->produceNum;
    ushort writedNum = AllConfig::instance()->getProduceConfig()->produceWritedNum;

    content_in.append((len>>8)&0xFF);
    content_in.append((len>>0)&0xFF);

    content_in.append((num>>8)&0xFF);
    content_in.append((num>>0)&0xFF);

    content_in.append((writedNum>>8)&0xFF);
    content_in.append((writedNum>>0)&0xFF);

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = content_in.size()/2;
    ushort addr = 3064; //3001 3064
    int offset = 0;

    packData(WRITE_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    int reTry = 3;
    int ret = -1;
    while (ret == -1)
    {
        ret = m_socket.write(m_sendData);
        reTry--;
        if(reTry==0){
            break;
        }
    }

    if(ret != -1)
    {
        //qDebug()<<"SEND :"<<m_sendData.toHex()<<ret;

        if(m_socket.waitForReadyRead(5000))
        {
            m_recvData = m_socket.readAll();//接受服务器发送的信息

            //qDebug() <<"RECV : "<< m_recvData.toHex();
            int funcCode = 0;
            ushort cmd = 0;
            QByteArray content;
            unpackData(m_recvData, funcCode, cmd, content);

            qDebug()<<"funcCode = "<<funcCode;
            if(funcCode == 0x00000001){
                m_finsConnect = true;
            }
            else if(funcCode == 0x00000002)
            {
                //m_writeCodeRead_Reply = m_recvData;
                return true;
            }
            else if(funcCode == 0x00000003)
            {

            }
        }
    }

    return false;
}



bool PLCCmd::WriteCode_WriteWrittingCode()
{
    ushort heart = 0;
    bool enWriteCode = true;
    bool codeUsed = false;
    bool recvWrite = true;
    bool writeFinished = false;
    bool writed = false;
    char rslt = 0;

    QByteArray failedcodes;
    ushort len = AllConfig::instance()->getProduceConfig()->lineLength;
    ushort num = AllConfig::instance()->getProduceConfig()->produceNum;
    ushort writedNum = AllConfig::instance()->getProduceConfig()->produceWritedNum;
    if(AllConfig::instance()->getProduceConfig()->produceWritedNum + 5 > AllConfig::instance()->getProduceConfig()->produceNum && AllConfig::instance()->getProduceConfig()->finalProduceFlag){
        codeUsed = true;
    }else{
        codeUsed = false;
    }

    QByteArray outcodes;

    for(int i = 0; i < 5*22; i++)
    {
        outcodes.append((char)(0));
    }

    for(int i = 0; i < 5; i++)
    {
        failedcodes.append((char)0);
        failedcodes.append((char)0);
    }

    return WriteCode_Write( heart, enWriteCode,  codeUsed, recvWrite,
                           writeFinished,  writed, rslt,
                           outcodes,  failedcodes,
                           len, num, writedNum);
}

bool PLCCmd::WriteCode_WriteWriteCodeFinished(uchar rslt, QList<QByteArray>& outcodes, QList<QByteArray>& failedcodes)
{
    if(outcodes.size() != 5 || failedcodes.size() != 5)
    {
        qDebug()<<"WriteCode_WriteWriteCodeFinished data ERR";
        return false;
    }
    ushort heart = 0;
    bool enWriteCode = true;
    bool codeUsed = false;
    bool recvWrite = true;
    bool writeFinished = true;
    bool writed = true;

    ushort len = AllConfig::instance()->getProduceConfig()->lineLength;
    ushort num = AllConfig::instance()->getProduceConfig()->produceNum;
    ushort writedNum = AllConfig::instance()->getProduceConfig()->produceWritedNum;
    int detType = AllConfig::instance()->getProduceConfig()->detType;
    QString detTypeStr =QString::number(detType);
    QByteArray outcodes_toPlc;
    for(int i = 0; i < 5; i++)
    {
        outcodes_toPlc.append(outcodes.at(i));
        outcodes_toPlc.append("1");
        for(int k = 0; k < 8; k++)
        {
            outcodes_toPlc.append(char(0));
        }
    }

    QByteArray failedcodes_toPlc;
    for(int i = 0; i < 5; i++)
    {
        failedcodes_toPlc.append(failedcodes.at(i));
    }

    qDebug()<<__FUNCTION__<<outcodes<<failedcodes;
    qDebug()<<__FUNCTION__<<outcodes_toPlc<<failedcodes_toPlc;

    return WriteCode_Write( heart, enWriteCode,  codeUsed, recvWrite,
                           writeFinished,  writed, rslt,
                           outcodes_toPlc,  failedcodes_toPlc,
                           len, num, writedNum);
}

bool PLCCmd::WriteCode_WriteBuTiaoHao()
{
    ushort heart = 0;
    bool enWriteCode = true;
    bool codeUsed = false;
    bool recvWrite = false;
    bool writeFinished = false;
    bool writed = false;
    char rslt = 0;


    ushort len = AllConfig::instance()->getProduceConfig()->lineLength;
    ushort num = AllConfig::instance()->getProduceConfig()->produceNum;
    ushort writedNum = AllConfig::instance()->getProduceConfig()->produceWritedNum;

    QByteArray outcodes;
    QByteArray failedcodes;

    for(int i = 0; i < 5*22; i++)
    {
        outcodes.append((char)(0));
    }

    for(int i = 0; i < 5; i++)
    {
        failedcodes.append((char)0);
        failedcodes.append((char)0);
    }

    return WriteCode_Write( heart, enWriteCode,  codeUsed, recvWrite,
                           writeFinished,  writed, rslt,
                           outcodes,  failedcodes,
                           len, num, writedNum);
}

bool PLCCmd::WriteCode_WriteTiaoHao()
{
    ushort heart = 0;
    bool enWriteCode = true;
    bool codeUsed = false;
    bool recvWrite = false;
    bool writeFinished = false;
    bool writed = false;
    char rslt = 0;

    ushort len = AllConfig::instance()->getProduceConfig()->lineLength;
    ushort num = AllConfig::instance()->getProduceConfig()->produceNum;
    ushort writedNum = AllConfig::instance()->getProduceConfig()->produceWritedNum;
    if(writedNum >= num && AllConfig::instance()->getProduceConfig()->finalProduceFlag){
       codeUsed = true;
    }

    QByteArray outcodes;
    QByteArray failedcodes;

    for(int i = 0; i < 5*22; i++)
    {
        outcodes.append((char)(0));
    }

    for(int i = 0; i < 5; i++)
    {
        failedcodes.append((char)0);
        failedcodes.append((char)0);
    }

    return WriteCode_Write( heart, enWriteCode,  codeUsed, recvWrite,
                           writeFinished,  writed, rslt,
                           outcodes,  failedcodes,
                           len, num, writedNum);
}





bool PLCCmd::Recheck_Write(ushort heart, bool enReCheck, bool recvReCheck,
                           bool recheckFinished, char rslt,
                          const QByteArray& codes, const QByteArray& failedcodes)
{
    QByteArray content_in;
    QByteArray content_out;

    m_recheckHeart++;
    content_in.append((m_recheckHeart>>8)&0xFF);
    content_in.append((m_recheckHeart>>0)&0xFF);
    content_in.append((char)0);
    content_in.append((char)((1&0x01)<<0)|((enReCheck&0x01)<<1));
    content_in.append((char)0);
    content_in.append((char)((recvReCheck&0x01)<<0)|((recheckFinished&0x01)<<1)|((rslt&0x1F)<<2));

    content_in += codes; //5*22*2
    content_in += failedcodes; //5*1*2

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = 80;
    ushort addr = 3201;
    int offset = 0;

    packData(WRITE_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
    qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();//接受服务器发送的信息

        qDebug() <<"RECV : "<< m_recvData.toHex();
        int funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, funcCode, cmd, content);

        qDebug()<<"funcCode = "<<funcCode;
        if(funcCode == 0x00000001){
//            m_finsConnect = true;
        }
        else if(funcCode == 0x00000002)
        {
            m_recheckRead_Reply = m_recvData;

//            ushort heart = ((m_recheckRead_Reply.at(30)<<8)&0xFF00) | m_recheckRead_Reply.at(31);
//            qDebug()<<heart;

            return true;

        }else if(funcCode == 0x00000003)
        {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }

    return false;

}


bool PLCCmd::xWR_sendWritedRslt(QByteArray& outcodes_toPlc, QByteArray& failedcodes)
{
    ushort heart = 0;
    bool enWriteCode = false;
    bool codeUsed = false;
    bool recvWrite = false;
    bool writeFinished = true;
    bool writed = false;
    char rslt = 0xFF;

    ushort len = 0;
    ushort num = 0;
    ushort writedNUm = 0;

    return WriteCode_Write(heart, enWriteCode,  codeUsed, recvWrite,
                           writeFinished,  writed, rslt,
                           outcodes_toPlc,  failedcodes,
                           len, num, writedNUm);
}

bool PLCCmd::xWR_finishedWrite(QByteArray& outcodes_toPlc, QByteArray& failedcodes)
{
    ushort heart = 0;
    bool enWriteCode = false;
    bool codeUsed = false;
    bool recvWrite = false;
    bool writeFinished = true;
    bool writed = false;
    char rslt = 0xFF;

    ushort len = 0;
    ushort num = 0;
    ushort writedNUm = 0;

    return WriteCode_Write(heart, enWriteCode,  codeUsed, recvWrite,
                           writeFinished,  writed, rslt,
                           outcodes_toPlc,  failedcodes,
                           len, num, writedNUm);

}

bool PLCCmd::PreCheck_Write_R()
{
    QByteArray content_in;
    QByteArray content_out;

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = 80;
    ushort addr = 3101;
    int offset = 0;

    packData(READ_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
    qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();//接受服务器发送的信息

        qDebug() <<"RECV : "<< m_recvData.toHex();
        int funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, funcCode, cmd, content);

        qDebug()<<"funcCode = "<<funcCode;
        if(funcCode == 0x00000001){
//            m_finsConnect = true;
        }
        else if(funcCode == 0x00000002)
        {
            m_preCheckRead_Reply = m_recvData;

//            ushort heart = ((m_preCheckRead_Reply.at(30)<<8)&0xFF00) | m_preCheckRead_Reply.at(31);
//            qDebug()<<heart;

            return true;

        }else if(funcCode == 0x00000003)
        {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }

    return false;
}

bool PLCCmd::WriteCode_Write_R()
{
    QByteArray content_in;
    QByteArray content_out;

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = 80;
    ushort addr = 0x0bb9;
    int offset = 0;

    packData(READ_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
    qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();//接受服务器发送的信息

        qDebug() <<"RECV : "<< m_recvData.toHex();
        int funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, funcCode, cmd, content);

        qDebug()<<"funcCode = "<<funcCode;
        if(funcCode == 0x00000001){
//            m_finsConnect = true;
        }
        else if(funcCode == 0x00000002)
        {
            m_writeCodeRead_Reply = m_recvData;

//            ushort heart = ((m_writeCodeRead_Reply.at(30)<<8)&0xFF00) | m_writeCodeRead_Reply.at(31);
//            qDebug()<<heart;

            return true;

        }else if(funcCode == 0x00000003)
        {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }

    return false;
}

bool PLCCmd::Recheck_Write_R()
{
    QByteArray content_in;
    QByteArray content_out;

    m_sendData.clear();
    m_recvData.clear();

    int writeCntW = 80;
    ushort addr = 3201;
    int offset = 0;

    packData(READ_CMD, AREA, addr, offset, writeCntW, content_in, m_sendData);
    m_socket.write(m_sendData);
    qDebug()<<"SEND :"<<m_sendData.toHex();

    if(m_socket.waitForReadyRead(500))
    {
        m_recvData = m_socket.readAll();//接受服务器发送的信息

        qDebug() <<"RECV : "<< m_recvData.toHex();
        int funcCode = 0;
        ushort cmd = 0;
        QByteArray content;
        unpackData(m_recvData, funcCode, cmd, content);

        qDebug()<<"funcCode = "<<funcCode;
        if(funcCode == 0x00000001){
//            m_finsConnect = true;
        }
        else if(funcCode == 0x00000002)
        {
            m_recheckRead_Reply = m_recvData;

//            ushort heart = ((m_recheckRead_Reply.at(30)<<8)&0xFF00) | m_recheckRead_Reply.at(31);
//            qDebug()<<heart;

            return true;

        }else if(funcCode == 0x00000003)
        {
//            m_tcpConnect = false;
//            m_finsConnect = false;
        }
    }

    return false;

}
